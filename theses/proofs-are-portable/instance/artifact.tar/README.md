# Idol Eyes — native MCP desktop runtime

The [WebAssembly target](docs/wasm.md) compiles the existing Idol request parser into an executable Wasm library. Its test host denies all effects; full desktop/MCP execution is not yet supplied by that target. Node is used only by its engine qualification tests, not as the product runtime.

The current source-build path is a Linux x86-64/X11 MCP controller with ten native tools, default-denied launcher scope, monotonic expiry, replay refusal, one-call text/chord/drag planning and lossless PNG capture. See [runtime usage and limits](docs/runtime.md). Build with `IDOL=/absolute/idol IDOL_RUNTIME=/absolute/runtime.c make server`; run `./mcp` from a stdio MCP client. Run `./verify` with the same compiler/runtime settings to rebuild and qualify the exact source against owned desktops. It does not touch a personal display.

**This is not yet a cross-platform, graph-authorized or competitively qualified replacement for Peekaboo/CUA.** Those remain the release objective, not a claim inferred from the small binary or this feature list.

# Product charter

**Idol-native computer perception, control, and UI.**

The target is a complete, measurably better alternative to Peekaboo: broader useful capabilities, stronger graph integration, lower latency and resource use, and at least equivalent correctness, safety, capture fidelity and usability. This is a release requirement, not a claim that the current implementation has achieved it.

## Current state

Pre-alpha product integration. The `native` submodule consumes the merged Idol-native AX value transaction and its adversarial qualification. It is not a second implementation, a Peekaboo wrapper, or a JavaScript controller renamed as native.

The existing transaction is authored in Idol and performs conditional value change with platform-access checks, one setter submission, independent readback and resource cleanup. It has native ABI test evidence. The last linked real-device evidence was blocked by macOS Accessibility permission. Full desktop control, graph-owned runtime authority, native UI authoring, packaging and competitive measurements remain open. The exact dependency revisions live in `eyes.json`; source presence and passing product-contract tests do not qualify those missing capabilities.

## Observe slice (macOS)

 is the first slice of the macOS observation and reference producers: it turns a captured accessibility observation into snapshot values whose actionable elements carry premise-bound refs, and resolves a ref only while its premise holds, refusing by name otherwise. The transport is foreign and carries an elimination order. See [the observe contract](docs/observe.md).

## Native MCP ingress candidate

`protocol/ingress.id` provides bounded, allocation-free **request parsing**, not a computer-control server. It validates the complete frame and projects exact ID/method/params/tool-name byte spans without granting authority or interpreting application payloads. Its executed source/graph/native-code tests run with:

```sh
make ingress IDOL=/absolute/path/to/idol
```

Read [the interface, bounds and qualification limits](docs/protocol.md). This path currently qualifies Linux x86_64 machine code from the explicit C realization; it does not establish direct-backend parity or complete graph fact publication. Stream framing, MCP version/capability handling, dispatch to the actual graph-owned executor, mesh lease binding and device effects are not supplied by this parser. Existing native and device gates remain unchanged.

## Ownership

| Repository | Responsibility |
|---|---|
| `clpi/idol` | Language, semantic graph, worlds, effects, compiler and canonical vocabulary |
| `clpi/idol-native` | Shared native realization and physical/ABI evidence |
| `clpi/idol-eyes` | Computer-use product composition, application integration, user surfaces, packaging and comparison acceptance |

The shared native code has one producer. Fix it upstream and deliberately advance the gitlink. Do not copy it into this repository and develop two variants. Peekaboo is an external comparator, never a runtime dependency.

## Development

```sh
git clone --recurse-submodules git@github.com:clpi/idol-eyes.git
cd idol-eyes
make check
make source
```

`make check` needs Python 3 and validates only the product contract and its regression tests. `make source` additionally requires the exact clean native checkout and checks its entry digest and gitlink.

To execute the inherited native ABI oracle with a compiler you have built from the compiler pin in `eyes.json`:

```sh
make oracle IDOL=/absolute/path/to/idol CAPTURE=/absolute/new/evidence-directory
make device CAPTURE=/absolute/new/evidence-directory
```

The oracle needs a compatible native compiler and C toolchain; the device path needs macOS ARM64, AppKit and an explicitly authorized Accessibility execution context. The capture parent must exist, but the capture itself must be new. The second command consumes the first command's successful source-bound artifacts. It never grants permissions or silently falls back to a host implementation. A source checkout beside a binary does not by itself prove that binary's build provenance.

## Better than Peekaboo means

[`bench/peekaboo.json`](bench/peekaboo.json) is the initial coverage contract. Its baseline is pinned to a released source commit; every comparison is currently **unmeasured**. Binary/configuration digests must be acquired from the actual comparator used in a campaign. The case labels are benchmark labels, not Idol semantic IDs.

Read [the acceptance contract](docs/acceptance.md) and [architecture](docs/architecture.md). Warm must be compared with warm, cold with cold, and verified effects with equally verified effects. No average may conceal a losing workload or a missing capability. Broad superiority requires independent evidence across the shared domain; extra platforms cannot excuse a macOS regression.

The product-contract CI does not execute personal UI, launch a daemon, change TCC permissions, upload private screenshots, or certify performance. The source-built runtime has bounded local execution evidence; it is not a signed production release or a competitively qualified system. Prebuilt binaries and generated C are delivery artifacts, not the maintained implementation in this source tree.
