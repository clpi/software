# Idol Eyes engineering

Follow upstream `clpi/idol/docs/spec/law.md`, then the exact native dependency's `AGENTS.md` and authority projection. This product is not a new language or semantic authority. Read `eyes.json`, `docs/architecture.md` and `docs/acceptance.md` before changes.

Production policy, target identity, authority, ordering, verification, recovery and UI behavior must be authored and executed in Idol. OS APIs remain explicit foreign ABI boundaries. Test fixtures and build orchestration may be foreign, with their limited role clearly stated. Never count a host controller with one compiled predicate as native ownership.

One graph owns semantic IDs, worlds, applications, packs and outcomes. Labels, selectors, paths, coordinates and hashes are evidence/provenance, not identity or grants. Do not add another graph, vocabulary registry, scheduler or policy ontology. Reuse Hermes for fleet coordination.

`native` is a pinned dependency. Do not edit it in place, duplicate its source, or silently follow its branch. Submit shared physical fixes to clpi/idol-native and consume a deliberately reviewed revision. Language/compiler fixes belong in clpi/idol.

Use owned fixtures. Preserve user focus/input. Explicit consent precedes foreground action, observation of sensitive surfaces and irreversible effects. No permission bypass, credential extraction, blind retry, silently lowered verification or public exposure of private evidence.

Run `make check`; run `make source` with the dependency initialized; run actual native/device qualification when changing production behavior. Preserve failures separately from blocked infrastructure. Tests of metadata are not product tests. Do not change comparison states to passing without implementing and reviewing a real evidence producer and verifier. No performance claim from generated counts, source volume, design prose or a faster but weaker comparator.

The dependency has not been relicensed. Do not publish private source or choose a license on the owner's behalf. The initial product repository is private.
