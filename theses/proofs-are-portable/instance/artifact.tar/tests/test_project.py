import copy
import importlib.util
import json
from pathlib import Path
import unittest

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location('check', ROOT / 'tools/check.py')
check = importlib.util.module_from_spec(spec)
spec.loader.exec_module(check)

class Contract(unittest.TestCase):
    def setUp(self):
        self.project = json.loads((ROOT / 'eyes.json').read_text())
        self.comparison = json.loads((ROOT / 'bench/peekaboo.json').read_text())

    def test_initial_contract_is_valid_but_unqualified(self):
        self.assertEqual(check.validate(self.project, self.comparison), [])
        self.assertEqual(self.project['status'], 'pre-alpha')
        self.assertFalse(self.comparison['superiorityEstablished'])

    def test_moving_native_ref_is_rejected(self):
        self.project['native']['commit'] = 'main'
        self.assertIn('native.commit must be an exact commit', check.validate(self.project, self.comparison))

    def test_moving_compiler_ref_is_rejected(self):
        self.project['compiler']['commit'] = 'latest'
        self.assertIn('compiler.commit must be an exact commit', check.validate(self.project, self.comparison))

    def test_empty_comparison_is_not_coverage(self):
        self.comparison['cases'] = []
        self.assertIn('comparison must contain cases', check.validate(self.project, self.comparison))

    def test_duplicate_case_is_rejected(self):
        self.comparison['cases'].append(copy.deepcopy(self.comparison['cases'][0]))
        self.assertIn('comparison case labels must be unique', check.validate(self.project, self.comparison))

    def test_missing_metric_is_rejected(self):
        self.comparison['metrics'] = []
        self.assertIn('comparison must contain metrics', check.validate(self.project, self.comparison))

    def test_unmeasured_cannot_be_claimed_as_superiority(self):
        self.comparison['superiorityEstablished'] = True
        self.assertIn('this bootstrap cannot certify superiority', check.validate(self.project, self.comparison))

    def test_string_false_is_not_boolean_false(self):
        self.comparison['superiorityEstablished'] = 'false'
        self.assertIn('this bootstrap cannot certify superiority', check.validate(self.project, self.comparison))

    def test_runtime_is_not_a_host_wrapper(self):
        self.project['runtime'] = 'Node'
        self.assertIn('production runtime must be Idol', check.validate(self.project, self.comparison))

    def test_comparator_is_external(self):
        self.comparison['baseline']['runtimeDependency'] = True
        self.assertIn('Peekaboo must remain an external comparator', check.validate(self.project, self.comparison))

    def test_baseline_must_be_revision_bound(self):
        self.comparison['baseline']['commit'] = 'latest'
        self.assertIn('baseline.commit must be an exact commit', check.validate(self.project, self.comparison))

    def test_unknown_case_state_is_rejected(self):
        self.comparison['cases'][0]['state'] = 'passing'
        self.assertIn('bootstrap comparison cases must remain unmeasured', check.validate(self.project, self.comparison))

if __name__ == '__main__':
    unittest.main()
