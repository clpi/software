#!/usr/bin/env python3
"""Fixture battery for the tree producer (docs/tree.md).

Runs a compiled tree binary (TREE_BIN) against a canned
form-shaped tree block and a pair of flat Calculator blocks,
checking:

  tree full      every scripted node present, nested by
                 parent, actionable nodes carrying references
                 in block order (spec case A-O1's tree form);
  tree skeleton  depth clamped at 3, the cut container
                 carrying its child count, cut points named,
                 completeness false over a cut tree (A-O3);
  tree compact   single-child unnamed group wrappers
                 collapsed out of the tree;
  drill          exactly the named region, fresh references
                 (A-O3's second half);
  search         role and exact name: the duplicate-label
                 case returns both matches, a missing role
                 returns zero matches plus the roles present
                 (A-O4);
  read           a value read and a state read return the
                 set values; a state that does not apply
                 answers applicable false, distinct from any
                 state value (A-O5);
  resolve        identity resolution across two flat blocks:
                 a moved element still resolves; a vanished
                 identity refuses R-STALE carrying the live
                 snapshot as the retracting observation; a
                 duplicated identity refuses R-AMBIG listing
                 both candidates; a headerless block refuses
                 R-NOSNAP. Every refusal is an envelope, never
                 an act line: the battery's event log (the act
                 lines it collected) proves zero input was
                 delivered by a refusal (A-A4, A-A5).

The battery recomputes the premise fold by hand from the same
bytes, independently of the program, and compares.
"""
import json
import os
import subprocess
import sys

BLOCK = (
    "S\tfsnap1\tForm\n"
    "N\twin\t-\twindow\t0\t\t-\tForm\n"
    "N\tmain\twin\tgroup\t0\t\t-\t-\n"
    "N\tname\tmain\ttext\t1\tAda\t-\tName\n"
    "N\tsecret\tmain\tsecure\t1\t\t-\tPassword\n"
    "N\tnews\tmain\tcheckbox\t1\t\tunchecked\tNewsletter\n"
    "N\tdisc\tmain\tgroup\t0\t\t-\tDetails\n"
    "N\tnote\tdisc\ttext\t1\thello\t-\tNote\n"
    "N\tdeep\tdisc\tgroup\t0\t\t-\t-\n"
    "N\tdeeper\tdeep\tgroup\t0\t\t-\t-\n"
    "N\tleaf\tdeeper\tbutton\t1\t\t-\tLeaf\n"
    "N\tgo\tmain\tbutton\t1\t\t-\tSubmit\n"
    "N\talsogo\twin\tbutton\t1\t\t-\tSubmit\n"
)

ISSUING = (
    "S\ts1\tCalculator\n"
    "E\td1\ttext\t0\t77\n"
    "E\tb7\tbutton\t1\t7\n"
    "E\tb8\tbutton\t1\t8\n"
)
LIVE_MOVED = (
    "S\ts2\tCalculator\n"
    "E\td1\ttext\t0\t78\n"
    "E\tb8\tbutton\t1\t8\n"
    "E\tb7\tbutton\t1\t7\n"
)
LIVE_GONE = (
    "S\ts3\tCalculator\n"
    "E\tb8\tbutton\t1\t8\n"
)
LIVE_DUP = (
    "S\ts4\tCalculator\n"
    "E\tb7\tbutton\t1\t7\n"
    "E\tb7\tbutton\t1\t7\n"
)


def premise(block):
    h = 7
    for byte in block.encode():
        h = (h * 31 + byte) & 268435455
    return str(h)


def run(binary, text):
    process = subprocess.run([binary], input=text,
                             capture_output=True, text=True, timeout=30)
    if process.returncode != 0:
        raise SystemExit("tree program failed: " + process.stderr.strip())
    return process.stdout.strip()


def find(node, identity):
    if node.get("identity") == identity:
        return node
    for child in node.get("children", []):
        found = find(child, identity)
        if found is not None:
            return found
    return None


def identities(node, acc):
    acc.append(node.get("identity"))
    for child in node.get("children", []):
        identities(child, acc)
    return acc


def main():
    binary = os.environ.get("TREE_BIN", "./tree")
    failures = []
    events = []

    def arm(name, condition, detail=""):
        print(("ok   " if condition else "FAIL ") + name +
              ((" - " + detail) if detail and not condition else ""))
        if not condition:
            failures.append(name)

    def call(text):
        answer = run(binary, text)
        if answer.startswith("act "):
            events.append(answer)
        return answer

    full = json.loads(call("tree full\n" + BLOCK))
    data = full.get("data", {})
    arm("full ok flag", full.get("ok") is True)
    arm("full completeness", data.get("complete") is True)
    arm("full premise", data.get("premise") == premise(BLOCK))
    tree = data.get("tree", {})
    arm("full root", tree.get("identity") == "win")
    arm("full holds every node",
        sorted(identities(tree, [])) == sorted(
            ["win", "main", "name", "secret", "news", "disc", "note",
             "deep", "deeper", "leaf", "go", "alsogo"]),
        str(identities(tree, [])))
    arm("full nests by parent",
        find(tree, "leaf") is not None and
        find(tree, "deep") is not None and
        find(find(tree, "deep"), "deeper") is not None)
    arm("full refs in block order",
        find(tree, "name").get("ref_id") == "@fsnap1:e1" and
        find(tree, "go").get("ref_id") == "@fsnap1:e6" and
        find(tree, "alsogo").get("ref_id") == "@fsnap1:e7")
    arm("full carries value and state",
        find(tree, "name").get("value") == "Ada" and
        find(tree, "news").get("state") == "unchecked")

    skeleton = json.loads(call("tree skeleton\n" + BLOCK)).get("data", {})
    arm("skeleton incomplete over a cut tree",
        skeleton.get("complete") is False)
    arm("skeleton names the cut point",
        skeleton.get("cutpoints") == ["disc"], str(skeleton.get("cutpoints")))
    stree = skeleton.get("tree", {})
    arm("skeleton clamps depth at 3",
        find(stree, "disc") is not None and
        find(stree, "note") is None and find(stree, "deep") is None)
    arm("skeleton cut container carries its child count",
        find(stree, "disc").get("child_count") == 2,
        str(find(stree, "disc")))

    compact = json.loads(call("tree compact\n" + BLOCK)).get("data", {})
    ctree = compact.get("tree", {})
    arm("compact collapses wrapper chains",
        find(ctree, "deep") is None and find(ctree, "deeper") is None and
        find(find(ctree, "disc"), "leaf") is not None)
    arm("compact keeps real nodes",
        find(ctree, "main") is not None and
        find(ctree, "go") is not None)

    drill = json.loads(call("drill disc\n" + BLOCK)).get("data", {})
    dtree = drill.get("tree", {})
    arm("drill root is the region", dtree.get("identity") == "disc")
    arm("drill holds exactly the region",
        sorted(identities(dtree, [])) ==
        sorted(["disc", "note", "deep", "deeper", "leaf"]),
        str(identities(dtree, [])))
    arm("drill refs are fresh references of this observation",
        find(dtree, "note").get("ref_id") == "@fsnap1:e4")
    missing = json.loads(call("drill nosuch\n" + BLOCK))
    arm("drill on a missing identity refuses R-ELEM",
        missing.get("error", {}).get("code") == "R-ELEM",
        json.dumps(missing))

    search = json.loads(call("search button Submit\n" + BLOCK)).get("data", {})
    matches = search.get("matches", [])
    arm("search finds both duplicate labels",
        [m.get("ref_id") for m in matches] == ["@fsnap1:e6", "@fsnap1:e7"],
        str(matches))
    none = json.loads(call("search slider Anything\n" + BLOCK)).get("data", {})
    arm("search with a missing role finds nothing and lists roles",
        none.get("matches") == [] and
        "button" in none.get("roles", []) and
        "checkbox" in none.get("roles", []), str(none))

    value = json.loads(call(
        "read @fsnap1:e1 " + premise(BLOCK) + " value\n" + BLOCK)).get("data", {})
    arm("read returns the set value", value.get("value") == "Ada", str(value))
    state = json.loads(call(
        "read @fsnap1:e3 " + premise(BLOCK) + " state\n" + BLOCK)).get("data", {})
    arm("read returns the set state",
        state.get("applicable") is True and state.get("state") == "unchecked",
        str(state))
    na = json.loads(call(
        "read @fsnap1:e1 " + premise(BLOCK) + " state\n" + BLOCK)).get("data", {})
    arm("a state that does not apply answers applicable false",
        na.get("applicable") is False and "state" not in na, str(na))
    stale = json.loads(call(
        "read @fsnap1:e1 0 state\n" + BLOCK))
    arm("read under a wrong premise refuses R-STALE",
        stale.get("error", {}).get("code") == "R-STALE", json.dumps(stale))

    issued_premise = premise(ISSUING[:-1])
    moved = call("resolve @s1:e1 " + issued_premise + "\n" +
                 ISSUING + "L\n" + LIVE_MOVED)
    arm("resolve follows identity across positions",
        moved == "act b7 s2", moved)
    gone = json.loads(call("resolve @s1:e1 " + issued_premise + "\n" +
                           ISSUING + "L\n" + LIVE_GONE))
    arm("resolve on a vanished identity refuses R-STALE",
        gone.get("error", {}).get("code") == "R-STALE", json.dumps(gone))
    arm("the stale refusal carries the retracting observation",
        gone.get("error", {}).get("retracted_by") == "s3", json.dumps(gone))
    dup = json.loads(call("resolve @s1:e1 " + issued_premise + "\n" +
                          ISSUING + "L\n" + LIVE_DUP))
    arm("resolve on a duplicated identity refuses R-AMBIG",
        dup.get("error", {}).get("code") == "R-AMBIG", json.dumps(dup))
    arm("the ambiguity refusal lists both candidates",
        dup.get("error", {}).get("candidates") == ["@s4:e1", "@s4:e2"],
        json.dumps(dup))
    headerless = "E\tb7\tbutton\t1\t7\n"
    nosnap = json.loads(call("resolve @s1:e1 " + issued_premise + "\n" +
                             headerless + "L\n" + LIVE_MOVED))
    arm("a block with no snapshot header refuses R-NOSNAP",
        nosnap.get("error", {}).get("code") == "R-NOSNAP",
        json.dumps(nosnap))
    arm("zero input delivered by any refusal",
        events == ["act b7 s2"], str(events))

    print("tree battery: %s" % ("FAIL " + ", ".join(failures)
                                if failures else "all arms ok"))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
