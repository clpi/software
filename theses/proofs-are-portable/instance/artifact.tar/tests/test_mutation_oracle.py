"""Offline controls for mutation evidence admission; no compiler or UI runs."""
import importlib.util
import io
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

SPEC = importlib.util.spec_from_file_location(
    'mutation_oracle', Path(__file__).parent / 'server/mutation_oracle.py')
ORACLE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(ORACLE)


def transcript(*methods):
    # This class is intentionally local: discovery must not execute its
    # deliberate failures as repository tests.
    class Fixture(unittest.TestCase):
        def test_required(self):
            self.fail('required behavioral difference')

        def test_other(self):
            self.fail('other failure mentioning test_required')

        def test_pass(self):
            pass

        def test_error(self):
            raise RuntimeError('infrastructure unavailable')

        @unittest.skip('not evidence')
        def test_skip(self):
            pass

        @unittest.expectedFailure
        def test_expected(self):
            self.fail('not evidence')

    suite = unittest.TestSuite(Fixture(method) for method in methods)
    identity = Fixture(methods[0]).id()
    stream = io.StringIO()
    result = unittest.TextTestRunner(stream=stream, verbosity=2).run(suite)
    return (0 if result.wasSuccessful() else 1), stream.getvalue().encode(), identity


class MutationOracle(unittest.TestCase):
    def test_accepts_actual_named_assertion_failure(self):
        ORACLE.require_named_failure(*transcript('test_required'))

    def test_rejects_wrong_failure_even_when_name_is_in_output(self):
        code, output, identity = transcript('test_other')
        with self.assertRaises(RuntimeError):
            ORACLE.require_named_failure(code, output, identity.replace('test_other', 'test_required'))

    def test_rejects_passing_required_case_and_other_failure(self):
        with self.assertRaises(RuntimeError):
            ORACLE.require_named_failure(*transcript('test_pass', 'test_other'))

    def test_rejects_multiple_cases_even_with_only_one_failure(self):
        with self.assertRaises(RuntimeError):
            ORACLE.require_named_failure(*transcript('test_required', 'test_pass'))

    def test_rejects_multiple_failures(self):
        with self.assertRaises(RuntimeError):
            ORACLE.require_named_failure(*transcript('test_required', 'test_other'))

    def test_rejects_errors_passes_skips_and_expected_failures(self):
        for method in ('test_error', 'test_pass', 'test_skip', 'test_expected'):
            with self.subTest(method=method), self.assertRaises(RuntimeError):
                ORACLE.require_named_failure(*transcript(method))

    def test_rejects_wrong_exit_status(self):
        _, output, identity = transcript('test_required')
        for code in (0, 2, -9):
            with self.subTest(code=code), self.assertRaises(RuntimeError):
                ORACLE.require_named_failure(code, output, identity)

    def test_rejects_fixture_setup_and_cleanup_assertions(self):
        for hook in ('setUp', 'tearDown'):
            # A named hook in the traceback models real setup/cleanup code.
            source = 'def ' + hook + '(self):\n    self.fail("fixture infrastructure failed")\n'
            namespace = {}
            exec(compile(source, '<owned-offline-fixture>', 'exec'), namespace)
            fixture = type('BrokenFixture', (unittest.TestCase,), {
                hook: namespace[hook], 'test_required': lambda self: None})
            case = fixture('test_required')
            stream = io.StringIO()
            result = unittest.TextTestRunner(stream=stream, verbosity=2).run(unittest.TestSuite([case]))
            self.assertFalse(result.wasSuccessful())
            with self.subTest(hook=hook), self.assertRaises(RuntimeError):
                ORACLE.require_named_failure(1, stream.getvalue().encode(), case.id())

    def test_rejects_process_failure_embedded_in_assertion(self):
        code, output, identity = transcript('test_required')
        for marker in (b'RuntimeError: failed', b'CalledProcessError'):
            with self.subTest(marker=marker), self.assertRaises(RuntimeError):
                ORACLE.require_named_failure(code, output.replace(b'required behavioral difference', marker), identity)

    def test_rejects_missing_assertion_or_truncated_summary(self):
        code, output, identity = transcript('test_required')
        for invalid in (output.replace(b'AssertionError:', b'ValueError:'), output.split(b'FAILED (')[0]):
            with self.subTest(output=invalid), self.assertRaises(RuntimeError):
                ORACLE.require_named_failure(code, invalid, identity)

    def test_selects_exact_case_with_unittest_not_script_main(self):
        for script, cls in ORACLE.CLASSES.items():
            with self.subTest(script=script):
                command, identity = ORACLE.single_case_command('/python', script, 'test_required')
                self.assertEqual(identity, script[:-3] + '.' + cls + '.test_required')
                self.assertEqual(command, ['/python', '-S', '-m', 'unittest', '-v', identity])

    def test_unknown_script_fails_closed(self):
        with self.assertRaises(KeyError):
            ORACLE.single_case_command('/python', 'unknown.py', 'test_required')

    def test_single_case_command_imports_only_requested_case_under_no_site(self):
        with tempfile.TemporaryDirectory(prefix='eyes-oracle-control-') as temporary:
            root = Path(temporary)
            (root / 'reconcile.py').write_text('''import pathlib, unittest
class Reconcile(unittest.TestCase):
    def test_required(self):
        pathlib.Path('required-ran').write_text('yes')
        self.fail('deliberate owned behavioral difference')
    def test_other(self):
        pathlib.Path('other-ran').write_text('wrong selection')
if __name__ == '__main__':
    pathlib.Path('main-ran').write_text('wrong entrypoint')
    unittest.main()
''')
            command, identity = ORACLE.single_case_command(
                sys.executable, 'reconcile.py', 'test_required')
            result = subprocess.run(command, cwd=root, capture_output=True, timeout=10)
            ORACLE.require_named_failure(result.returncode, result.stderr, identity)
            self.assertEqual((root / 'required-ran').read_text(), 'yes')
            self.assertFalse((root / 'other-ran').exists())
            self.assertFalse((root / 'main-ran').exists())


if __name__ == '__main__':
    unittest.main()
