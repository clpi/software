"""Regression coverage for test-fixture isolation, never production policy."""
import concurrent.futures
import importlib.util
import os
import pathlib
import subprocess
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('review_client', ROOT / 'tests/server/check.py')
CLIENT = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CLIENT)

class Review(unittest.TestCase):
    def test_parallel_clients_select_their_own_executable(self):
        original = CLIENT.BINARY
        with tempfile.TemporaryDirectory(prefix='eyes-client-choice-') as td:
            paths = []
            for label in ('first', 'second'):
                path = pathlib.Path(td) / label
                path.write_text('#!/bin/sh\nIFS= read -r line\nprintf \'%s\\n\' \'{"label":"' + label + '"}\'\nwhile IFS= read -r line; do :; done\n')
                path.chmod(0o755)
                paths.append(path)
            def invoke(path):
                client = CLIENT.Client(binary=path)
                try:
                    client.send(b'{}\n')
                    return client.recv()['label']
                finally:
                    client.close()
            with concurrent.futures.ThreadPoolExecutor(max_workers=2) as workers:
                self.assertEqual(list(workers.map(invoke, paths)), ['first', 'second'])
        self.assertEqual(CLIENT.BINARY, original)

class Interposer(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temporary = tempfile.TemporaryDirectory(prefix='eyes-interposer-')
        cls.root = pathlib.Path(cls.temporary.name)
        cls.library = cls.root / 'probe.so'
        subprocess.run(['cc','-shared','-fPIC','-O2','-std=c11','-Wall','-Wextra','-Werror',str(ROOT/'tests/server/reconcile.c'),'-ldl','-lX11','-o',str(cls.library)],check=True,timeout=30)
        source = cls.root / 'probe.c'
        source.write_text('#define _POSIX_C_SOURCE 200809L\n#include <X11/Xlib.h>\n#include <stdlib.h>\nint main(int argc,char**argv){(void)argv;if(argc>1){if(setenv("EYES_TEST_EDGE","disabled",1))return 2;return XKeysymToKeycode(NULL,65505)==0?0:3;}return 0;}\n')
        cls.binary = cls.root / 'probe'
        subprocess.run(['cc','-std=c11','-O2','-Wall','-Wextra','-Werror',str(source),'-lX11','-o',str(cls.binary)],check=True,timeout=30)
    @classmethod
    def tearDownClass(cls):
        cls.temporary.cleanup()
    def runprobe(self, extra, args=(), descriptors=()):
        return subprocess.run([str(self.binary),*args],env={**os.environ,'LD_PRELOAD':str(self.library),**extra},pass_fds=descriptors,capture_output=True,timeout=3)
    def test_bad_descriptors_refuse_before_execution(self):
        for value in ('', 'invalid', '0', '2', '-1', ' 5', '5junk', '9999999999999999999999999'):
            with self.subTest(value=value):
                result = self.runprobe({'EYES_TEST_EDGE':'held','EYES_TEST_NOTIFY':value,'EYES_TEST_RESUME':value})
                self.assertEqual(result.returncode,78,'invalid descriptor was not rejected at ingress')
                self.assertIn(b'invalid test descriptor',result.stderr)
    def test_closed_descriptors_refuse(self):
        result = self.runprobe({'EYES_TEST_EDGE':'held','EYES_TEST_NOTIFY':'2000000','EYES_TEST_RESUME':'2000001'})
        self.assertEqual(result.returncode,78)
    def test_valid_pipes_and_direction(self):
        nr,nw=os.pipe();rr,rw=os.pipe()
        try:
            env={'EYES_TEST_EDGE':'held','EYES_TEST_NOTIFY':str(nw),'EYES_TEST_RESUME':str(rr)}
            self.assertEqual(self.runprobe(env,descriptors=(nw,rr)).returncode,0)
            env.update(EYES_TEST_NOTIFY=str(nr),EYES_TEST_RESUME=str(rw))
            self.assertEqual(self.runprobe(env,descriptors=(nr,rw)).returncode,78)
        finally:
            for fd in (nr,nw,rr,rw):os.close(fd)
    def test_mode_is_fixed_at_library_initialization(self):
        result=self.runprobe({'EYES_TEST_EDGE':'shift'},args=('change-environment',))
        self.assertEqual(result.returncode,0,'interposed calls reread mutable environment')

if __name__=='__main__':unittest.main(verbosity=2)
