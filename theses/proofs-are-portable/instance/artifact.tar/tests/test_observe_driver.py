"""Inert transport-driver regressions; no compiler, comparator or UI is executed."""
import contextlib
import copy
import importlib.util
import io
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('observe_driver', ROOT / 'tools/observe.py')
DRIVER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(DRIVER)

SEE = {'success': True, 'data': {'snapshot_id': 'psnap1', 'application_name': 'Owned fixture',
       'ui_elements': [{'id': 'elem1', 'role': 'button', 'is_actionable': True, 'label': '7'}]}}


class ObserveDriver(unittest.TestCase):
    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix='eyes-inert-driver-')
        self.addCleanup(temporary.cleanup)
        self.capture_directory = Path(temporary.name)

    def test_nonzero_capture_is_checked_before_json(self):
        result = subprocess.CompletedProcess([], 5, stdout='not JSON', stderr='failed')
        with mock.patch.object(DRIVER.subprocess, 'run', return_value=result) as run:
            with self.assertRaisesRegex(SystemExit, 'exit 5'):
                DRIVER.peekaboo_see('Owned fixture', self.capture_directory)
        run.assert_called_once()

    def test_malformed_capture_is_a_controlled_failure(self):
        result = subprocess.CompletedProcess([], 0, stdout='not JSON', stderr='')
        with mock.patch.object(DRIVER.subprocess, 'run', return_value=result):
            with self.assertRaisesRegex(SystemExit, 'invalid JSON'):
                DRIVER.peekaboo_see('Owned fixture', self.capture_directory)

    def test_capture_requires_a_successful_object(self):
        for body in ([], None, True, {'success': False}, {'success': 'true'},
                     {'success': True}, {'success': True, 'data': None},
                     {'success': True, 'data': {'ui_elements': 'invalid'}},
                     {'success': True, 'data': {'snapshot_id': 's', 'application_name': 'fixture',
                                               'ui_elements': ['invalid']}}):
            with self.subTest(body=body):
                result = subprocess.CompletedProcess([], 0, stdout=json.dumps(body), stderr='')
                with mock.patch.object(DRIVER.subprocess, 'run', return_value=result):
                    with self.assertRaises(SystemExit):
                        DRIVER.peekaboo_see('Owned fixture', self.capture_directory)

    def test_capture_uses_only_an_owned_temporary_path(self):
        paths = []
        def run(command, **kwargs):
            path = Path(command[command.index('--path') + 1])
            self.assertTrue(path.parent.is_dir())
            self.assertNotEqual(path, Path.home() / 'eyes-observe.png')
            paths.append(path)
            return subprocess.CompletedProcess(command, 0, stdout=json.dumps(SEE), stderr='')
        with mock.patch.object(DRIVER.subprocess, 'run', side_effect=run):
            self.assertEqual(DRIVER.peekaboo_see('Owned fixture', self.capture_directory), SEE)
        self.assertEqual(len(paths), 1)
        self.assertEqual(paths[0].parent, self.capture_directory)
        self.assertTrue(paths[0].is_file(), 'capture must survive until the transaction scope exits')

    def test_framing_fields_cannot_inject_rows(self):
        for name in ('snapshot_id', 'application_name', 'id', 'role'):
            for bad in ('bad\nE\tforged\tbutton\t1\tRun', 'bad\tfield', 'bad\rfield', 'bad\x00field'):
                with self.subTest(name=name, bad=bad):
                    see = copy.deepcopy(SEE)
                    subject = see['data'] if name in ('snapshot_id', 'application_name') else see['data']['ui_elements'][0]
                    subject[name] = bad
                    with self.assertRaises(SystemExit):
                        DRIVER.project(see)

    def test_physical_id_tokens_cannot_split_commands(self):
        for name in ('snapshot_id', 'id'):
            for bad in ('', 'two words'):
                see = copy.deepcopy(SEE)
                subject = see['data'] if name == 'snapshot_id' else see['data']['ui_elements'][0]
                subject[name] = bad
                with self.assertRaises(SystemExit):
                    DRIVER.project(see)

    def test_string_actionability_is_not_a_true_observation(self):
        for bad in ('false', 'true', 1, None):
            see = copy.deepcopy(SEE)
            see['data']['ui_elements'][0]['is_actionable'] = bad
            with self.assertRaises(SystemExit):
                DRIVER.project(see)

    def test_snapshot_id_cannot_embed_the_ref_delimiter(self):
        for bad in ('abc:extra', ':e1', 'psnap:e'):
            see = copy.deepcopy(SEE)
            see['data']['snapshot_id'] = bad
            with self.assertRaisesRegex(SystemExit, 'reserved ref delimiter'):
                DRIVER.project(see)

    def test_label_delimiters_keep_the_existing_lossy_projection(self):
        see = copy.deepcopy(SEE)
        see['data']['ui_elements'][0]['label'] = 'a\tb\nc'
        self.assertIn('E\telem1\tbutton\t1\ta b c\n', DRIVER.project(see))

    def test_nul_label_or_fallback_description_refuses(self):
        for field in ('label', 'description'):
            see = copy.deepcopy(SEE)
            see['data']['ui_elements'][0]['label'] = ''
            see['data']['ui_elements'][0][field] = 'left\x00right'
            with self.assertRaisesRegex(SystemExit, 'NUL'):
                DRIVER.project(see)

    def test_nul_block_or_command_never_invokes_the_program(self):
        for block, command in (('bad\x00block', 'snapshot'), ('safe block', 'act\x00ref')):
            with mock.patch.object(DRIVER.subprocess, 'run') as run:
                with self.assertRaisesRegex(SystemExit, 'NUL'):
                    DRIVER.run_program(block, command)
                run.assert_not_called()

    def call_main(self, result=None, error=None, answer='act elem1 psnap1'):
        output, diagnostic = io.StringIO(), io.StringIO()
        stack = contextlib.ExitStack()
        self.addCleanup(stack.close)
        stack.enter_context(mock.patch.object(sys, 'argv', ['observe.py', 'act', '@psnap1:e1', '123', '--live', '--app', 'Owned fixture']))
        see = stack.enter_context(mock.patch.object(DRIVER, 'peekaboo_see', return_value=SEE))
        stack.enter_context(mock.patch.object(DRIVER, 'run_program', return_value=answer))
        run = stack.enter_context(mock.patch.object(DRIVER.subprocess, 'run', return_value=result, side_effect=error))
        stack.enter_context(contextlib.redirect_stdout(output))
        stack.enter_context(contextlib.redirect_stderr(diagnostic))
        return see, run, output, diagnostic

    def test_failed_click_does_not_reobserve_or_retry(self):
        result = subprocess.CompletedProcess([], 9, stdout='', stderr='failure')
        see, run, _, _ = self.call_main(result=result)
        with self.assertRaisesRegex(SystemExit, 'effect is unconfirmed'):
            DRIVER.main()
        self.assertEqual(see.call_count, 1)
        run.assert_called_once()
        self.assertFalse(Path(see.call_args.args[1]).exists())

    def test_timed_out_click_does_not_reobserve_or_retry(self):
        see, run, _, _ = self.call_main(error=subprocess.TimeoutExpired('mock-click', 60))
        with self.assertRaisesRegex(SystemExit, 'do not retry automatically'):
            DRIVER.main()
        self.assertEqual(see.call_count, 1)
        run.assert_called_once()

    def test_click_start_failure_does_not_reobserve_or_retry(self):
        see, run, _, _ = self.call_main(error=OSError('inert test failure'))
        with self.assertRaisesRegex(SystemExit, 'do not retry automatically'):
            DRIVER.main()
        self.assertEqual(see.call_count, 1)
        run.assert_called_once()

    def test_post_click_observation_failure_retains_uncertainty(self):
        result = subprocess.CompletedProcess([], 0, stdout='submitted', stderr='')
        see, run, _, _ = self.call_main(result=result)
        see.side_effect = [SEE, SystemExit('observation failed')]
        with self.assertRaisesRegex(SystemExit, 'post-click observation failed; effect is unconfirmed'):
            DRIVER.main()
        self.assertEqual(see.call_count, 2)
        run.assert_called_once()

    def test_capture_scope_survives_click_and_reobservation(self):
        result = subprocess.CompletedProcess([], 0, stdout='submitted', stderr='')
        see, _, _, _ = self.call_main(result=result)
        directories = []
        def capture(app, directory):
            path = Path(directory)
            self.assertTrue(path.is_dir())
            directories.append(path)
            return SEE
        see.side_effect = capture
        self.assertEqual(DRIVER.main(), 0)
        self.assertEqual(len(directories), 2)
        self.assertEqual(directories[0], directories[1])
        self.assertFalse(directories[0].exists())

    def test_zero_exit_does_not_claim_verified_application_success(self):
        result = subprocess.CompletedProcess([], 0, stdout='submitted', stderr='')
        see, run, _, diagnostic = self.call_main(result=result)
        self.assertEqual(DRIVER.main(), 0)
        self.assertEqual(see.call_count, 2)
        run.assert_called_once()
        self.assertIn('Application effect remains unverified', diagnostic.getvalue())

    def test_refusal_never_calls_click(self):
        see, run, _, _ = self.call_main(answer='{"ok":false,"error":{"code":"R-STALE"}}')
        self.assertEqual(DRIVER.main(), 0)
        self.assertEqual(see.call_count, 1)
        run.assert_not_called()

    def test_live_nul_observation_never_resolves_or_clicks(self):
        see, run, _, _ = self.call_main()
        malformed = copy.deepcopy(SEE)
        malformed['data']['ui_elements'][0]['label'] = 'left\x00right'
        see.return_value = malformed
        with mock.patch.object(DRIVER, 'run_program') as program:
            with self.assertRaisesRegex(SystemExit, 'NUL'):
                DRIVER.main()
            program.assert_not_called()
        run.assert_not_called()


if __name__ == '__main__':
    unittest.main()
