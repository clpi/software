"""Version-specific metadata rejection is a protocol boundary, not authorization."""
import pathlib,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from check import Client
class Metadata(unittest.TestCase):
    def test_modern_client_identity_shape(self):
        for info in ['bad',False,[],{}, {'name':'agent'}, {'name':False,'version':'1'}]:
            with self.subTest(info=info):
                c=Client()
                try:
                    meta={'io.modelcontextprotocol/protocolVersion':'2026-07-28','io.modelcontextprotocol/clientCapabilities':{},'io.modelcontextprotocol/clientInfo':info}
                    r=c.call('server/discover',{'_meta':meta});self.assertIn('error',r,'malformed client identity accepted')
                finally:c.close()
    def test_valid_optional_identity(self):
        for info in [None,{'name':'agent','version':'1'}]:
            c=Client()
            try:
                meta={'io.modelcontextprotocol/protocolVersion':'2026-07-28','io.modelcontextprotocol/clientCapabilities':{}}
                if info is not None:meta['io.modelcontextprotocol/clientInfo']=info
                self.assertIn('result',c.call('server/discover',{'_meta':meta}))
            finally:c.close()
if __name__=='__main__':unittest.main(verbosity=2)
