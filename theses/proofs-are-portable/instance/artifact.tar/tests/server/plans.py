"""Native plan validation and execution against a real, owned desktop."""
import json,os,pathlib,sys,unittest,time
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from interaction import Interaction
from check import Client

class Plans(Interaction):
    def perform(self,steps,**extra):
        args={'context':self.initial['context'],'sequence':self.sequence,'steps':steps,**extra}
        return self.client.call('tools/call',{'name':'perform','arguments':args})
    def step(self,name,**arguments):return {'name':name,'arguments':arguments}
    def accepted(self,r):
        self.assertIn('result',r,'native perform missing');self.assertFalse(r['result'].get('isError'),r)
        return r['result']
    def refused(self,r):self.assertTrue('error' in r or r.get('result',{}).get('isError'),r)
    def ok(self):
        self.action('type',{'text':'ok'})
        self.until(lambda r:r.get('text')==list(b'ok') and r['keys']==r['ups'])
    def test_plan_complete(self):
        steps=[self.step('move',x=80,y=90),self.step('type',text='Hello, Idol!'),self.step('chord',code=[self.ready['ctrl'],self.ready['a']]),self.step('drag',x=210,y=180,button=1)]
        r=self.accepted(self.perform(steps,capture={'x':30,'y':30,'width':32,'height':32}))
        s=r['structuredContent'];self.assertEqual((s['submittedSteps'],s['nextSequence']),(4,5));self.assertFalse(s['atomic'])
        self.until(lambda r:r.get('text')==list(b'Hello, Idol!')+[1] and r['keys']==r['ups'] and r.get('drag',0)>=1 and r['presses']==r['releases']==1)
        import base64,io
        from PIL import Image
        image=next(c for c in r['content'] if c['type']=='image')
        pixels=Image.open(io.BytesIO(base64.b64decode(image['data'],validate=True)))
        self.assertEqual(pixels.size,(32,32));self.assertEqual(set(pixels.get_flattened_data()),{(51,102,153)})
        self.sequence=5
        restored=self.action('move',{'x':self.initial['x'],'y':self.initial['y']})['structuredContent']
        self.assertEqual((restored['x'],restored['y']),(self.initial['x'],self.initial['y']))
    def test_plan_late_invalid_no_prefix(self):
        self.refused(self.perform([self.step('type',text='leak'),self.step('move',x=640,y=0)]));self.ok()
    def test_plan_late_unmapped_no_prefix(self):
        self.refused(self.perform([self.step('type',text='leak'),self.step('type',text='prefix😀')]));self.ok()
    def test_plan_bad_capture_no_prefix(self):
        self.refused(self.perform([self.step('type',text='leak')],capture={'x':0,'y':0,'width':513,'height':1}));self.ok()
    def test_plan_scope(self):
        self.refused(self.perform([self.step('type',text='leak')],context=0));self.ok()
    def test_plan_replay(self):
        steps=[self.step('type',text='once')];r=self.accepted(self.perform(steps));self.refused(self.perform(steps))
        self.sequence=r['structuredContent']['nextSequence'];self.action('type',{'text':'!'})
        self.until(lambda r:r.get('text')==list(b'once!') and r['keys']==r['ups'])
    def test_plan_structure(self):
        bad=[[],[self.step('move',x=80,y=90)]*33,[self.step('perform',steps=[])],[self.step('close')],[self.step('observe')],[self.step('key',code=38,context=1)],[self.step('key',code=38,sequence=1)],[{'name':'key','arguments':[]}],[{'name':'key','arguments':{'code':38},'extra':True}]]
        for steps in bad:self.refused(self.perform(steps))
        self.ok()
    def test_plan_duplicates(self):
        for fields in ['"steps":[],"steps":[]','"steps":[{"name":"key","name":"type","arguments":{"code":38,"text":"x"}}]','"steps":[{"name":"key","arguments":{"code":38,"code":39}}]','"steps":[],"capture":{},"capture":{}']:
            raw='{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"name":"perform","arguments":{"context":%d,"sequence":1,%s}}}'%(self.initial['context'],fields)
            self.client.send(raw.encode()+b'\n');self.refused(self.client.recv())
        self.ok()
    def test_plan_capacity(self):
        r=self.accepted(self.perform([self.step('move',x=80+i,y=90+i) for i in range(32)]))['structuredContent']
        self.assertEqual((r['submittedSteps'],r['nextSequence'],r['x'],r['y']),(32,33,111,121));self.sequence=33
    def test_plan_readonly(self):
        self.client.close();self.client=Client({**self.env,'IDOL_EYES_READONLY':'1'});self.client.init();self.initial=self.tool('observe',{})['structuredContent']
        self.refused(self.perform([self.step('type',text='leak')]))
    def test_plan_revoked(self):
        self.tool('close',{});self.refused(self.perform([self.step('type',text='leak')]))
    def test_plan_expired(self):
        self.client.close();self.client=Client({**self.env,'IDOL_EYES_SECONDS':'1'});self.client.init();self.initial=self.tool('observe',{})['structuredContent'];time.sleep(1.1)
        self.refused(self.perform([self.step('type',text='leak')]))

    def instrument(self,fault=None):
        import subprocess
        library=pathlib.Path(self.temp.name)/'probe.so'
        subprocess.run(['cc','-shared','-fPIC','-O2','-std=c11','-Wall','-Wextra','-Werror',str(pathlib.Path(__file__).with_name('probe.c')),'-ldl','-o',str(library)],check=True)
        self.client.close();self.counts=pathlib.Path(self.temp.name)/'counts.json'
        env={**self.env,'LD_PRELOAD':str(library),'EYES_TEST_COUNTS':str(self.counts)}
        if fault:env['EYES_TEST_FAULT']=fault
        self.client=Client(env);self.client.init();self.initial=self.tool('observe',{})['structuredContent'];self.sequence=1
    def test_plan_roundtrips(self):
        self.instrument();before=json.loads(self.counts.read_text())
        r=self.accepted(self.perform([self.step('move',x=80+i,y=90+i) for i in range(16)]))
        after=json.loads(self.counts.read_text());delta={k:after[k]-before[k] for k in before}
        self.assertEqual(delta,{'pointer':17,'keymap':16,'sync':0});self.assertEqual((r['structuredContent']['x'],r['structuredContent']['y']),(95,105));self.sequence=17
    def test_plan_drift_stops_dependents(self):
        self.instrument('drift');r=self.perform([self.step('move',x=80,y=90),self.step('type',text='leak')]);self.refused(r)
        state=r['result']['structuredContent'];self.assertEqual((state['submittedSteps'],state['nextSequence']),(1,2));self.sequence=2;self.ok()
    def test_plan_last_drift_is_not_confirmation(self):
        self.instrument('drift');r=self.perform([self.step('move',x=80,y=90)]);self.refused(r)
        self.assertEqual(r['result']['structuredContent']['submittedSteps'],1);self.assertNotIn('x',r['result']['structuredContent'])
    def test_plan_uncertain_prefix(self):
        self.instrument('button');r=self.perform([self.step('type',text='a'),self.step('click',button=1),self.step('type',text='leak')]);self.refused(r)
        state=r['result']['structuredContent'];self.assertEqual((state['submittedSteps'],state['failedStep'],state['nextSequence']),(2,2,3))
        self.sequence=3;self.action('type',{'text':'!'});self.until(lambda r:r.get('text')==list(b'a!') and r['keys']==r['ups'])

if __name__=='__main__':
    suite=unittest.TestSuite(Plans(n) for n in (sys.argv[1:] or unittest.defaultTestLoader.getTestCaseNames(Plans)) if n.startswith('test_plan_'))
    r=unittest.TextTestRunner(verbosity=2).run(suite);sys.exit(not r.wasSuccessful())

