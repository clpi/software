#define _GNU_SOURCE
#include <X11/Xlib.h>
#include <X11/XKBlib.h>
#include <dlfcn.h>
#include <stdio.h>
static unsigned emitted,interleaved;
KeySym XkbKeycodeToKeysym(Display*d,KeyCode c,int g,int l){
    static KeySym(*actual)(Display*,KeyCode,int,int);
    if(!actual)actual=dlsym(RTLD_NEXT,"XkbKeycodeToKeysym");
    if(emitted)interleaved++;
    return actual(d,c,g,l);
}
int XTestFakeKeyEvent(Display*d,unsigned int c,Bool down,unsigned long delay){
    static int(*actual)(Display*,unsigned int,Bool,unsigned long);
    if(!actual)actual=dlsym(RTLD_NEXT,"XTestFakeKeyEvent");
    emitted++;
    return actual(d,c,down,delay);
}
__attribute__((destructor)) static void report(void){fprintf(stderr,"query-phase emitted=%u interleaved=%u\n",emitted,interleaved);}
