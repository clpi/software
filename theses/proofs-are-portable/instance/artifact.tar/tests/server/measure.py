"""Diagnostic paired end-to-end measurements; never a competitor or physical-optimum claim."""
import hashlib,json,os,pathlib,platform,random,statistics,sys,time
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from interaction import Interaction
from check import BINARY as EYES
out=pathlib.Path(os.environ['EVIDENCE']).resolve();out.mkdir(parents=True,exist_ok=False,mode=0o700)
fixture=Interaction('test_type_chord_drag_and_restoration');rows=[]
def summary(ns):
    a=sorted(ns);return {'samples':len(a),'medianUs':statistics.median(a)/1000,'p95Us':a[min(len(a)-1,int(len(a)*.95))]/1000,'p99Us':a[min(len(a)-1,int(len(a)*.99))]/1000}
try:
    fixture.setUp();fixture.action('move',{'x':80,'y':90})
    for name in ['ping','move','capture64']:
        values=[]
        for i in range(40):
            start=time.perf_counter_ns()
            if name=='ping':result=fixture.client.call('ping')
            elif name=='move':result=fixture.action('move',{'x':80+i%30,'y':90+i%30})
            else:result=fixture.tool('capture',{'x':30,'y':30,'width':64,'height':64})
            stop=time.perf_counter_ns()
            if name=='ping':assert result['result']=={}
            if name=='move':assert result['structuredContent']['x']==80+i%30
            if name=='capture64':assert result['content'][0]['mimeType']=='image/png'
            if i>=8:values.append(stop-start)
        rows.append({'workload':name,'boundary':'request serialized/sent to complete MCP response received; pointer is independently queried by server; image decoding not timed','ns':values,'summary':summary(values)})
    total=0;rng=random.Random(20261101);paired=[]
    for round in range(25):
        order=['type','key'];rng.shuffle(order);pair={'round':round,'order':order}
        for mode in order:
            target=total+16;start=time.perf_counter_ns()
            if mode=='type':fixture.action('type',{'text':'a'*16})
            else:
                for _ in range(16):fixture.action('key',{'code':fixture.ready['a']})
            actual=fixture.until(lambda r:len(r.get('text',[]))>=target and r['keys']==r['ups'])
            stop=time.perf_counter_ns();assert actual['text']==[97]*target
            total=target;pair[mode+'Ns']=stop-start
        if round>=4:paired.append(pair)
    report={'schema':'idol.eyes.measurement.v1','scope':'local isolated Xvfb, Linux x86-64, shared container; diagnostic samples, not Peekaboo/CUA/ChatGPT comparison or a physical optimum','binarySha256':hashlib.sha256(EYES.read_bytes()).hexdigest(),'binaryBytes':EYES.stat().st_size,'platform':platform.platform(),'clock':'perf_counter_ns','rows':rows,'typing':{'semanticWork':'16 lowercase a characters observed exactly by an independent X11 application','oneCall':summary([p['typeNs'] for p in paired]),'sixteenCalls':summary([p['keyNs'] for p in paired]),'pairs':paired},'processStatus':pathlib.Path('/proc/'+str(fixture.client.p.pid)+'/status').read_text().split('VmPeak:')[1].split('Threads:')[0]}
    (out/'measurement.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:v for k,v in report.items() if k not in ['rows','typing','processStatus']},indent=2));print(json.dumps([(r['workload'],r['summary']) for r in rows],indent=2));print(report['typing']['oneCall'],report['typing']['sixteenCalls'])
finally:
    if hasattr(fixture,'client'):fixture.tearDown()
