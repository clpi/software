"""Exercise the actual compiled Idol server against an owned Xvfb app, not mocked APIs."""
import base64,io,json,os,pathlib,select,subprocess,sys,tempfile,time,unittest
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from check import Client,ROOT,BINARY
class Desktop(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp=tempfile.TemporaryDirectory(prefix='eyes-desktop-');out=pathlib.Path(cls.temp.name)
        subprocess.run(['cc','-std=c11','-O2','-Wall','-Wextra','-Werror',str(ROOT/'tests/server/fixture.c'),'-lX11','-o',str(out/'fixture')],check=True)
        cls.x=subprocess.Popen(['Xvfb','-displayfd','1','-screen','0','640x480x24','-nolisten','tcp'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        if not select.select([cls.x.stdout],[],[],5)[0]:raise RuntimeError('Xvfb startup timeout')
        number=cls.x.stdout.readline().strip().decode();assert number.isdigit(),number
        cls.env=os.environ.copy();cls.env.update(DISPLAY=':'+number,IDOL_EYES_X11='allow')
        cls.app=subprocess.Popen([str(out/'fixture')],env=cls.env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)
        cls.buffer=b'';cls.events=[];cls.ready=cls.event();assert cls.ready.get('ready'),cls.ready
    @classmethod
    def event(cls,timeout=3):
        end=time.monotonic()+timeout
        while b'\n' not in cls.buffer:
            if not select.select([cls.app.stdout],[],[],max(0,end-time.monotonic()))[0]:raise TimeoutError('fixture event')
            cls.buffer+=os.read(cls.app.stdout.fileno(),65536)
        line,cls.buffer=cls.buffer.split(b'\n',1);r=json.loads(line);cls.events.append(r);return r
    @classmethod
    def tearDownClass(cls):
        cls.app.terminate();cls.app.wait(timeout=3);cls.x.terminate();cls.x.wait(timeout=3)
        cls.app.stdout.close();cls.app.stderr.close();cls.x.stdout.close();cls.x.stderr.close();cls.temp.cleanup()
    def test_real_effects_and_replay(self):
        c=Client(self.env)
        try:
            c.init()
            denied=Client({**self.env,'IDOL_EYES_X11':'deny'})
            try:
                denied.init(); self.assertTrue(denied.call('tools/call',{'name':'observe','arguments':{}})['result'].get('isError'))
            finally:denied.close()
            def tool(name,args):
                if name not in ('observe','capture','close') and 'context' not in args: args={**args,'context':obs['context']}
                return c.call('tools/call',{'name':name,'arguments':args})
            obs=tool('observe',{})['result']['structuredContent'];self.assertEqual((obs['width'],obs['height']),(640,480))
            self.assertTrue(tool('click',{'sequence':1,'button':1,'context':0})['result'].get('isError'))
            self.assertIn('error',tool('click',{'sequence':1,'button':1,'unexpected':True}))
            self.assertIn('error',tool('move',{'sequence':1,'x':640,'y':90}))
            moved=tool('move',{'sequence':1.0,'x':80.0,'y':90.0})['result']['structuredContent'];self.assertEqual((moved['x'],moved['y']),(80,90))
            self.assertIn('error',tool('click',{'sequence':3,'button':1}))
            click=tool('click',{'sequence':2,'button':1})['result'];self.assertEqual(click['structuredContent']['outcome'],'submitted')
            duplicate=tool('click',{'sequence':2,'button':1})['result'];self.assertTrue(duplicate['isError'])
            self.assertIn('error',tool('click',{'sequence':2,'button':2}))
            tool('key',{'sequence':3,'code':self.ready['keycode']})
            tool('scroll',{'sequence':4,'direction':4,'count':3})
            seen=None
            for _ in range(20):
                try: seen=self.event()
                except TimeoutError: self.fail("required application event sequence was not observed")
                if seen.get('releases')==4 and seen.get('ups')==1:break
            self.assertEqual(seen,{'clicks':1,'releases':4,'keys':1,'ups':1,'scroll':3})
            image=tool('capture',{'x':30,'y':30,'width':64,'height':64})['result']['content'][0]
            self.assertEqual(image['mimeType'],'image/png')
            from PIL import Image
            pixels=Image.open(io.BytesIO(base64.b64decode(image['data'],validate=True)))
            self.assertEqual(pixels.size,(64,64)); self.assertEqual(set(pixels.get_flattened_data()),{(51,102,153)})
            self.assertIn('error',tool('capture',{'x':0,'y':0,'width':513,'height':64}))
            self.assertIn('error',tool('move',{'sequence':5,'x':640,'y':2}))
            restored=tool('move',{'sequence':5,'x':obs['x'],'y':obs['y']})['result']['structuredContent']
            self.assertEqual((restored['x'],restored['y']),(obs['x'],obs['y']))
            self.assertIn('result',tool('close',{}))
            self.assertTrue(tool('observe',{})['result'].get('isError'))
            self.assertTrue(tool('click',{'sequence':6,'button':1})['result'].get('isError'))
            successor=Client(self.env)
            try:
                successor.init()
                self.assertTrue(successor.call('tools/call',{'name':'click','arguments':{'context':obs['context'],'sequence':1,'button':1}})['result'].get('isError'))
            finally:successor.close()
        finally:c.close()
if __name__=='__main__':unittest.main(verbosity=2)
