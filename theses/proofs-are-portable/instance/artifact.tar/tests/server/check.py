"""Real subprocess/desktop tests; never the production dispatcher."""
import json, os, pathlib, select, subprocess, time, unittest
ROOT=pathlib.Path(__file__).resolve().parents[2]
BINARY=pathlib.Path(os.environ.get('EYES', ROOT/'.build/eyes')).resolve()
class Client:
    def __init__(self, env=None, pass_fds=(), binary=None):
        self.p=subprocess.Popen([str(BINARY if binary is None else binary)], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=os.environ.copy() if env is None else env, bufsize=0, pass_fds=pass_fds)
        self.buf=b''
    def send(self, value):
        raw=value if isinstance(value,bytes) else json.dumps(value,separators=(',',':'),ensure_ascii=False).encode()+b'\n'
        self.p.stdin.write(raw)
    def recv(self, timeout=3):
        end=time.monotonic()+timeout
        while b'\n' not in self.buf:
            if not select.select([self.p.stdout],[],[],max(0,end-time.monotonic()))[0]: raise TimeoutError('response deadline')
            chunk=os.read(self.p.stdout.fileno(),65536)
            if not chunk: raise RuntimeError('server ended: '+self.p.stderr.read().decode())
            self.buf+=chunk
        line,self.buf=self.buf.split(b'\n',1);return json.loads(line)
    def call(self, method, params=None, identity=1):
        msg={'jsonrpc':'2.0','id':identity,'method':method}
        if params is not None:msg['params']=params
        self.send(msg);return self.recv()
    def init(self):
        r=self.call('initialize',{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'test','version':'1'}})
        assert r['result']['protocolVersion']=='2025-11-25',r
        self.send({'jsonrpc':'2.0','method':'notifications/initialized'})
    def close(self):
        if self.p.poll() is None:
            self.p.stdin.close()
            try:self.p.wait(timeout=2)
            except subprocess.TimeoutExpired:
                self.p.kill();self.p.wait();raise RuntimeError('server did not terminate on EOF')
        error=self.p.stderr.read()
        self.p.stdout.close();self.p.stderr.close()
        if error or self.p.returncode not in (0,74):raise RuntimeError(f'server exit {self.p.returncode}: {error.decode(errors="replace")}')
class Protocol(unittest.TestCase):
    def setUp(self):self.c=Client()
    def tearDown(self):self.c.close()
    def test_lifecycle(self):
        self.c.init();self.assertEqual(self.c.call('ping')['result'],{})
        names={t['name'] for t in self.c.call('tools/list')['result']['tools']}
        self.assertEqual(names,{'observe','move','click','key','scroll','capture','close','type','chord','drag','perform'})
    def test_gate_before_initialize(self):self.assertIn('error',self.c.call('tools/list'))
    def test_notifications_are_silent(self):
        self.c.send({'jsonrpc':'2.0','method':'ping'})
        self.assertFalse(select.select([self.c.p.stdout],[],[],0.05)[0])
        self.c.init();self.assertEqual(self.c.call('ping',identity='live')['id'],'live')
    def test_exact_id(self):
        self.c.init()
        for x in [0,-9,2**63,2**80,'x"\\\n😀']:
            self.assertEqual(self.c.call('ping',identity=x)['id'],x)
    def test_stream_frames_and_fragmentation(self):
        self.c.init()
        raw=b'{"jsonrpc":"2.0","id":2,"method":"ping"}\n'
        for c in raw:self.c.send(bytes([c]))
        self.assertEqual(self.c.recv()['id'],2)
        self.c.send(raw*10)
        for _ in range(10):self.assertEqual(self.c.recv()['id'],2)
    def test_malformed_and_recovery(self):
        for raw in [b'{}',b'{"id":1}',b'{',b'[]',b'{"jsonrpc":"2.0","id":1,"id":2,"method":"ping"}']:
            self.c.send(raw+b'\n');self.assertIn('error',self.c.recv())
        self.c.init();self.assertIn('result',self.c.call('ping'))
    def test_unknown_and_injected_names(self):
        self.c.init()
        self.assertEqual(self.c.call('wrong',{'method':'tools/list'})['error']['code'],-32601)
        self.assertIn('error',self.c.call('tools/call',{'name':'nope','arguments':{}}))
    def test_default_denial(self):
        self.c.init();r=self.c.call('tools/call',{'name':'observe','arguments':{}})
        self.assertTrue(r['result']['isError'])
    def test_oversize_recovers(self):
        self.c.send(b' '*65537+b'\n');self.assertIn('error',self.c.recv())
        self.c.init();self.assertIn('result',self.c.call('ping'))
    def test_modern(self):
        meta={'io.modelcontextprotocol/protocolVersion':'2026-07-28','io.modelcontextprotocol/clientCapabilities':{}}
        r=self.c.call('server/discover',{'_meta':meta})
        self.assertIn('2026-07-28',r['result']['supportedVersions'])
        self.assertEqual(r['result']['resultType'],'complete')
        self.assertIn('tools',self.c.call('tools/list',{'_meta':meta})['result'])
        self.assertEqual(self.c.call('ping',{'_meta':meta})['result']['resultType'],'complete')
        wrong={**meta,'io.modelcontextprotocol/protocolVersion':'2099-01-01'}
        r=self.c.call('tools/list',{'_meta':wrong})
        self.assertEqual(r['error']['code'],-32022)
        self.assertEqual(r['error']['data']['requested'],'2099-01-01')
        self.assertIn('2026-07-28',r['error']['data']['supported'])
        self.assertEqual(self.c.call('tools/list',{'_meta':{'io.modelcontextprotocol/protocolVersion':'2026-07-28'}})['error']['code'],-32602)
    def test_eof(self):
        self.c.p.stdin.close();self.assertEqual(self.c.p.wait(timeout=2),0)
    def test_truncated_eof_is_failure(self):
        self.c.send(b'{"jsonrpc"');self.c.p.stdin.close();self.assertNotEqual(self.c.p.wait(timeout=2),0)
if __name__=='__main__':unittest.main(verbosity=2)
