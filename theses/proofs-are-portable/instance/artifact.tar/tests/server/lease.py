"""Actual process-local launcher scope and monotonic expiry; not graph or remote grants."""
import pathlib,sys,time,unittest
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from check import Client
import desktop
class Lease(unittest.TestCase):
    setUpClass=classmethod(desktop.Desktop.setUpClass.__func__)
    tearDownClass=classmethod(desktop.Desktop.tearDownClass.__func__)
    event=classmethod(desktop.Desktop.event.__func__)
    def test_missing_grant_denies_even_with_live_display(self):
        environment=self.env.copy();environment.pop('IDOL_EYES_X11',None)
        c=Client(environment)
        try:
            c.init();self.assertTrue(c.call('tools/call',{'name':'observe','arguments':{}})['result'].get('isError'),'missing launcher grant was treated as permission')
        finally:c.close()
    def test_operator_can_shorten_lease(self):
        c=Client({**self.env,'IDOL_EYES_SECONDS':'1'})
        try:
            c.init();self.assertFalse(c.call('tools/call',{'name':'observe','arguments':{}})['result'].get('isError'))
            time.sleep(1.1)
            self.assertTrue(c.call('tools/call',{'name':'observe','arguments':{}})['result'].get('isError'),'expired scope still observing')
        finally:c.close()
    def test_invalid_lease_is_denied(self):
        for value in ['0','301','-1','1e2','yes','']:
            c=Client({**self.env,'IDOL_EYES_SECONDS':value})
            try:
                c.init();self.assertTrue(c.call('tools/call',{'name':'observe','arguments':{}})['result'].get('isError'),value)
            finally:c.close()
    def test_observation_only_scope(self):
        c=Client({**self.env,'IDOL_EYES_READONLY':'1'})
        try:
            c.init();state=c.call('tools/call',{'name':'observe','arguments':{}})['result']['structuredContent']
            for name,args in [('move',{'x':80,'y':90}),('key',{'code':self.ready['keycode']}),('type',{'text':'no'}),('chord',{'code':[self.ready['keycode']]}),('drag',{'x':90,'y':90,'button':1})]:
                r=c.call('tools/call',{'name':name,'arguments':{**args,'context':state['context'],'sequence':1}})
                self.assertTrue(r['result'].get('isError'),name)
            self.assertEqual(c.call('tools/call',{'name':'capture','arguments':{'x':30,'y':30,'width':8,'height':8}})['result']['content'][0]['type'],'image')
        finally:c.close()
if __name__=='__main__':unittest.main(verbosity=2)
