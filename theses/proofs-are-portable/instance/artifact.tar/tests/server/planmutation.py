"""Require successful compilation followed by the named behavioral failure."""
import hashlib,json,os,pathlib,shutil,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parents[2]
OUT=pathlib.Path(os.environ['EVIDENCE']).resolve();OUT.mkdir(mode=0o700,parents=True,exist_ok=False)
changes=[
 ('preflight','program.id','  for index = 0, checks - 1','  for index = 0, -1',1,'test_plan_late_invalid_no_prefix'),
 ('prior-position','server.id','    if mode == 3 and (state[4] == 2 or state[4] == 10)','    if false',1,'test_plan_drift_stops_dependents'),
 ('final-position','program.id','    matched = cells[3] == state[5] and cells[4] == state[6]','    matched = true',1,'test_plan_last_drift_is_not_confirmation'),
 ('uncertain-prefix','program.id','    if result != 0 or frame[10] != 0','    if false',2,'test_plan_uncertain_prefix'),
]
report=[]
for name,file,old,new,occurrence,case in changes:
    work=OUT/name;work.mkdir()
    for folder in ('protocol','tools'):shutil.copytree(ROOT/folder,work/folder,ignore=shutil.ignore_patterns('__pycache__'))
    shutil.copytree(ROOT/'tests/server',work/'tests/server',ignore=shutil.ignore_patterns('__pycache__'))
    path=work/'protocol'/file;text=path.read_text();position=-1
    for _ in range(occurrence):
        position=text.find(old,position+1)
        if position<0:raise RuntimeError('Mutation site absent: '+name)
    path.write_text(text[:position]+new+text[position+len(old):])
    build=subprocess.run([sys.executable,'-S',str(work/'tools/server.py')],capture_output=True,timeout=90)
    (work/'build.log').write_bytes(build.stdout+build.stderr)
    if build.returncode:raise RuntimeError(name+': build failure is not behavioral evidence')
    run=subprocess.run([sys.executable,'-S',str(ROOT/'tests/server/plans.py')],env={**os.environ,'EYES':str(work/'.build/eyes')},capture_output=True,timeout=30)
    (work/'test.log').write_bytes(run.stdout+run.stderr)
    if run.returncode!=1 or b'FAILED (failures=' not in run.stderr or b'ERROR:' in run.stderr or case.encode() not in run.stderr:raise RuntimeError(name+': required assertion not established')
    report.append({'name':name,'case':case,'buildExit':0,'testExit':1,'logSha256':hashlib.sha256(run.stdout+run.stderr).hexdigest()})
    print(name,'caught',flush=True)
(OUT/'mutations.json').write_text(json.dumps(report,indent=2)+'\n')
