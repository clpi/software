"""Observe real library-call ordering; all platform calls retain actual results."""
import pathlib,subprocess,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).parent))
import interaction
from check import Client,ROOT
class Observed(Client):
    def close(self):
        if hasattr(self,'closed_result'):return self.closed_result
        if self.p.poll() is None:
            self.p.stdin.close()
            try:self.p.wait(timeout=3)
            except subprocess.TimeoutExpired:
                self.p.kill();self.p.wait();raise RuntimeError('instrumented server failed to exit')
        report=self.p.stderr.read();self.p.stdout.close();self.p.stderr.close()
        self.closed_result=(self.p.returncode,report)
        return self.closed_result
class Query(unittest.TestCase):
    def test_typing_preflights_before_first_event(self):
        target=interaction.Interaction('test_type_chord_drag_and_restoration')
        try:
            target.setUp();library=pathlib.Path(target.temp.name)/'observe.so'
            subprocess.run(['cc','-std=c11','-O2','-Wall','-Wextra','-Werror','-shared','-fPIC',str(ROOT/'tests/server/query.c'),'-ldl','-o',str(library)],check=True)
            target.client.close();target.client=Observed({**target.env,'LD_PRELOAD':str(library)});target.client.init();target.initial=target.tool('observe',{})['structuredContent'];target.sequence=1
            target.action('move',{'x':80,'y':90});target.action('type',{'text':'a'*16});target.until(lambda r:r.get('text')==[97]*16 and r['keys']==r['ups'])
            code,report=target.client.close();self.assertEqual(code,0)
            self.assertEqual(report,b'query-phase emitted=32 interleaved=0\n','keyboard-map queries were interleaved with effects')
        finally:
            if hasattr(target,'client'):target.tearDown()
if __name__=='__main__':unittest.main(verbosity=2)
