#define _GNU_SOURCE
#include <X11/Xlib.h>
#include <dlfcn.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
static unsigned pointers,keymaps,synchronizations;
static void record(void){const char *p=getenv("EYES_TEST_COUNTS");if(!p)return;FILE *f=fopen(p,"w");if(!f)abort();fprintf(f,"{\"pointer\":%u,\"keymap\":%u,\"sync\":%u}\n",pointers,keymaps,synchronizations);if(fclose(f))abort();}
Bool XQueryPointer(Display*d,Window w,Window*r,Window*c,int*x,int*y,int*rx,int*ry,unsigned*m){typedef Bool(*fn)(Display*,Window,Window*,Window*,int*,int*,int*,int*,unsigned*);fn next=(fn)dlsym(RTLD_NEXT,"XQueryPointer");if(!next)abort();Bool result=next(d,w,r,c,x,y,rx,ry,m);++pointers;record();return result;}
int XQueryKeymap(Display*d,char keys[32]){typedef int(*fn)(Display*,char*);fn next=(fn)dlsym(RTLD_NEXT,"XQueryKeymap");if(!next)abort();int r=next(d,keys);++keymaps;record();return r;}
int XSync(Display*d,Bool discard){typedef int(*fn)(Display*,Bool);fn next=(fn)dlsym(RTLD_NEXT,"XSync");if(!next)abort();int r=next(d,discard);++synchronizations;record();return r;}
int XTestFakeMotionEvent(Display*d,int s,int x,int y,unsigned long delay){typedef int(*fn)(Display*,int,int,int,unsigned long);fn next=(fn)dlsym(RTLD_NEXT,"XTestFakeMotionEvent");const char *fault=getenv("EYES_TEST_FAULT");if(!next)abort();if(fault&&!strcmp(fault,"drift"))x++;return next(d,s,x,y,delay);}
int XTestFakeButtonEvent(Display*d,unsigned b,Bool pressed,unsigned long delay){typedef int(*fn)(Display*,unsigned,Bool,unsigned long);fn next=(fn)dlsym(RTLD_NEXT,"XTestFakeButtonEvent");const char *fault=getenv("EYES_TEST_FAULT");if(!next)abort();if(fault&&!strcmp(fault,"button")&&pressed)return 0;return next(d,b,pressed,delay);}
