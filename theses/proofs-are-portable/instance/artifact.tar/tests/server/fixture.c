#include <X11/Xlib.h>
#include <X11/keysym.h>
#include <stdio.h>
#include <stdlib.h>
int main(void) {
    Display *d = XOpenDisplay(NULL); if (!d) return 2;
    Window w = XCreateSimpleWindow(d,DefaultRootWindow(d),10,10,320,240,0,0,0x336699);
    XSelectInput(d,w,ButtonPressMask|ButtonReleaseMask|KeyPressMask|KeyReleaseMask|PointerMotionMask|StructureNotifyMask);
    XMapWindow(d,w); XSync(d,False); XSetInputFocus(d,w,RevertToParent,CurrentTime); XSync(d,False);
    unsigned clicks=0, releases=0, keys=0, ups=0, scroll=0;
    printf("{\"ready\":true,\"keycode\":%u}\n",XKeysymToKeycode(d,XK_a));fflush(stdout);
    for (;;) {
        XEvent e; XNextEvent(d,&e);
        if(e.type==ButtonPress){if(e.xbutton.button<=3)clicks++;else scroll++;}
        if(e.type==ButtonRelease)releases++;
        if(e.type==KeyPress)keys++;
        if(e.type==KeyRelease)ups++;
        if(e.type==ButtonPress || e.type==ButtonRelease || e.type==KeyPress || e.type==KeyRelease || e.type==MotionNotify){
            printf("{\"clicks\":%u,\"releases\":%u,\"keys\":%u,\"ups\":%u,\"scroll\":%u}\n",clicks,releases,keys,ups,scroll);fflush(stdout);
        }
    }
}
