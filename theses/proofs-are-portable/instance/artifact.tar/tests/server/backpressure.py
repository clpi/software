"""A non-reading MCP peer must not hold the controller forever."""
import json,os,pathlib,subprocess,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from check import BINARY as EYES
class Backpressure(unittest.TestCase):
    def test_nonreading_client_is_bounded(self):
        env={k:v for k,v in os.environ.items() if not k.startswith('IDOL_EYES_')};env.pop('DISPLAY',None)
        p=subprocess.Popen([str(EYES)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env,bufsize=0)
        frames=[{'jsonrpc':'2.0','id':1,'method':'initialize','params':{'protocolVersion':'2025-11-25','capabilities':{},'clientInfo':{'name':'test','version':'1'}}},{'jsonrpc':'2.0','method':'notifications/initialized'}]
        frames += [{'jsonrpc':'2.0','id':i+2,'method':'tools/list'} for i in range(20)]
        payload=b''.join(json.dumps(x,separators=(',',':')).encode()+b'\n' for x in frames)
        self.assertLess(len(payload),4096)
        try:
            self.assertEqual(p.stdin.write(payload),len(payload));p.stdin.flush()
            try:code=p.wait(timeout=7)
            except subprocess.TimeoutExpired:self.fail('non-reading peer left the native controller blocked')
            self.assertNotEqual(code,0,'incomplete replies cannot report successful exit')
        finally:
            if p.poll() is None:p.kill();p.wait(timeout=2)
            p.stdin.close();p.stdout.close();p.stderr.close()
if __name__=='__main__':unittest.main(verbosity=2)
