"""Independent real-X11 controls for ownership of held input state."""
import ctypes, os, pathlib, sys, unittest
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from check import Client
import desktop
class Safety(unittest.TestCase):
    setUpClass=classmethod(desktop.Desktop.setUpClass.__func__)
    tearDownClass=classmethod(desktop.Desktop.tearDownClass.__func__)
    event=classmethod(desktop.Desktop.event.__func__)
    def setUp(self):
        self.x=ctypes.CDLL('libX11.so.6');self.t=ctypes.CDLL('libXtst.so.6')
        self.x.XOpenDisplay.argtypes=[ctypes.c_char_p];self.x.XOpenDisplay.restype=ctypes.c_void_p
        self.x.XCloseDisplay.argtypes=[ctypes.c_void_p]
        self.x.XSync.argtypes=[ctypes.c_void_p,ctypes.c_int]
        self.x.XQueryKeymap.argtypes=[ctypes.c_void_p,ctypes.c_void_p]
        self.x.XDefaultRootWindow.argtypes=[ctypes.c_void_p];self.x.XDefaultRootWindow.restype=ctypes.c_ulong
        self.x.XQueryPointer.argtypes=[ctypes.c_void_p,ctypes.c_ulong,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p,ctypes.c_void_p]
        self.t.XTestFakeKeyEvent.argtypes=[ctypes.c_void_p,ctypes.c_uint,ctypes.c_int,ctypes.c_ulong]
        self.t.XTestFakeButtonEvent.argtypes=[ctypes.c_void_p,ctypes.c_uint,ctypes.c_int,ctypes.c_ulong]
        self.d=self.x.XOpenDisplay(self.env['DISPLAY'].encode());self.assertTrue(self.d)
        self.c=Client(self.env);self.c.init()
        self.context=self.c.call('tools/call',{'name':'observe','arguments':{}})['result']['structuredContent']['context']
    def tearDown(self):
        self.c.close();self.x.XCloseDisplay(self.d)
    def keymap(self):
        raw=ctypes.create_string_buffer(32);self.x.XQueryKeymap(self.d,raw);return raw.raw
    def mask(self):
        root=ctypes.c_ulong();child=ctypes.c_ulong();x=ctypes.c_int();y=ctypes.c_int();wx=ctypes.c_int();wy=ctypes.c_int();mask=ctypes.c_uint()
        self.assertTrue(self.x.XQueryPointer(self.d,self.x.XDefaultRootWindow(self.d),ctypes.byref(root),ctypes.byref(child),ctypes.byref(x),ctypes.byref(y),ctypes.byref(wx),ctypes.byref(wy),ctypes.byref(mask)))
        return mask.value
    def test_does_not_release_preheld_key(self):
        code=self.ready['keycode'];self.t.XTestFakeKeyEvent(self.d,code,1,0);self.x.XSync(self.d,0)
        before=self.keymap();self.assertTrue(before[code//8]&(1<<(code%8)))
        try:
            reply=self.c.call('tools/call',{'name':'key','arguments':{'context':self.context,'sequence':1,'code':code}})
            self.assertEqual(self.keymap(),before,'server released or changed externally held keys')
            self.assertTrue(reply['result']['isError'],reply)
        finally:self.t.XTestFakeKeyEvent(self.d,code,0,0);self.x.XSync(self.d,0)
        # Denial occurs before reserving the sequence.
        good=self.c.call('tools/call',{'name':'key','arguments':{'context':self.context,'sequence':1,'code':code}})
        self.assertEqual(good['result']['structuredContent']['outcome'],'submitted')
    def test_does_not_release_preheld_button(self):
        self.t.XTestFakeButtonEvent(self.d,1,1,0);self.x.XSync(self.d,0)
        before=self.mask();self.assertTrue(before&256)
        try:
            reply=self.c.call('tools/call',{'name':'click','arguments':{'context':self.context,'sequence':1,'button':1}})
            self.assertEqual(self.mask(),before,'server released externally held button')
            self.assertTrue(reply['result']['isError'],reply)
        finally:self.t.XTestFakeButtonEvent(self.d,1,0,0);self.x.XSync(self.d,0)
    def test_paste_like_payload_remains_data(self):
        r=self.c.call('tools/call',{'name':'observe','arguments':{'method':'close','command':'rm -rf /'}})
        self.assertIn('error',r)
        r=self.c.call('tools/call',{'name':'observe','arguments':{}})
        self.assertEqual(r['result']['structuredContent']['outcome'],'observed')
if __name__=='__main__':unittest.main(verbosity=2)
