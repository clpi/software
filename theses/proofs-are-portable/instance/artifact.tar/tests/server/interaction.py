"""MCP client -> actual Idol binary -> X server -> independent application observations."""
import json,os,pathlib,select,subprocess,sys,tempfile,time,unittest
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from check import Client,ROOT
class Interaction(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='eyes-interaction-');p=pathlib.Path(self.temp.name)
        subprocess.run(['cc','-std=c11','-O2','-Wall','-Wextra','-Werror',str(ROOT/'tests/server/interaction.c'),'-lX11','-o',str(p/'fixture')],check=True)
        self.x=subprocess.Popen(['Xvfb','-displayfd','1','-screen','0','640x480x24','-nolisten','tcp'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        if not select.select([self.x.stdout],[],[],5)[0]:raise RuntimeError('display startup deadline')
        n=self.x.stdout.readline().strip().decode();self.assertTrue(n.isdigit())
        self.env={**os.environ,'DISPLAY':':'+n,'IDOL_EYES_X11':'allow'}
        self.app=subprocess.Popen([str(p/'fixture')],env=self.env,stdout=subprocess.PIPE,stderr=subprocess.PIPE,bufsize=0)
        self.buffer=b'';self.ready=self.event();self.assertTrue(self.ready['ready'])
        self.client=Client(self.env,binary=getattr(self,'binary',None));self.client.init()
        self.initial=self.tool('observe',{})['structuredContent'];self.sequence=1
    def tearDown(self):
        self.client.close()
        for p in [self.app,self.x]:
            p.terminate();p.wait(timeout=3);p.stdout.close();p.stderr.close()
        self.temp.cleanup()
    def event(self,timeout=3):
        deadline=time.monotonic()+timeout
        while b'\n' not in self.buffer:
            if not select.select([self.app.stdout],[],[],max(0,deadline-time.monotonic()))[0]:raise TimeoutError('fixture observation deadline')
            b=os.read(self.app.stdout.fileno(),65536)
            if not b:raise RuntimeError('fixture ended')
            self.buffer+=b
        line,self.buffer=self.buffer.split(b'\n',1);return json.loads(line)
    def until(self,predicate):
        for _ in range(600):
            try: row=self.event()
            except TimeoutError: self.fail("required application effect was not observed")
            if predicate(row):return row
        self.fail('required application observation absent')
    def tool(self,name,args):
        if name not in ('observe','capture','close'):
            args={**args,'sequence':self.sequence,'context':self.initial['context']}
        r=self.client.call('tools/call',{'name':name,'arguments':args})
        self.assertIn('result',r,'native action was not implemented or rejected')
        return r['result']
    def action(self,name,args):
        result=self.tool(name,args);self.assertFalse(result.get('isError'),result);self.sequence+=1;return result
    def test_type_chord_drag_and_restoration(self):
        names={t['name'] for t in self.client.call('tools/list')['result']['tools']}
        self.assertTrue({'type','chord','drag'}<=names,'missing one-call input tools')
        self.action('move',{'x':80,'y':90})
        result=self.action('type',{'text':'Hello, Idol! 42\t\n'})
        self.assertEqual(result['structuredContent']['outcome'],'submitted')
        wanted=list(b'Hello, Idol! 42\t\r')
        row=self.until(lambda r:r.get('text')==wanted and r['keys']==r['ups'])
        self.assertEqual(row['text'],wanted)
        self.action('chord',{'code':[self.ready['ctrl'],self.ready['a']]})
        row=self.until(lambda r:r.get('text')==wanted+[1] and r['keys']==r['ups'])
        self.action('drag',{'x':210,'y':180,'button':1})
        row=self.until(lambda r:r.get('drag',0)>=1 and r['presses']==r['releases']==1)
        self.assertEqual(row['presses'],1)
        restored=self.action('move',{'x':self.initial['x'],'y':self.initial['y']})['structuredContent']
        self.assertEqual((restored['x'],restored['y']),(self.initial['x'],self.initial['y']))
    def test_type_preflights_unmapped_text(self):
        self.action('move',{'x':80,'y':90})
        denied=self.tool('type',{'text':'prefix😀'})
        self.assertTrue(denied.get('isError'),denied)
        self.action('type',{'text':'ok'})
        row=self.until(lambda r:r.get('text')==list(b'ok') and r['keys']==r['ups'])
        self.assertEqual(row['text'],list(b'ok'),'unsupported suffix must not leak a typed prefix')
    def test_invalid_chord_does_not_reserve_sequence(self):
        r=self.client.call('tools/call',{'name':'chord','arguments':{'context':self.initial['context'],'sequence':1,'code':[self.ready['ctrl'],self.ready['ctrl']]}})
        self.assertIn('error',r)
        self.action('key',{'code':self.ready['a']})
if __name__=='__main__':unittest.main(verbosity=2)
