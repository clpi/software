#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/XKBlib.h>
#include <stddef.h>
#include <stdio.h>
#include <stdint.h>
#include <time.h>
#include <zlib.h>
static void scalar(const char *name, size_t offset){
 printf("%s: i64 = (subject: ptr)\n  mem.read_byte(subject, %zu) | (mem.read_byte(subject, %zu) << 8) | (mem.read_byte(subject, %zu) << 16) | (mem.read_byte(subject, %zu) << 24)\n\n",name,offset,offset+1,offset+2,offset+3);
}
int main(void){
#if __BYTE_ORDER__ != __ORDER_LITTLE_ENDIAN__
 return 2;
#endif
 if(sizeof(void*)!=8||sizeof(long)!=8||sizeof(int)!=4||sizeof(struct timespec)!=16||offsetof(struct timespec,tv_nsec)!=8||sizeof(uLong)!=8)return 2;
 printf("data: ptr = (image: ptr)\n  mem.ptr_from_addr(ptr, mem.read_i64(image, %zu))\n\n",offsetof(XImage,data));
 scalar("pitch",offsetof(XImage,bytes_per_line));
 scalar("bits",offsetof(XImage,bits_per_pixel));
 scalar("order",offsetof(XImage,byte_order));
 printf("red: i64 = (image: ptr)\n  mem.read_i64(image, %zu)\n\n",offsetof(XImage,red_mask));
 printf("green: i64 = (image: ptr)\n  mem.read_i64(image, %zu)\n\n",offsetof(XImage,green_mask));
 printf("blue: i64 = (image: ptr)\n  mem.read_i64(image, %zu)\n\n",offsetof(XImage,blue_mask));
 scalar("origin",offsetof(XImage,xoffset));
 scalar("color",offsetof(Visual,class));
 printf("layout: i64 = (subject: ptr)\n  mem.read_byte(subject, %zu)\n\n",offsetof(XkbStateRec,group));
 printf("modifier: i64 = (subject: ptr)\n  mem.read_byte(subject, %zu)\n\n",offsetof(XkbStateRec,mods));
 return 0;
}
