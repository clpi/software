"""A corrupt internal return after real input must retain the uncertain prefix."""
import os,pathlib,shutil,subprocess,sys,tempfile,unittest
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from interaction import Interaction
ROOT=pathlib.Path(__file__).resolve().parents[2]
class Result(unittest.TestCase):
 def fault(self,value):
  with tempfile.TemporaryDirectory(prefix='eyes-receipt-') as td:
   root=pathlib.Path(td)
   for d in ('protocol','tools'):shutil.copytree(ROOT/d,root/d,ignore=shutil.ignore_patterns('__pycache__'))
   (root/'tests/server').mkdir(parents=True);shutil.copy2(ROOT/'tests/server/layout.c',root/'tests/server/layout.c')
   p=root/'protocol/server.id';s=p.read_text();a='  if mode > 1\n';self.assertEqual(s.count(a),1)
   p.write_text(s.replace(a,f'  if mode > 1 and sequence == 2\n    return {value}\n'+a))
   built=subprocess.run([sys.executable,'-S',str(root/'tools/server.py')],capture_output=True,timeout=90);self.assertEqual(built.returncode,0,built.stdout+built.stderr)
   f=Interaction('test_type_chord_drag_and_restoration');f.binary=root/'.build/eyes';ready=False
   try:
    f.setUp();ready=True
    args={'context':f.initial['context'],'sequence':1,'steps':[{'name':'key','arguments':{'code':f.ready['a']}},{'name':'key','arguments':{'code':f.ready['a']}},{'name':'type','arguments':{'text':'BAD'}}]}
    try:r=f.client.call('tools/call',{'name':'perform','arguments':args})['result']
    except RuntimeError as e:self.fail('lost action receipt terminated the session: '+str(e))
    self.assertTrue(r.get('isError'),r);s=r['structuredContent'];self.assertEqual((s['submittedSteps'],s['failedStep'],s['nextSequence']),(2,2,3));self.assertNotIn('x',s)
    self.assertTrue(f.client.call('tools/call',{'name':'perform','arguments':args})['result'].get('isError'))
    f.sequence=3;f.action('type',{'text':'ok'});r=f.until(lambda r:r.get('text',[])[-2:]==list(b'ok') and r['keys']==r['ups']);self.assertEqual(r['text'],list(b'aaok'))
   finally:
    if ready:
     f.tearDown()
 def test_negative_result_retains_uncertain_prefix(self):self.fault(-1)
 def test_positive_result_without_error_stops(self):self.fault(65537)
if __name__=='__main__':
 r=unittest.TextTestRunner(verbosity=2).run(unittest.defaultTestLoader.loadTestsFromTestCase(Result));sys.exit(not r.wasSuccessful())
