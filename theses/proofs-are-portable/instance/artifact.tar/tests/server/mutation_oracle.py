"""Test-only selection and strict unittest failure admission for mutation controls."""
import re


CLASSES = {
    'backpressure.py': 'Backpressure', 'lease.py': 'Lease',
    'desktop.py': 'Desktop', 'safety.py': 'Safety',
    'interaction.py': 'Interaction', 'query.py': 'Query',
    'reconcile.py': 'Reconcile',
}


def single_case_command(python, script, case):
    """Use unittest's selector even when a script has a custom __main__."""
    identity = script.removesuffix('.py') + '.' + CLASSES[script] + '.' + case
    return [python, '-S', '-m', 'unittest', '-v', identity], identity


def require_named_failure(returncode, stderr, identity):
    """Admit exactly one named assertion failure, never a setup/process error."""
    output = stderr.decode('utf-8', errors='strict')
    case = identity.rsplit('.', 1)[1]
    records = re.findall(r'^(FAIL|ERROR): ([^\n]+)$', output, re.MULTILINE)
    if returncode != 1 or records != [('FAIL', case + ' (' + identity + ')')]:
        raise RuntimeError('did not fail the required single oracle: ' + identity)
    if not re.search(r'^Ran 1 test in [^\n]+$', output, re.MULTILINE):
        raise RuntimeError('oracle did not run exactly one test: ' + identity)
    if not re.search(r'^FAILED \(failures=1\)\s*\Z', output, re.MULTILINE):
        raise RuntimeError('oracle had additional or unexpected outcomes: ' + identity)
    if not re.search(r'^AssertionError(?::|$)', output, re.MULTILINE):
        raise RuntimeError('oracle did not report an assertion: ' + identity)
    # unittest hides its own stack frames. These named lifecycle hooks remain
    # identifiable, but arbitrary addCleanup callback assertion failures cannot
    # be distinguished from test-body assertions by this text-only verifier.
    if re.search(r'^  File .*, in (?:setUp|tearDown|setUpClass|tearDownClass)$', output, re.MULTILINE):
        raise RuntimeError('fixture setup/cleanup failure is not a behavioral control')
    # Missing application effects are converted to assertions by fixtures.
    # Preserve the existing exclusion of process/setup failures, even if a
    # fixture includes such an exception inside an assertion message.
    if 'RuntimeError:' in output or 'CalledProcessError' in output:
        raise RuntimeError('infrastructure error is not a behavioral control')
