#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <X11/keysym.h>
#include <stdio.h>
#include <stdlib.h>
int main(void) {
    Display *d=XOpenDisplay(NULL); if(!d)return 2;
    Window w=XCreateSimpleWindow(d,DefaultRootWindow(d),10,10,500,400,0,0,0x336699);
    XSelectInput(d,w,ButtonPressMask|ButtonReleaseMask|KeyPressMask|KeyReleaseMask|PointerMotionMask|StructureNotifyMask);
    XMapWindow(d,w);XSync(d,False);XSetInputFocus(d,w,RevertToParent,CurrentTime);XSync(d,False);
    unsigned presses=0,releases=0,keys=0,ups=0,drag=0; unsigned char text[2048];size_t used=0;
    printf("{\"ready\":true,\"a\":%u,\"ctrl\":%u}\n",XKeysymToKeycode(d,XK_a),XKeysymToKeycode(d,XK_Control_L));fflush(stdout);
    for(;;){
        XEvent e;XNextEvent(d,&e);
        if(e.type==ButtonPress)presses++;
        if(e.type==ButtonRelease)releases++;
        if(e.type==MotionNotify&&(e.xmotion.state&Button1Mask))drag++;
        if(e.type==KeyPress){char b[32];KeySym s;int n=XLookupString(&e.xkey,b,sizeof b,&s,NULL);keys++;for(int i=0;i<n&&used<sizeof text;i++)text[used++]=(unsigned char)b[i];}
        if(e.type==KeyRelease)ups++;
        if(e.type==ButtonPress||e.type==ButtonRelease||e.type==MotionNotify||e.type==KeyPress||e.type==KeyRelease){
            printf("{\"presses\":%u,\"releases\":%u,\"keys\":%u,\"ups\":%u,\"drag\":%u,\"text\":[",presses,releases,keys,ups,drag);
            for(size_t i=0;i<used;i++){printf("%s%u",i?",":"",text[i]);}puts("]}");fflush(stdout);
        }
    }
}
