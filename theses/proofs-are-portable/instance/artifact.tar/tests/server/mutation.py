"""Compile deliberately broken Idol bodies; require named assertion failures, never build failures."""
import hashlib,json,os,pathlib,shutil,subprocess,sys
from mutation_oracle import single_case_command, require_named_failure
ROOT=pathlib.Path(__file__).resolve().parents[2]
OUT=pathlib.Path(os.environ['EVIDENCE']).resolve();OUT.mkdir(parents=True,exist_ok=False,mode=0o700)
changes=[
 ('egress','server.id','          bound(5)\n          delivered = flush','          delivered = flush','backpressure.py','test_nonreading_client_is_bounded'),
 ('absent-grant','server.id','  if grant != nil','  if true','lease.py','test_missing_grant_denies_even_with_live_display'),
 ('expiry','server.id','instant + duration * 1000000000','instant + 300000000000','lease.py','test_operator_can_shorten_lease'),
 ('readonly','server.id','action != 6 and state[8] != 0','action != 6 and false','lease.py','test_observation_only_scope'),
 ('permission','server.id','if authorized and nearby','if nearby','desktop.py','test_real_effects_and_replay'),
 ('replay','server.id','if sequence == state[3]','if false','desktop.py','test_real_effects_and_replay'),
 ('submission','server.id','accepted = button(device, first, 1, 0)','accepted = 1','desktop.py','test_real_effects_and_replay'),
 ('pixels','capture.id','bluevalue = mem.read_byte(pixels, offset + bluebyte)','bluevalue = mem.read_byte(pixels, offset + redbyte)','desktop.py','test_real_effects_and_replay'),
 ('held-input','server.id','    if not quiet','    if false','safety.py','test_does_not_release_preheld_key'),
 ('typing','input.id','pressed = key(device, code, 1, 0)','pressed = 1','interaction.py','test_type_chord_drag_and_restoration'),
 ('chord-release','input.id','if key(device, plan[submitted], 0, 0) == 0','if false','interaction.py','test_type_chord_drag_and_restoration'),
 ('drag','input.id','accepted = button(device, code, 1, 0)','accepted = 1','interaction.py','test_type_chord_drag_and_restoration'),
]
phase='''  for index = 0, count - 1
    if symbol(device, plan[index * 3 + 1], plan[2048], plan[index * 3 + 2]):to(i64) != plan[index * 3 + 3]
      return 0
'''
changes.append(('interleaving','input.id',phase,'','query.py','test_typing_preflights_before_first_event'))
changes.extend([
 ('clock-snapshot','observation.id','  instant = now(state)\n  instant >= 0 and instant < state[2]','  now(state) >= 0 and now(state) < state[2]','reconcile.py','test_clock_failure_withholds_observations'),
 ('shift-preflight','input.id','  if mapping(device, 65505):to(i64) < 8\n    return -1\n','','reconcile.py','test_missing_shift_prevents_prefix'),
])
report=[]
for name,file,old,new,test,case in changes:
    work=OUT/name;work.mkdir();shutil.copytree(ROOT/'protocol',work/'protocol');shutil.copytree(ROOT/'tools',work/'tools',ignore=shutil.ignore_patterns('__pycache__'));shutil.copytree(ROOT/'tests/server',work/'tests/server',ignore=shutil.ignore_patterns('__pycache__'))
    path=work/'protocol'/file;s=path.read_text();assert s.count(old)==1,(name,s.count(old));s=s.replace(old,new)
    if name=='replay':s=s.replace('if sequence != state[3] + 1','if false')
    if name=='interleaving':
        marker='    shifted = plan[index * 3 + 2]\n'
        assert s.count(marker)==1
        s=s.replace(marker,marker+'    if symbol(device, code, plan[2048], shifted):to(i64) != plan[index * 3 + 3]\n      return 0\n')
    path.write_text(s)
    p=subprocess.run([sys.executable,'-S',str(work/'tools/server.py')],env=os.environ,capture_output=True,timeout=60)
    (work/'build.log').write_bytes(p.stdout+p.stderr)
    if p.returncode:raise RuntimeError(f'{name}: build failure is NOT mutation evidence')
    env={**os.environ,'EYES':str(work/'.build/eyes')}
    command,identity=single_case_command(sys.executable,test,case)
    p=subprocess.run(command,cwd=ROOT/'tests/server',env=env,capture_output=True,timeout=20)
    (work/'test.log').write_bytes(p.stdout+p.stderr)
    require_named_failure(p.returncode,p.stderr,identity)
    report.append({'name':name,'case':case,'testIdentity':identity,'buildExit':0,'testExit':p.returncode,'testSha256':hashlib.sha256(p.stdout+p.stderr).hexdigest()})
    print(name,'caught',flush=True)
(OUT/'mutations.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))

for name,script in [('plans','tests/server/planmutation.py'),('capture','tests/capture/mutation.py')]:
    child=subprocess.run([sys.executable,'-S',str(ROOT/script)],env={**os.environ,'EVIDENCE':str(OUT/name)},capture_output=True,timeout=240)
    (OUT/(name+'.log')).write_bytes(child.stdout+child.stderr)
    if child.returncode:raise RuntimeError(name+' fault controls failed')
    report.extend(json.loads((OUT/name/'mutations.json').read_text()))
(OUT/'mutations.json').write_text(json.dumps(report,indent=2)+'\n')
print('total',len(report),'compiled faults caught',flush=True)
