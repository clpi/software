#define _GNU_SOURCE
#include <X11/Xlib.h>
#include <dlfcn.h>
#include <errno.h>
#include <fcntl.h>
#include <limits.h>
#include <stdatomic.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <sys/syscall.h>
#include <unistd.h>

enum { NONE, CLOCK, SHIFT, DELAY, HELD };
static _Atomic unsigned queries,clocks,releases,presses;
static _Atomic int armed,edge;
static int notify=-1,resume=-1;
static void invalid(void){
 static const char message[]="invalid test descriptor\n";
 size_t offset=0;
 while(offset<sizeof(message)-1){
  ssize_t count=write(2,message+offset,sizeof(message)-1-offset);
  if(count<0&&errno==EINTR)continue;
  if(count<=0)break;
  offset+=(size_t)count;
 }
 _exit(78);
}
static int descriptor(const char *text,int access){
 if(!text||!*text)invalid();
 unsigned value=0;
 for(const unsigned char*p=(const unsigned char*)text;*p;p++){
  if(*p<'0'||*p>'9'||value>((unsigned)INT_MAX-(*p-'0'))/10)invalid();
  value=value*10+(*p-'0');
 }
 if(value<3)invalid();
 int flags=fcntl((int)value,F_GETFL);
 if(flags<0||(flags&O_ACCMODE)!=access)invalid();
 return (int)value;
}
__attribute__((constructor)) static void configure(void){
 const char *name=getenv("EYES_TEST_EDGE");
 if(!name)return;
 if(!strcmp(name,"clock"))edge=CLOCK;
 else if(!strcmp(name,"shift"))edge=SHIFT;
 else if(!strcmp(name,"delay"))edge=DELAY;
 else if(!strcmp(name,"held")){
  notify=descriptor(getenv("EYES_TEST_NOTIFY"),O_WRONLY);
  resume=descriptor(getenv("EYES_TEST_RESUME"),O_RDONLY);
  edge=HELD;
 }
}
int clock_gettime(clockid_t c,struct timespec*r){
 if(edge==CLOCK&&c==CLOCK_MONOTONIC&&armed&&++clocks==2){errno=EIO;return -1;}
 return (int)syscall(SYS_clock_gettime,c,r);
}
Bool XQueryPointer(Display*d,Window w,Window*r,Window*child,int*x,int*y,int*wx,int*wy,unsigned*m){
 typedef Bool(*F)(Display*,Window,Window*,Window*,int*,int*,int*,int*,unsigned*);
 F f=(F)dlsym(RTLD_NEXT,"XQueryPointer");if(!f)abort();Bool a=f(d,w,r,child,x,y,wx,wy,m);
 if(edge==CLOCK&&++queries==2)armed=1;
 return a;
}
KeyCode XKeysymToKeycode(Display*d,KeySym k){
 typedef KeyCode(*F)(Display*,KeySym);F f=(F)dlsym(RTLD_NEXT,"XKeysymToKeycode");if(!f)abort();
 if(edge==SHIFT&&k==65505)return 0;
 return f(d,k);
}
int XTestFakeKeyEvent(Display*d,unsigned code,Bool pressed,unsigned long delay){
 typedef int(*F)(Display*,unsigned,Bool,unsigned long);F f=(F)dlsym(RTLD_NEXT,"XTestFakeKeyEvent");if(!f)abort();
 if(pressed&&++presses==2&&edge==DELAY){struct timespec t={1,200000000};while(nanosleep(&t,&t)!=0){if(errno!=EINTR)abort();}}
 int r=f(d,code,pressed,delay);
 if(edge==HELD&&!pressed&&++releases==1){
  XSync(d,False);char b='1';if(write(notify,&b,1)!=1||read(resume,&b,1)!=1)abort();
 }
 return r;
}
