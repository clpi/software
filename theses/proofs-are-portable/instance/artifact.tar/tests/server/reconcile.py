"""Retain PR4 safety invariants through the single PR5 action executor."""
import ctypes,json,os,pathlib,select,subprocess,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from check import Client
from interaction import Interaction
class Reconcile(Interaction):
 def edge(self,mode,extra=None,descriptors=()):
  lib=pathlib.Path(self.temp.name)/'edge.so'
  subprocess.run(['cc','-shared','-fPIC','-O2','-std=c11','-Wall','-Wextra','-Werror',str(pathlib.Path(__file__).with_suffix('.c')),'-ldl','-lX11','-o',str(lib)],check=True)
  env={**self.env,**(extra or {}),'LD_PRELOAD':str(lib),'EYES_TEST_EDGE':mode}
  if mode=='delay':env['IDOL_EYES_SECONDS']='1'
  c=Client(env,pass_fds=descriptors);c.init()
  context=c.call('tools/call',{'name':'observe','arguments':{}})['result']['structuredContent']['context']
  return c,context
 def sendplan(self,c,context,steps):return c.call('tools/call',{'name':'perform','arguments':{'context':context,'sequence':1,'steps':steps}})['result']
 def step(self,n,**a):return {'name':n,'arguments':a}
 def test_clock_failure_withholds_observations(self):
  c,context=self.edge('clock')
  try:
   r=self.sendplan(c,context,[self.step('key',code=self.ready['a'])]);self.assertTrue(r.get('isError'),r)
   self.assertNotIn('"x"',json.dumps(r));self.assertFalse(any(x['type']=='image' for x in r['content']))
  finally:c.close()
 def test_missing_shift_prevents_prefix(self):
  c,context=self.edge('shift')
  try:
   r=self.sendplan(c,context,[self.step('key',code=self.ready['a']),self.step('type',text='ok')])
   self.assertTrue(r.get('isError'),r);s=r['structuredContent'];self.assertEqual((s['submittedSteps'],s['nextSequence']),(0,1))
   r=c.call('tools/call',{'name':'key','arguments':{'context':context,'sequence':1,'code':self.ready['a']}})['result'];self.assertFalse(r.get('isError'),r)
   self.until(lambda r:r.get('text')==[97] and r['keys']==r['ups'])
  finally:c.close()
 def test_expiry_withholds_prefix_observations(self):
  c,context=self.edge('delay')
  try:
   r=self.sendplan(c,context,[self.step('key',code=self.ready['a']),self.step('key',code=self.ready['a']),self.step('type',text='BAD')])
   self.assertTrue(r.get('isError'),r);s=r['structuredContent'];self.assertEqual((s['submittedSteps'],s['failedStep'],s['nextSequence']),(2,2,3))
   self.assertNotIn('"x"',json.dumps(r));self.assertFalse(any(x['type']=='image' for x in r['content']))
  finally:c.close()
 def test_external_held_input_stops_suffix(self):
  nr,nw=os.pipe();rr,rw=os.pipe();c=None;d=None;held=False;resumed=False
  x=ctypes.CDLL('libX11.so.6');t=ctypes.CDLL('libXtst.so.6')
  x.XOpenDisplay.argtypes=[ctypes.c_char_p];x.XOpenDisplay.restype=ctypes.c_void_p
  x.XCloseDisplay.argtypes=[ctypes.c_void_p];x.XSync.argtypes=[ctypes.c_void_p,ctypes.c_int];x.XQueryKeymap.argtypes=[ctypes.c_void_p,ctypes.c_void_p]
  t.XTestFakeKeyEvent.argtypes=[ctypes.c_void_p,ctypes.c_uint,ctypes.c_int,ctypes.c_ulong]
  def bitmap():
   a=ctypes.create_string_buffer(32);x.XQueryKeymap(d,a);return a.raw
  try:
   c,context=self.edge('held',{'EYES_TEST_NOTIFY':str(nw),'EYES_TEST_RESUME':str(rr)},(nw,rr));d=x.XOpenDisplay(self.env['DISPLAY'].encode());self.assertTrue(d)
   c.send({'jsonrpc':'2.0','id':1,'method':'tools/call','params':{'name':'perform','arguments':{'context':context,'sequence':1,'steps':[self.step('key',code=self.ready['a']),self.step('key',code=self.ready['a']),self.step('type',text='BAD')]}}})
   self.assertTrue(select.select([nr],[],[],3)[0]);self.assertEqual(os.read(nr,1),b'1')
   code=self.ready['ctrl'];t.XTestFakeKeyEvent(d,code,1,0);x.XSync(d,0);held=True;before=bitmap();self.assertTrue(before[code//8]&(1<<(code%8)))
   os.write(rw,b'1');resumed=True;r=c.recv()['result'];self.assertTrue(r.get('isError'),r)
   s=r['structuredContent'];self.assertEqual((s['submittedSteps'],s['failedStep'],s['nextSequence']),(1,2,2));self.assertEqual(bitmap(),before)
   t.XTestFakeKeyEvent(d,code,0,0);x.XSync(d,0);held=False
   r=c.call('tools/call',{'name':'type','arguments':{'context':context,'sequence':2,'text':'ok'}})['result'];self.assertFalse(r.get('isError'),r)
   row=self.until(lambda r:r.get('text',[])[-2:]==list(b'ok') and r['keys']==r['ups']);self.assertEqual(row['text'],list(b'aok'))
  finally:
   if held:t.XTestFakeKeyEvent(d,self.ready['ctrl'],0,0);x.XSync(d,0)
   if not resumed:
    try:os.write(rw,b'1')
    except OSError:pass
   if c:c.close()
   if d:x.XCloseDisplay(d)
   for f in (nr,nw,rr,rw):os.close(f)
if __name__=='__main__':
 names=sys.argv[1:] or [n for n in unittest.defaultTestLoader.getTestCaseNames(Reconcile) if n.startswith(('test_clock','test_missing','test_expiry','test_external'))]
 r=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(Reconcile(n) for n in names));sys.exit(not r.wasSuccessful())
