#!/usr/bin/env python3
"""Fixture battery for the observe slice (docs/observe.md).

Runs a compiled observe binary (OBSERVE_BIN) against a canned
Calculator-shaped observation block and checks the four arms:

  snapshot  the envelope shape, the ref assignment (actionable
            elements only, in block order), and the premise;
  act       a well-formed ref under its own premise resolves to
            the transport id of the numbered actionable element;
  stale     the same ref presented against a changed block (its
            premise no longer matches) refuses R-STALE by name;
  bare      a bare element number refuses R-ARGS by name.

The battery recomputes the premise fold by hand from the same
bytes, independently of the program, and compares.
"""
import json
import os
import subprocess
import sys

BLOCK = (
    "S\tpsnap1\tCalculator\n"
    "E\telem_0\tother\t0\tCalculator\n"
    "E\telem_7\ttext\t0\t77\n"
    "E\telem_16\tbutton\t1\t7\n"
    "E\telem_17\tbutton\t1\t8\n"
    "E\telem_21\tbutton\t1\t+\n"
)


def premise(block):
    h = 7
    for byte in block.encode():
        h = (h * 31 + byte) & 268435455
    return str(h)


def run(binary, command, block):
    process = subprocess.run([binary], input=command + "\n" + block,
                             capture_output=True, text=True, timeout=30)
    if process.returncode != 0:
        raise SystemExit("observe program failed: " + process.stderr.strip())
    return process.stdout.strip()


def main():
    binary = os.environ.get("OBSERVE_BIN", "./observe")
    failures = []

    def arm(name, condition, detail=""):
        print(("ok   " if condition else "FAIL ") + name +
              ((" — " + detail) if detail and not condition else ""))
        if not condition:
            failures.append(name)

    envelope = json.loads(run(binary, "snapshot", BLOCK))
    arm("snapshot ok flag", envelope.get("ok") is True)
    data = envelope.get("data", {})
    arm("snapshot id", data.get("snapshot_id") == "psnap1")
    arm("ref count", data.get("ref_count") == 3)
    arm("flat preview never claims complete observation", data.get("complete") is False)
    arm("premise matches the independent fold",
        data.get("premise") == premise(BLOCK),
        "program %s, battery %s" % (data.get("premise"), premise(BLOCK)))
    elements = data.get("elements", [])
    refs = [e.get("ref_id") for e in elements if "ref_id" in e]
    arm("refs in actionable order",
        refs == ["@psnap1:e1", "@psnap1:e2", "@psnap1:e3"], str(refs))
    names = [e.get("name") for e in elements if "ref_id" in e]
    arm("ref names", names == ["7", "8", "+"], str(names))

    answer = run(binary, "act @psnap1:e1 " + premise(BLOCK), BLOCK)
    arm("act resolves to the transport id", answer == "act elem_16 psnap1",
        answer)

    changed = BLOCK.replace("\t77\n", "\t78\n")
    refusal = json.loads(run(binary, "act @psnap1:e1 " + premise(BLOCK),
                             changed))
    arm("stale refuses by name",
        refusal.get("error", {}).get("code") == "R-STALE",
        json.dumps(refusal))

    bare = json.loads(run(binary, "act e1 " + premise(BLOCK), BLOCK))
    arm("bare ref refuses by name",
        bare.get("error", {}).get("code") == "R-ARGS", json.dumps(bare))

    wrong = json.loads(run(binary, "act @psnap1:e9 " + premise(BLOCK), BLOCK))
    arm("out of range refuses by name",
        wrong.get("error", {}).get("code") == "R-STALE", json.dumps(wrong))

    # No candidate is allowed to wrap an oversized ordinal into a live ref.
    for ordinal in ('', '0', '9223372036854775807', '9223372036854775808',
                    '18446744073709551617', '36893488147419103233', '9' * 100):
        refusal = json.loads(run(binary, 'act @psnap1:e' + ordinal + ' ' + premise(BLOCK), BLOCK))
        arm('invalid or unavailable ordinal refuses: ' + repr(ordinal),
            refusal.get('ok') is False and refusal.get('error', {}).get('code') == 'R-STALE')

    # Every untrusted string output position must remain valid JSON.
    # These probes exercise the compiled Idol executable, not a Python model.
    token = 'psnap"\\quoted\x01'
    quoted = BLOCK.replace('psnap1', token)
    snapshot = json.loads(run(binary, 'snapshot', quoted))
    quoted_data = snapshot.get('data', {})
    arm('snapshot token round-trips JSON', quoted_data.get('snapshot_id') == token)
    quoted_refs = [row.get('ref_id') for row in quoted_data.get('elements', []) if 'ref_id' in row]
    arm('ref tokens round-trip JSON', quoted_refs == ['@' + token + ':e' + str(n) for n in (1, 2, 3)])

    foreign = json.loads(run(binary, 'act @wrong"\\token:e1 ' + premise(quoted), quoted))
    arm('snapshot-mismatch refusal remains JSON', foreign.get('error', {}).get('code') == 'R-STALE')
    malformed = json.loads(run(binary, 'act @psnap1:e"\\ ' + premise(BLOCK), BLOCK))
    arm('malformed-ref refusal remains JSON', malformed.get('error', {}).get('code') == 'R-STALE')

    app = 'App"\\name'
    role = 'button"\\role'
    metadata = BLOCK.replace('Calculator', app).replace('\tbutton\t', '\t' + role + '\t')
    decoded = json.loads(run(binary, 'snapshot', metadata)).get('data', {})
    arm('application metadata round-trips JSON', decoded.get('app') == app)
    roles = [row.get('role') for row in decoded.get('elements', []) if 'ref_id' in row]
    arm('role metadata round-trips JSON', roles == [role, role, role])
    command = 'unknown"\\name'
    unknown = json.loads(run(binary, command, BLOCK))
    arm('unknown command round-trips JSON', unknown.get('command') == command)

    for code in range(32):
        if code in (9, 10):
            continue  # These bytes delimit the fixture's tab/newline transport.
        label = 'left' + chr(code) + 'right'
        controls = BLOCK.replace('\t1\t7\n', '\t1\t' + label + '\n')
        parsed = json.loads(run(binary, 'snapshot', controls))
        if code == 0:
            # The pinned runtime loses NUL extent in substring/helper strings.
            # Refusal is mandatory; successful NUL preservation is not claimed.
            arm('NUL observation refuses before parsing',
                parsed.get('ok') is False and parsed.get('error', {}).get('code') == 'R-ARGS')
            refused = json.loads(run(binary, 'act @psnap1:e1 ' + premise(controls), controls))
            arm('NUL observation cannot resolve an action',
                refused.get('ok') is False and refused.get('error', {}).get('code') == 'R-ARGS')
        else:
            names = [row.get('name') for row in parsed.get('data', {}).get('elements', []) if 'ref_id' in row]
            arm('control byte ' + str(code) + ' preserved in JSON', bool(names) and names[0] == label)

    for command, observation in (('snapshot\x00suffix', BLOCK),
                                  ('snapshot', BLOCK.replace('psnap1', 'psnap\x001')),
                                  ('snapshot', BLOCK + '\x00')):
        refused = json.loads(run(binary, command, observation))
        arm('NUL at the raw command/token/end boundary refuses',
            refused.get('ok') is False and refused.get('error', {}).get('code') == 'R-ARGS')

    print("observe battery: %s" % ("FAIL " + ", ".join(failures)
                                   if failures else "all arms ok"))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
