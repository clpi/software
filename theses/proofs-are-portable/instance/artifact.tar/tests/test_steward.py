#!/usr/bin/env python3
"""Battery for the state steward (tools/steward.py).

The fake calculator is the owned fixture: it issues a fresh
premise with every observation, and its act() asserts the
presented premise is the current one, so any stale action by
the steward fails the test loudly instead of landing. Its
event log (the labels acted on, in order) is the campaign's
zero-surprise evidence: arms assert the exact act sequence.

Arms:
  dirty pre-state   777 is cleared to the baseline, verified
                    by re-observation, then restored digit by
                    digit; the filed record matches the
                    returned record;
  clean pre-state   no action at all;
  unrestorable      a pre-state that is not a plain digit
                    string is carried as the named residue
                    after the baseline verifies;
  no clear path     a fixture with no clear element ends
                    with the residue recorded, no act taken;
  block adapter     the BlockTransport parses the observe
                    program's envelope shape and reports the
                    program's act line.
"""
import importlib.util
import json
import os
from pathlib import Path
import shutil
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location(
    "steward", ROOT / "tools" / "steward.py")
STEWARD = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(STEWARD)

BUTTONS = ["C", "7", "8", "+", "="]


class FakeCalc:
    def __init__(self, display, buttons=BUTTONS):
        self.display = display
        self.buttons = buttons
        self.seq = 0
        self.current_premise = ""
        self.acts = []

    def observe(self):
        self.seq += 1
        self.current_premise = "p%d-%s" % (self.seq, self.display)
        elements = [{"role": "text", "name": self.display}]
        for index, label in enumerate(self.buttons):
            elements.append({"role": "button", "name": label,
                             "ref_id": "@fake:e%d" % (index + 1)})
        return {"app": "Calculator", "premise": self.current_premise,
                "display": self.display, "elements": elements}

    def act(self, ref, premise):
        assert premise == self.current_premise, \
            "stale premise presented: %s" % premise
        label = None
        for index, name in enumerate(self.buttons):
            if ref == "@fake:e%d" % (index + 1):
                label = name
        assert label is not None, "unknown ref: %s" % ref
        self.acts.append(label)
        if label == "C":
            self.display = "0"
        elif label == "=":
            if "+" in self.display:
                left, right = self.display.split("+", 1)
                self.display = str(int(left or 0) + int(right or 0))
        elif label == "+":
            self.display += "+"
        elif self.display == "0":
            self.display = label
        else:
            self.display += label
        return True


class StewardTest(unittest.TestCase):
    def test_dirty_pre_state_is_baselined_and_restored(self):
        calc = FakeCalc("777")
        tmp = Path(__file__).resolve().parent / (
            ".steward-tmp-%d" % os.getpid())
        tmp.mkdir(exist_ok=True)
        try:
            path = tmp / "campaign.json"
            record = STEWARD.campaign(calc, record_path=path)
            self.assertEqual(record["status"],
                             "baseline-verified-restored")
            self.assertEqual(record["pre"], "777")
            self.assertEqual(record["after"], "0")
            self.assertEqual(record["restored"], "777")
            self.assertEqual(calc.acts, ["C", "7", "7", "7"])
            self.assertEqual(calc.display, "777")
            filed = json.loads(path.read_text())
            self.assertEqual(
                filed,
                {k: v for k, v in record.items() if k != "filed"})
        finally:
            shutil.rmtree(tmp, ignore_errors=True)

    def test_clean_pre_state_takes_no_action(self):
        calc = FakeCalc("0")
        record = STEWARD.campaign(calc)
        self.assertEqual(record["status"], "baseline-verified")
        self.assertEqual(calc.acts, [])

    def test_unrestorable_pre_state_is_the_named_residue(self):
        calc = FakeCalc("1+2")
        record = STEWARD.campaign(calc)
        self.assertEqual(record["status"],
                         "baseline-verified-residue-recorded")
        self.assertEqual(record["residue"], "1+2")
        self.assertEqual(record["after"], "0")
        self.assertEqual(calc.acts, ["C"])

    def test_no_clear_path_records_residue_and_acts_never(self):
        calc = FakeCalc("55", buttons=["7", "8"])
        record = STEWARD.campaign(calc)
        self.assertEqual(record["status"], "no-clear-path")
        self.assertEqual(record["residue"], "55")
        self.assertEqual(calc.acts, [])

    def test_block_transport_reads_the_program_envelope(self):
        state = {"display": "77"}

        def source():
            return ("S\ts1\tCalculator\n"
                    "E\td1\ttext\t0\t%s\n"
                    "E\tb7\tbutton\t1\t7\n"
                    "E\tbc\tbutton\t1\tC\n" % state["display"])

        def run(command, block):
            if command == "snapshot":
                elements = [
                    {"role": "text", "name": state["display"]},
                    {"role": "button", "name": "7",
                     "ref_id": "@s1:e1"},
                    {"role": "button", "name": "C",
                     "ref_id": "@s1:e2"}]
                return json.dumps(
                    {"ok": True, "data": {
                        "app": "Calculator", "premise": "prem",
                        "elements": elements}})
            if command.startswith("act @s1:e2"):
                state["display"] = "0"
                return "act bc s1"
            if command.startswith("act @s1:e1"):
                state["display"] = ("7" if state["display"] == "0"
                                     else state["display"] + "7")
                return "act b7 s1"
            raise AssertionError("unexpected command: " + command)

        transport = STEWARD.BlockTransport(source, run)
        record = STEWARD.campaign(transport)
        self.assertEqual(record["status"], "baseline-verified-restored")
        self.assertEqual(record["pre"], "77")
        self.assertEqual(record["after"], "0")
        self.assertEqual(record["restored"], "77")
        self.assertEqual(transport.last_action, "act b7 s1")


if __name__ == "__main__":
    unittest.main()
