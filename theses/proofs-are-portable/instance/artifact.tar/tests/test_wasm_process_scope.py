"""Owned compiler-process fixtures; not Idol, Wasm or desktop qualification."""
import ctypes
import importlib.util
import json
import os
from pathlib import Path
import select
import signal
import subprocess
import sys
import tempfile
import threading
import time
import unittest
from types import SimpleNamespace
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tools'))
SPEC = importlib.util.spec_from_file_location('eyes_wasm_scope', ROOT / 'tools/wasm.py')
WASM = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(WASM)


@unittest.skipUnless(sys.platform == 'linux', 'real inherited-group fixtures require Linux')
class WasmProcessScope(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.libc = ctypes.CDLL(None, use_errno=True)
        prior = ctypes.c_int()
        if cls.libc.prctl(37, ctypes.byref(prior), 0, 0, 0) != 0:
            raise OSError(ctypes.get_errno(), 'cannot inspect test subreaper state')
        if cls.libc.prctl(36, 1, 0, 0, 0) != 0:
            raise OSError(ctypes.get_errno(), 'cannot own fixture descendants')
        cls.addClassCleanup(cls.libc.prctl, 36, prior.value, 0, 0, 0)

    def setUp(self):
        temporary = tempfile.TemporaryDirectory(prefix='eyes-wasm-scope-')
        self.addCleanup(temporary.cleanup)
        self.root = Path(temporary.name)
        self.source = self.root / 'ingress.id'
        self.source.write_text('inert source fixture\n')
        self.compiler = self.root / 'compiler'
        self.capture = self.root / 'capture'
        self.pid = self.root / 'descendant.pid'
        self.release = self.root / 'release'
        self.addCleanup(self.release_descendant)

    def fixture(self, mode):
        # Descendant deliberately ignores TERM but stays in the inherited group.
        # A private release marker and deadline also bound failed test cleanup.
        body = '''import os,signal,sys,time
from pathlib import Path
root=Path(__file__).parent
(root/'leader.pid').write_text(str(os.getpid()))
child=os.fork()
if child==0:
    signal.signal(signal.SIGTERM, signal.SIG_IGN)
    (root/'descendant.pid').write_text(str(os.getpid()))
    deadline=time.monotonic()+10
    while not (root/'release').exists() and time.monotonic()<deadline:
        time.sleep(0.01)
    os._exit(0)
deadline=time.monotonic()+3
while not (root/'descendant.pid').exists():
    if time.monotonic()>deadline: raise RuntimeError('fixture child never ready')
    time.sleep(0.005)
print('fixture ready',flush=True)
'''
        if mode == 'success':
            body += "Path(sys.argv[-1]).write_bytes(b'\\0asm\\x01\\0\\0\\0')\n"
        elif mode == 'failure':
            body += 'sys.exit(7)\n'
        else:
            body += "deadline=time.monotonic()+10\nwhile not (root/'release').exists() and time.monotonic()<deadline: time.sleep(0.01)\n"
        self.compiler.write_text('#!' + sys.executable + ' -S\n' + body)
        self.compiler.chmod(0o700)

    def running(self):
        self.assertTrue(self.pid.is_file(), 'compiler fixture did not reach its child boundary')
        pid = int(self.pid.read_text())
        try:
            descriptor = os.pidfd_open(pid)
        except ProcessLookupError:
            return False
        try:
            alive = not select.select([descriptor], [], [], 0)[0]
        finally:
            os.close(descriptor)
        if not alive:
            try:
                os.waitpid(pid, os.WNOHANG)
            except ChildProcessError:
                pass
        return alive

    def assert_stopped(self):
        deadline = time.monotonic() + 0.5
        while self.running():
            if time.monotonic() >= deadline:
                self.fail('Wasm build returned with its inherited compiler descendant still running')
            time.sleep(0.01)

    def release_descendant(self):
        self.release.touch()
        if not self.pid.is_file():
            return
        deadline = time.monotonic() + 3
        while self.running():
            if time.monotonic() >= deadline:
                raise AssertionError('owned fixture descendant did not stop after release')
            time.sleep(0.01)
        leader = self.root / 'leader.pid'
        if leader.is_file():
            while time.monotonic() < deadline:
                try:
                    reaped, _ = os.waitpid(int(leader.read_text()), os.WNOHANG)
                except ChildProcessError:
                    break
                if reaped:
                    break
                time.sleep(0.01)
            else:
                raise AssertionError('owned compiler fixture leader did not stop after release')

    def report(self):
        return json.loads((self.capture / 'build.json').read_text())

    def test_success_stops_inherited_descendants_before_receipt(self):
        self.fixture('success')
        report = WASM.build(self.compiler, self.capture, self.source, limit=3)
        self.assert_stopped()
        self.assertEqual(report['outcome'], 'built-not-executed')
        self.assertEqual(report['processScope'], 'linux-owned-inherited-group')
        self.assertTrue(report['process']['ok'])
        self.assertTrue(report['process']['cleanup']['leaderReaped'])

    def test_failed_compiler_stops_inherited_descendants(self):
        self.fixture('failure')
        with self.assertRaises(RuntimeError):
            WASM.build(self.compiler, self.capture, self.source, limit=3)
        self.assert_stopped()
        report = self.report()
        self.assertEqual(report['outcome'], 'failed')
        self.assertEqual(report['exit'], 7)
        self.assertTrue(report['process']['cleanup']['leaderReaped'])
        self.assertIn('fixture ready', (self.capture / 'compile.log').read_text())

    def test_timeout_stops_term_resistant_descendant(self):
        self.fixture('timeout')
        started = time.monotonic()
        with self.assertRaises(subprocess.TimeoutExpired):
            WASM.build(self.compiler, self.capture, self.source, limit=1)
        self.assert_stopped()
        self.assertLess(time.monotonic() - started, 4)
        report = self.report()
        self.assertEqual(report['outcome'], 'failed')
        self.assertTrue(report['timeout'])
        self.assertIn('SIGKILL', report['process']['cleanup']['signalsSent'])

    def test_keyboard_interrupt_cleans_group_without_inventing_receipt(self):
        self.fixture('timeout')
        done = threading.Event()
        fired = threading.Event()
        def interrupt():
            deadline = time.monotonic() + 3
            while not done.wait(0.005) and time.monotonic() < deadline:
                if self.pid.exists():
                    fired.set()
                    os.kill(os.getpid(), signal.SIGINT)
                    return
        thread = threading.Thread(target=interrupt)
        thread.start()
        try:
            with self.assertRaises(KeyboardInterrupt):
                WASM.build(self.compiler, self.capture, self.source, limit=4)
        finally:
            done.set()
            thread.join(4)
        self.assertFalse(thread.is_alive())
        self.assertTrue(fired.is_set(), 'owned cancellation fixture did not fire')
        self.assert_stopped()
        report = self.report()
        self.assertEqual(report['outcome'], 'failed')
        self.assertEqual(report['error']['type'], 'KeyboardInterrupt')
        # Cleanup ran, but the interrupted runner returned no exact result.
        self.assertIsNone(report['process']['cleanup'])
        self.assertIsNone(report['process']['exit'])



    def synthetic_result(self, *, timed_out=False, cleanup_error=False, process_error=False):
        def run(*args, **kwargs):
            (self.capture / 'ingress.wasm').write_bytes(WASM.MAGIC)
            return {
                'ok': False, 'exit': 0 if not process_error else None,
                'timedOut': timed_out,
                'error': {'type': 'FileNotFoundError', 'message': 'fixture'} if process_error else None,
                'cleanup': {'signalsSent': [], 'leaderReaped': not process_error,
                            'errors': [{'type': 'PermissionError', 'message': 'fixture'}] if cleanup_error else []},
            }
        return run

    def test_zero_exit_with_cleanup_error_cannot_publish_success(self):
        self.compiler.write_text('#!' + sys.executable + '\nraise RuntimeError("not executed")\n')
        self.compiler.chmod(0o700)
        with mock.patch.object(WASM.process_scope, 'run_scope', side_effect=self.synthetic_result(cleanup_error=True)):
            with self.assertRaisesRegex(RuntimeError, 'cleanup failed'):
                WASM.build(self.compiler, self.capture, self.source)
        report = self.report()
        self.assertEqual(report['exit'], 0)
        self.assertEqual(report['outcome'], 'failed')
        self.assertEqual(report['process']['cleanup']['errors'][0]['type'], 'PermissionError')
        self.assertNotIn('artifactSha256', report)

    def test_zero_exit_after_timeout_is_not_success(self):
        self.compiler.write_text('#!' + sys.executable + '\nraise RuntimeError("not executed")\n')
        self.compiler.chmod(0o700)
        with mock.patch.object(WASM.process_scope, 'run_scope', side_effect=self.synthetic_result(timed_out=True)):
            with self.assertRaises(subprocess.TimeoutExpired):
                WASM.build(self.compiler, self.capture, self.source)
        report = self.report()
        self.assertEqual(report['outcome'], 'failed')
        self.assertTrue(report['timeout'])
        self.assertEqual(report['exit'], 0)
        self.assertNotIn('artifactSha256', report)

    def test_launch_failure_keeps_missing_exit_explicit(self):
        self.compiler.write_text('#!' + sys.executable + '\nraise RuntimeError("not executed")\n')
        self.compiler.chmod(0o700)
        with mock.patch.object(WASM.process_scope, 'run_scope', side_effect=self.synthetic_result(process_error=True)):
            with self.assertRaises(RuntimeError):
                WASM.build(self.compiler, self.capture, self.source)
        report = self.report()
        self.assertEqual(report['outcome'], 'failed')
        self.assertIsNone(report['exit'])
        self.assertEqual(report['process']['error']['type'], 'FileNotFoundError')
        self.assertFalse(report['process']['cleanup']['leaderReaped'])

    def test_nonlinux_branch_retains_original_direct_child_contract(self):
        # Branch selection only: this test does not execute macOS or Windows.
        self.compiler.write_text('#!' + sys.executable + ' -S\nimport sys\nfrom pathlib import Path\nPath(sys.argv[-1]).write_bytes(' + repr(WASM.MAGIC) + ')\n')
        self.compiler.chmod(0o700)
        with mock.patch.object(WASM, 'sys', SimpleNamespace(platform='darwin')):
            with mock.patch.object(WASM.process_scope, 'run_scope', side_effect=AssertionError('Linux-only scope used')) as runner:
                report = WASM.build(self.compiler, self.capture, self.source)
        runner.assert_not_called()
        self.assertEqual(report['outcome'], 'built-not-executed')
        self.assertEqual(report['processScope'], 'direct-child-only')
        self.assertNotIn('process', report)

if __name__ == '__main__':
    unittest.main(verbosity=2)
