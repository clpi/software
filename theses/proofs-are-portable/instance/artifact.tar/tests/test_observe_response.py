"""Inert preview-output controls; no native compiler or desktop is exercised."""
import argparse
import contextlib
import importlib.util
import io
import subprocess
import tempfile
import unittest
from pathlib import Path
from unittest import mock

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location("observe_response_driver", ROOT / "tools/observe.py")
DRIVER = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(DRIVER)
SEE = {"success": True, "data": {"snapshot_id": "s1", "application_name": "Owned fixture",
       "ui_elements": [{"id": "e1", "role": "button", "is_actionable": True, "label": "7"}]}}


class Response(unittest.TestCase):
    def preview(self, answer, *, click=None, observation=None):
        args = argparse.Namespace(live=True, see=None, app="Owned fixture", command="act", ref="@s1:e1", premise="123")
        with tempfile.TemporaryDirectory() as directory, contextlib.ExitStack() as stack:
            see = stack.enter_context(mock.patch.object(DRIVER, "peekaboo_see", side_effect=observation, return_value=SEE))
            stack.enter_context(mock.patch.object(DRIVER, "run_program", return_value=answer))
            run = stack.enter_context(mock.patch.object(DRIVER.subprocess, "run", side_effect=click, return_value=subprocess.CompletedProcess([], 0, "submitted", "")))
            stack.enter_context(contextlib.redirect_stdout(io.StringIO()))
            stack.enter_context(contextlib.redirect_stderr(io.StringIO()))
            caught = None
            try:
                code = DRIVER.preview(args, directory)
            except (SystemExit, ValueError) as error:
                caught, code = error, None
            return caught, code, run, see

    def refused(self, answer):
        error, _, run, see = self.preview(answer)
        self.assertIsInstance(error, SystemExit, "malformed response must refuse predictably before submission")
        self.assertIn("no action submitted", str(error))
        run.assert_not_called()
        self.assertEqual(see.call_count, 1)

    def test_missing_snapshot_refuses_without_crashing(self):
        self.refused("act e1")

    def test_missing_fields_refuse(self):
        for answer in ("act ", "act", "act e1 ", "act  s1"):
            with self.subTest(answer=answer):
                self.refused(answer)

    def test_extra_fields_refuse(self):
        self.refused("act e1 s1 extra")

    def test_control_bytes_cannot_split_the_action(self):
        for bad in ("\x00", "\t", "\n", "\r", "\x1f", "\x7f"):
            for answer in (f"act e{bad}1 s1", f"act e1 s{bad}1"):
                with self.subTest(answer=answer):
                    self.refused(answer)

    def test_mismatching_snapshot_is_not_submitted(self):
        self.refused("act e1 other")

    def test_unknown_transport_id_is_not_submitted(self):
        self.refused("act absent s1")

    def test_second_command_is_not_submitted(self):
        self.refused("act e1 s1\nact e2 s2")

    def test_empty_output_is_not_success(self):
        self.refused("")

    def test_arbitrary_output_is_not_success(self):
        self.refused("unexpected diagnostic")

    def test_malformed_json_refusal_is_not_success(self):
        for answer in ('{', 'null', '[]', '{"ok":true}', '{"ok":false}',
                       '{"ok":"false","error":{"code":"R-STALE"}}'):
            with self.subTest(answer=answer):
                self.refused(answer)

    def test_nonactionable_element_is_not_submitted(self):
        see = {"data": {**SEE["data"], "ui_elements": [{**SEE["data"]["ui_elements"][0], "is_actionable": False}]}}
        error, _, run, _ = self.preview("act e1 s1", observation=[see, see])
        self.assertIsInstance(error, SystemExit)
        self.assertIn("no action submitted", str(error))
        run.assert_not_called()

    def test_duplicate_transport_id_is_not_submitted(self):
        see = {"data": {**SEE["data"], "ui_elements": SEE["data"]["ui_elements"] * 2}}
        error, _, run, _ = self.preview("act e1 s1", observation=[see, see])
        self.assertIsInstance(error, SystemExit)
        self.assertIn("no action submitted", str(error))
        run.assert_not_called()

    def test_real_refusal_remains_non_effecting(self):
        error, code, run, see = self.preview('{"ok":false,"error":{"code":"R-STALE"}}')
        self.assertIsNone(error)
        self.assertEqual(code, 0)
        run.assert_not_called()
        self.assertEqual(see.call_count, 1)

    def test_valid_resolution_is_submitted_once(self):
        error, code, run, see = self.preview("act e1 s1")
        self.assertIsNone(error)
        self.assertEqual(code, 0)
        run.assert_called_once_with(["peekaboo", "click", "--on", "e1", "--snapshot", "s1", "--app", "Owned fixture"], capture_output=True, text=True, timeout=60)
        self.assertEqual(see.call_count, 2)

    def test_timeout_after_submission_remains_uncertain(self):
        error, _, run, see = self.preview("act e1 s1", click=subprocess.TimeoutExpired("fixture", 60))
        self.assertIsInstance(error, SystemExit)
        self.assertIn("effect is unconfirmed", str(error))
        self.assertNotIn("no action submitted", str(error))
        run.assert_called_once()
        self.assertEqual(see.call_count, 1)

    def test_observation_failure_after_submission_remains_uncertain(self):
        error, _, run, see = self.preview("act e1 s1", observation=[SEE, SystemExit("fixture")])
        self.assertIsInstance(error, SystemExit)
        self.assertIn("effect is unconfirmed", str(error))
        run.assert_called_once()
        self.assertEqual(see.call_count, 2)


if __name__ == "__main__":
    unittest.main(verbosity=2)
