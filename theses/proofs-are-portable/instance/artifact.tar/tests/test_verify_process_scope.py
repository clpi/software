"""Owned inert subprocess controls; never starts a compiler, X server or UI."""
import contextlib
import hashlib
import importlib.util
import io
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

TOOLS = Path(__file__).resolve().parents[1] / 'tools'
SPEC = importlib.util.spec_from_file_location('process_scope', TOOLS / 'process_scope.py')
SCOPE = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(SCOPE)
with mock.patch.dict(sys.modules, process_scope=SCOPE):
    SPEC = importlib.util.spec_from_file_location('eyes_verify', TOOLS / 'verify.py')
    VERIFY = importlib.util.module_from_spec(SPEC)
    SPEC.loader.exec_module(VERIFY)


@unittest.skipUnless(sys.platform == 'linux' and hasattr(os, 'WNOWAIT') and
                     hasattr(os, 'pidfd_open') and hasattr(signal, 'pidfd_send_signal'),
                     'Linux waitid/pidfd controls')
class ProcessScope(unittest.TestCase):
    def setUp(self):
        self.temporary = tempfile.TemporaryDirectory(prefix='eyes-process-control-')
        self.addCleanup(self.temporary.cleanup)
        self.root = Path(self.temporary.name)
        self.addCleanup(self.emergency_descendant_cleanup)

    def emergency_descendant_cleanup(self):
        if not (self.root / 'ready').exists():
            return
        pid, born = json.loads((self.root / 'ready').read_text())
        try:
            # Pin a process handle, then verify its recorded creation identity.
            # Never signal by a stale numeric PID after an identity check.
            descriptor = os.pidfd_open(pid)
        except ProcessLookupError:
            return
        try:
            try:
                fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
            except FileNotFoundError:
                return
            if fields[19] == born and fields[0] not in ('Z', 'X'):
                try:
                    signal.pidfd_send_signal(descriptor, signal.SIGKILL)
                except ProcessLookupError:
                    pass
        finally:
            os.close(descriptor)

    def run_child(self, code, timeout=3):
        with tempfile.TemporaryFile() as stdout, tempfile.TemporaryFile() as stderr:
            result = SCOPE.run_scope([sys.executable, '-S', '-c', code],
                                     cwd=self.root, env=os.environ.copy(),
                                     stdout=stdout, stderr=stderr, timeout=timeout, grace=0.02)
            stdout.seek(0); stderr.seek(0)
            return result, stdout.read(), stderr.read()

    def descendant(self, parent_exit='sys.exit(0)', ignore_term=False):
        # The descendant's readiness file is written after its signal policy.
        grandchild = (
            'import json, os, pathlib, signal, time; '
            + ('signal.signal(signal.SIGTERM, signal.SIG_IGN); ' if ignore_term else '')
            + "pid=os.getpid(); born=pathlib.Path('/proc/self/stat').read_text().rsplit(')',1)[1].split()[19]; "
            + "pathlib.Path('ready.tmp').write_text(json.dumps([pid,born])); pathlib.Path('ready.tmp').replace('ready'); time.sleep(60)")
        return (
            'import pathlib, subprocess, sys, time\n'
            f'p = subprocess.Popen([sys.executable, "-S", "-c", {grandchild!r}])\n'
            'deadline = time.monotonic() + 2\n'
            'while not pathlib.Path("ready").exists():\n'
            '    if time.monotonic() > deadline: raise RuntimeError("owned child not ready")\n'
            '    time.sleep(0.005)\n'
            'print("partial evidence", flush=True)\n' + parent_exit)

    def assert_descendant_stopped(self):
        pid, born = json.loads((self.root / 'ready').read_text())
        deadline = time.monotonic() + 2
        while time.monotonic() < deadline:
            try:
                # Orphan zombies are exited, but can await the container reaper.
                fields = Path(f'/proc/{pid}/stat').read_text().rsplit(')', 1)[1].split()
            except FileNotFoundError:
                return
            if fields[19] != born or fields[0] in ('Z', 'X'):
                return
            time.sleep(0.01)
        self.fail('owned descendant remained running')

    def test_normal_exit_preserves_output(self):
        result, out, err = self.run_child('import sys; print("out"); print("err", file=sys.stderr)')
        self.assertTrue(result['ok'], result)
        self.assertEqual((out, err), (b'out\n', b'err\n'))
        self.assertTrue(result['cleanup']['leaderReaped'])

    def test_normal_exit_cleans_inherited_descendant(self):
        result, out, _ = self.run_child(self.descendant())
        self.assertTrue(result['ok'], result)
        self.assertIn(b'partial evidence', out)
        self.assert_descendant_stopped()

    def test_setup_style_failure_preserves_code_and_cleans_descendant(self):
        result, _, _ = self.run_child(self.descendant('sys.exit(7)'))
        self.assertFalse(result['ok'])
        self.assertEqual(result['exit'], 7)
        self.assertFalse(result['timedOut'])
        self.assert_descendant_stopped()

    def test_timeout_preserves_partial_output_and_kills_descendants(self):
        result, out, _ = self.run_child(self.descendant('time.sleep(60)'), timeout=0.5)
        self.assertTrue(result['timedOut'], result)
        self.assertFalse(result['ok'])
        self.assertIn(b'partial evidence', out)
        self.assert_descendant_stopped()

    def test_ignoring_term_descendant_is_killed_after_leader_exit(self):
        start = time.monotonic()
        result, _, _ = self.run_child(self.descendant(ignore_term=True))
        self.assertTrue(result['ok'], result)
        self.assertIn('SIGKILL', result['cleanup']['signalsSent'])
        self.assertLess(time.monotonic() - start, 5)
        self.assert_descendant_stopped()

    def test_unrelated_owned_sentinel_is_not_signaled(self):
        sentinel = subprocess.Popen([sys.executable, '-S', '-c', 'import time; time.sleep(60)'],
                                    start_new_session=True)
        def cleanup():
            if sentinel.poll() is None:
                sentinel.kill()
            sentinel.wait(timeout=2)
        self.addCleanup(cleanup)
        result, _, _ = self.run_child(self.descendant())
        self.assertTrue(result['ok'], result)
        self.assertIsNone(sentinel.poll())
        self.assert_descendant_stopped()

    def test_launch_failure_does_not_signal_any_group(self):
        with tempfile.TemporaryFile() as output, mock.patch.object(SCOPE.os, 'killpg') as kill:
            result = SCOPE.run_scope(['/nonexistent/eyes-owned-test'], cwd=self.root,
                                     env={}, stdout=output, stderr=output, timeout=1)
        self.assertFalse(result['ok'])
        self.assertEqual(result['error']['type'], 'FileNotFoundError')
        kill.assert_not_called()

    def test_wait_exception_still_cleans_owned_process(self):
        def fail_wait(*args):
            raise RuntimeError('inert injected wait failure')
        with mock.patch.object(SCOPE.os, 'waitid', side_effect=fail_wait):
            result, _, _ = self.run_child('import time; time.sleep(60)')
        self.assertFalse(result['ok'])
        self.assertEqual(result['error']['type'], 'RuntimeError')
        self.assertTrue(result['cleanup']['leaderReaped'])

    def test_cleanup_errors_fail_closed_and_signals_precede_reaping(self):
        events = []
        child = mock.Mock(pid=12345)
        child.wait.side_effect = lambda **kw: events.append('reap') or 9
        def signal_group(pid, sig):
            self.assertEqual(pid, 12345)
            events.append(sig.name)
            if sig == signal.SIGTERM:
                raise PermissionError('inert cleanup refusal')
        with mock.patch.object(SCOPE.subprocess, 'Popen', return_value=child), \
             mock.patch.object(SCOPE.os, 'waitid', return_value=object()) as observe, \
             mock.patch.object(SCOPE.os, 'killpg', side_effect=signal_group):
            result, _, _ = self.run_child('unused')
        self.assertEqual(events, ['SIGTERM', 'SIGKILL', 'reap'])
        self.assertEqual(observe.call_args.args[2], os.WEXITED | os.WNOHANG | os.WNOWAIT)
        self.assertFalse(result['ok'])
        self.assertEqual(result['exit'], 9)
        self.assertEqual(result['cleanup']['errors'][0]['type'], 'PermissionError')
        child.poll.assert_not_called()
        child.communicate.assert_not_called()

    def test_cleanup_grace_interrupt_still_kills_and_reaps(self):
        events = []
        child = mock.Mock(pid=12345)
        child.wait.side_effect = lambda **kw: events.append('reap') or -9
        with mock.patch.object(SCOPE.subprocess, 'Popen', return_value=child), \
             mock.patch.object(SCOPE.os, 'waitid', return_value=object()), \
             mock.patch.object(SCOPE.os, 'killpg', side_effect=lambda pid, sig: events.append(sig.name)), \
             mock.patch.object(SCOPE.time, 'sleep', side_effect=KeyboardInterrupt()):
            with self.assertRaises(KeyboardInterrupt):
                self.run_child('unused')
        self.assertEqual(events, ['SIGTERM', 'SIGKILL', 'reap'])

    def test_cleanup_grace_error_is_retained_after_kill_and_reap(self):
        events = []
        child = mock.Mock(pid=12345)
        child.wait.side_effect = lambda **kw: events.append('reap') or 0
        with mock.patch.object(SCOPE.subprocess, 'Popen', return_value=child), \
             mock.patch.object(SCOPE.os, 'waitid', return_value=object()), \
             mock.patch.object(SCOPE.os, 'killpg', side_effect=lambda pid, sig: events.append(sig.name)), \
             mock.patch.object(SCOPE.time, 'sleep', side_effect=OSError('inert grace error')):
            result, _, _ = self.run_child('unused')
        self.assertEqual(events, ['SIGTERM', 'SIGKILL', 'reap'])
        self.assertFalse(result['ok'])
        self.assertEqual(result['cleanup']['errors'][0]['type'], 'OSError')

    def test_reaped_elsewhere_never_signals_reused_group(self):
        child = mock.Mock(pid=12345)
        with mock.patch.object(SCOPE.subprocess, 'Popen', return_value=child), \
             mock.patch.object(SCOPE.os, 'waitid', side_effect=ChildProcessError()), \
             mock.patch.object(SCOPE.os, 'killpg') as kill:
            result, _, _ = self.run_child('unused')
        self.assertFalse(result['ok'])
        self.assertEqual(result['cleanup']['errors'][0]['type'], 'OwnershipLost')
        kill.assert_not_called()
        child.wait.assert_not_called()

    def test_absent_group_does_not_redirect_cleanup(self):
        child = mock.Mock(pid=12345)
        child.wait.return_value = 0
        with mock.patch.object(SCOPE.subprocess, 'Popen', return_value=child), \
             mock.patch.object(SCOPE.os, 'waitid', return_value=object()), \
             mock.patch.object(SCOPE.os, 'killpg', side_effect=ProcessLookupError()) as kill:
            result, _, _ = self.run_child('unused')
        self.assertTrue(result['ok'], result)
        self.assertEqual([call.args[0] for call in kill.call_args_list], [12345, 12345])

    def test_unsupported_platform_refuses_before_launch(self):
        with mock.patch.object(SCOPE.sys, 'platform', 'unsupported'), \
             mock.patch.object(SCOPE.subprocess, 'Popen') as launch:
            result, _, _ = self.run_child('unused')
        self.assertFalse(result['ok'])
        self.assertIn('requires Linux', result['error']['message'])
        launch.assert_not_called()


class VerifyReporting(unittest.TestCase):
    def test_build_interruption_retains_partial_log_and_propagates(self):
        with tempfile.TemporaryDirectory(prefix='eyes-verify-interrupt-') as temporary:
            root = Path(temporary)
            out = root / 'evidence'
            def interrupt(command, **kwargs):
                kwargs['stdout'].write(b'partial stdout\n')
                kwargs['stderr'].write(b'partial stderr\n')
                raise KeyboardInterrupt('inert cancellation')
            with mock.patch.object(VERIFY, 'ROOT', root), \
                 mock.patch.object(VERIFY, 'run_scope', side_effect=interrupt), \
                 mock.patch.dict(os.environ, {'IDOL': '/never-run', 'IDOL_RUNTIME': '/never-run'}), \
                 mock.patch.object(sys, 'argv', ['verify', '--output', str(out)]), \
                 contextlib.redirect_stdout(io.StringIO()):
                with self.assertRaises(KeyboardInterrupt):
                    VERIFY.main()
            log = (out / 'build.log').read_bytes()
            self.assertEqual(log, b'partial stdout\npartial stderr\n')
            report = json.loads((out / 'report.json').read_text())
            self.assertEqual(report['outcome'], 'failed')
            self.assertEqual(report['buildRun']['error']['type'], 'KeyboardInterrupt')
            self.assertIsNone(report['buildRun']['cleanup'])
            self.assertIsNone(report['buildRun']['exit'])
            self.assertEqual(report['buildRun']['logSha256'], hashlib.sha256(log).hexdigest())

    def exercise(self, fail_build, failure_kind='timeout'):
        with tempfile.TemporaryDirectory(prefix='eyes-verify-report-') as temporary:
            root = Path(temporary)
            run = root / '.build' / 'owned'
            run.mkdir(parents=True)
            (run / 'eyes').write_bytes(b'inert fixture, never executed')
            (run / 'build.json').write_text(json.dumps({
                'binarySha256': hashlib.sha256((run / 'eyes').read_bytes()).hexdigest(), 'source': {}}))
            out = root / 'evidence'
            calls = []
            def fake_scope(command, **kwargs):
                calls.append(command)
                failure = fail_build or len(calls) > 1
                kwargs['stdout'].write(b'partial log\n' if failure else (str(run) + '\n').encode())
                return {'ok': not failure, 'exit': None if failure and failure_kind == 'launch' else (-15 if failure else 0),
                        'timedOut': failure and failure_kind == 'timeout',
                        'error': {'type': 'FileNotFoundError', 'message': 'inert launch failure'} if failure and failure_kind == 'launch' else None,
                        'cleanup': {'signalsSent': ['SIGTERM', 'SIGKILL'],
                                    'errors': [{'type': 'PermissionError', 'message': 'inert cleanup failure'}] if failure and failure_kind == 'cleanup' else [],
                                    'leaderReaped': failure_kind != 'launch'}}
            with mock.patch.object(VERIFY, 'ROOT', root), \
                 mock.patch.object(VERIFY, 'run_scope', side_effect=fake_scope), \
                 mock.patch.dict(os.environ, {'IDOL': '/never-run', 'IDOL_RUNTIME': '/never-run'}), \
                 mock.patch.object(sys, 'argv', ['verify', '--output', str(out)]), \
                 contextlib.redirect_stdout(io.StringIO()):
                self.assertEqual(VERIFY.main(), 1)
            report = json.loads((out / 'report.json').read_text())
            self.assertEqual(report['outcome'], 'failed')
            record = report['buildRun'] if fail_build else report['runs'][0]
            log = out / ('build.log' if fail_build else 'contract.log')
            self.assertEqual(record['timedOut'], failure_kind == 'timeout')
            self.assertFalse(record['ok'])
            if failure_kind == 'launch':
                self.assertEqual(record['error']['type'], 'FileNotFoundError')
            if failure_kind == 'cleanup':
                self.assertEqual(record['cleanup']['errors'][0]['type'], 'PermissionError')
            self.assertIn(b'partial log', log.read_bytes())
            self.assertEqual(record['logSha256'], hashlib.sha256(log.read_bytes()).hexdigest())
            self.assertEqual(len(calls), 1 if fail_build else 2)

    def test_build_timeout_retains_log_and_report(self):
        self.exercise(True)

    def test_phase_timeout_retains_failed_run_and_log(self):
        self.exercise(False)

    def test_build_launch_failure_retains_error_and_log(self):
        self.exercise(True, 'launch')

    def test_phase_cleanup_failure_retains_error_and_log(self):
        self.exercise(False, 'cleanup')


if __name__ == '__main__':
    unittest.main()
