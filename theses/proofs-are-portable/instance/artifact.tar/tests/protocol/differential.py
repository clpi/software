#!/usr/bin/env python3
"""Independent Python JSON oracle against compiled Idol bytes, not production logic."""
import ctypes, decimal, hashlib, importlib.util, json, os, pathlib, random, struct, sys
spec=importlib.util.spec_from_file_location('ingress_check',pathlib.Path(__file__).with_name('check.py'))
module=importlib.util.module_from_spec(spec); spec.loader.exec_module(module)
class Pairs(list): pass

def oracle(raw):
    if not 1<=len(raw)<=65536: return False
    def forbidden(x): raise ValueError(x)
    try:
        value=json.loads(raw.decode('utf-8'),object_pairs_hook=Pairs,parse_float=decimal.Decimal,parse_constant=forbidden)
        def valid(v,depth=0):
            if isinstance(v,str): v.encode('utf-8'); return
            if isinstance(v,(list,Pairs)):
                if depth>=64: raise ValueError('depth')
                if isinstance(v,Pairs):
                    if len(v)>128: raise ValueError('members')
                    for k,child in v: k.encode('utf-8'); valid(child,depth+1)
                else:
                    for child in v: valid(child,depth+1)
        valid(value)
        if not isinstance(value,Pairs): return False
        def get(v,key,default=None):
            values=[x for k,x in v if k==key]
            if len(values)>1: raise ValueError('duplicate')
            return values[0] if values else default
        if any(k in ('result','error') for k,_ in value): return False
        if get(value,'jsonrpc')!='2.0' or not isinstance(get(value,'method'),str): return False
        absent=object(); ident=get(value,'id',absent)
        if ident is not absent:
            if isinstance(ident,bool) or ident is None: return False
            if not isinstance(ident,(str,int,decimal.Decimal)): return False
            if isinstance(ident,decimal.Decimal) and ident != ident.to_integral_value(): return False
        param=get(value,'params',absent)
        if param is not absent:
            if not isinstance(param,Pairs): return False
            meta=get(param,'_meta',absent)
            if meta is not absent and not isinstance(meta,Pairs): return False
        if get(value,'method')=='tools/call':
            if param is absent: return False
            name=get(param,'name')
            if not isinstance(name,str) or not name: return False
            arg=get(param,'arguments',absent)
            if arg is not absent and not isinstance(arg,Pairs): return False
        return True
    except (ValueError,UnicodeError,decimal.DecimalException,RecursionError): return False

seed=20261030; rng=random.Random(seed)
roots=[b'{"jsonrpc":"2.0","id":0,"method":"ping"}',
       b'{"method":"tools/call","jsonrpc":"2.0","id":"x","params":{"name":"apply","arguments":{"note":"method"}}}',
       '{"jsonrpc":"2.0","id":"🦋","method":"ping","params":{"中文":"\\uD83D\\uDE00","a":[1,-1,1.5e-10,true,null]}}'.encode()]
cases=list(roots)
for root in roots:
    cases.extend(root[:i] for i in range(len(root)+1))
    for i in range(len(root)):
        for c in (0,34,92,255): cases.append(root[:i]+bytes([c])+root[i+1:])
for _ in range(10000):
    raw=bytearray(rng.choice(roots)); pos=rng.randrange(len(raw)+1)
    mode=rng.randrange(3)
    if mode==0: raw[pos:pos]=bytes([rng.randrange(256)])
    elif mode==1 and pos<len(raw): raw[pos]=rng.randrange(256)
    elif pos<len(raw): del raw[pos]
    cases.append(bytes(raw))
for _ in range(3000): cases.append(rng.randbytes(rng.randrange(300)))
for n in range(2000):
    value={'jsonrpc':'2.0','id':n,'method':'tools/call','params':{'name':'apply','arguments':{'text':''.join(rng.choices('abc😀漢字\n\x00"\\',k=rng.randrange(80))), 'value':[rng.randint(-10000,10000),False,None]}}}
    cases.append(json.dumps(value,ensure_ascii=bool(n%2)).encode())
for size in (65535,65536,65537):
    prefix=b'{"jsonrpc":"2.0","id":1,"method":"ping","padding":"'; suffix=b'"}'
    cases.append(prefix+b'x'*(size-len(prefix)-len(suffix))+suffix)
for n in (62,63,64,65): cases.append(b'{"jsonrpc":"2.0","id":1,"method":"ping","params":{"v":'+b'['*n+b'0'+b']'*n+b'}}')
passed=0; accepted=0; failures=[]
corpus=module.OUT/'corpus.bin'
with corpus.open('wb') as stream:
    for n,raw in enumerate(cases):
        expected=oracle(raw)
        rc,out,_=module.invoke(raw)
        actual=rc in (0,1)
        stream.write(struct.pack('<Ii',len(raw),int(expected))+raw)
        if actual!=expected or (not actual and out!=[0]*8):
            failures.append({'case':n,'input':raw.hex(),'rc':rc,'expected':expected,'slots':out})
        else: passed+=1
        accepted+=int(actual)
report={'seed':seed,'cases':len(cases),'agree':passed,'accepted':accepted,'rejected':len(cases)-accepted,'mismatches':failures,'sourceSha256':hashlib.sha256(module.SOURCE.encode()).hexdigest(),'compilerSha256':hashlib.sha256(module.IDOL.read_bytes()).hexdigest(),'corpusSha256':hashlib.sha256(corpus.read_bytes()).hexdigest(),'scope':'bounded wire ingress only; not protocol-session, authority, UI, mesh or competitor qualification'}
(module.OUT/'differential.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k!='mismatches'},indent=2)); print('mismatches',len(failures))
if failures: print(json.dumps(failures[:5],indent=2))
sys.exit(bool(failures))
