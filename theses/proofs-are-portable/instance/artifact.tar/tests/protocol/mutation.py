#!/usr/bin/env python3
"""Compile deliberate wrong Idol bodies; require named behavioral failures."""
import hashlib, importlib.util, io, json, pathlib, unittest
spec=importlib.util.spec_from_file_location('ingress_check',pathlib.Path(__file__).with_name('check.py'))
m=importlib.util.module_from_spec(spec); spec.loader.exec_module(m)
source=m.SOURCE
changes=[
 ('duplicate','      if spell(text, key, bound, "id", 2)\n        if identity != 0',
  '      if spell(text, key, bound, "id", 2)\n        if false','test_duplicate_control_keys'),
 ('control','    if character < 32\n      return -1','    if false\n      return -1','test_json_malformed'),
 ('unicode','        if character >= 194 and character <= 223','        if character >= 192 and character <= 223','test_utf8'),
 ('tool','    if tool\n      name = field','    if false\n      name = field','test_tool_call_boundary'),
 ('extent','  if space(text, size, position + 1) != size + 1','  if false','test_trailing_bytes'),
 ('integer','      if not integral(text, start, finish)','      if false','test_integral_json_number_ids'),
 ('notification','  if identity == 0\n    return 1','  if identity == 0\n    return 0','test_notification'),
 ('depth','  if depth >= 64','  if depth >= 65536','test_limits_and_boundaries'),
]
results=[]
for name,old,new,case in changes:
    if source.count(old)!=1: raise AssertionError((name,'mutation must hit exactly once'))
    changed=source.replace(old,new)
    m.FN=m.build(changed,'damage-'+name)
    log=io.StringIO(); result=unittest.TextTestRunner(stream=log,verbosity=2).run(unittest.TestSuite([m.Ingress(case)]))
    (m.OUT/(name+'.behavior.log')).write_text(log.getvalue())
    caught=not result.wasSuccessful() and len(result.failures)>0 and not result.errors
    results.append({'mutation':name,'case':case,'compiled':True,'caughtByBehavior':caught,'failures':len(result.failures),'errors':len(result.errors),'sourceSha256':hashlib.sha256(changed.encode()).hexdigest()})
    if not caught: raise AssertionError((name,log.getvalue()))
print(json.dumps(results,indent=2)); (m.OUT/'mutations.json').write_text(json.dumps(results,indent=2)+'\n')
