#define _GNU_SOURCE
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/mman.h>
#include <unistd.h>

extern int64_t eyes_probe(int64_t, int64_t, int64_t);

static void die(const char *message) { perror(message); exit(2); }

int main(int argc, char **argv) {
    if (argc != 2) return 2;
    FILE *input = fopen(argv[1], "rb");
    if (!input) die("corpus");
    const size_t page = (size_t)sysconf(_SC_PAGESIZE);
    const size_t capacity = ((65537 + page - 1) / page) * page;
    unsigned char *area = mmap(NULL, capacity + 2 * page, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (area == MAP_FAILED) die("mmap");
    if (mprotect(area + page, capacity, PROT_READ | PROT_WRITE)) die("mprotect");
    unsigned char *result = mmap(NULL, 3 * page, PROT_NONE, MAP_PRIVATE | MAP_ANONYMOUS, -1, 0);
    if (result == MAP_FAILED) die("result");
    if (mprotect(result + page, page, PROT_READ | PROT_WRITE)) die("result protect");
    int64_t *out = (int64_t *)(result + 2 * page - 8 * sizeof(int64_t));
    unsigned count = 0;
    for (;;) {
        uint32_t length;
        int32_t expected;
        size_t got = fread(&length, 1, sizeof length, input);
        if (got == 0 && feof(input)) break;
        if (got != sizeof length || fread(&expected, sizeof expected, 1, input) != 1 || length > 65537) die("header");
        unsigned char *text = area + page + capacity - length;
        if (fread(text, 1, length, input) != length) die("payload");
        if (mprotect(area + page, capacity, PROT_READ)) die("readonly");
        for (size_t i = 0; i < 8; ++i) out[i] = -999;
        int64_t answer = eyes_probe((int64_t)(intptr_t)text, length, (int64_t)(intptr_t)out);
        if ((answer == 0 || answer == 1) != expected) {
            fprintf(stderr, "case %u: outcome disagreement\n", count); return 1;
        }
        if (answer < 0) for (size_t i = 0; i < 8; ++i) if (out[i] != 0) return 1;
        if (mprotect(area + page, capacity, PROT_READ | PROT_WRITE)) die("writable");
        ++count;
    }
    int64_t expected = eyes_probe(0, 1, (int64_t)(intptr_t)out);
    if (expected >= 0 || eyes_probe(0, 1, 0) >= 0) return 1;
    fclose(input);
    munmap(area, capacity + 2 * page);
    munmap(result, 3 * page);
    printf("guarded native frames: %u; readonly input; exact output extent; no overread\n", count);
    return count == 0 ? 1 : 0;
}
