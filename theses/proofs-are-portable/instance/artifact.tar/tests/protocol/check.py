#!/usr/bin/env python3
"""Native-code oracle. This script is not a production MCP controller."""
import ctypes, hashlib, json, os, pathlib, random, re, subprocess, sys, tempfile, unittest
ROOT = pathlib.Path(__file__).resolve().parents[2]
IDOL = pathlib.Path(os.environ['IDOL']).resolve()
if 'EVIDENCE' in os.environ:
    OUT = pathlib.Path(os.environ['EVIDENCE']).resolve()
    OUT.mkdir(parents=True, mode=0o700, exist_ok=False)
else:
    parent = ROOT / '.evidence'
    parent.mkdir(exist_ok=True)
    OUT = pathlib.Path(tempfile.mkdtemp(prefix='protocol-', dir=parent))

def build(source, name):
    path = OUT / (name+'.id'); path.write_text(source)
    gen = OUT / (name+'.c')
    p = subprocess.run([str(IDOL),'compile','--no-cache','--backend=c','--emit','c',str(path),'-o',str(gen)],capture_output=True, timeout=30)
    (OUT/(name+'.compile.log')).write_bytes(p.stdout+p.stderr)
    if p.returncode: raise RuntimeError(p.stderr.decode(errors='replace')+p.stdout.decode(errors='replace'))
    graph_run=subprocess.run([str(IDOL),'graph',str(path)],capture_output=True,timeout=30)
    (OUT/(name+'.graph.log')).write_bytes(graph_run.stderr)
    if graph_run.returncode: raise RuntimeError('graph export failed')
    graph=json.loads(graph_run.stdout)
    if graph.get('schema')!='idol.graph.v1' or graph.get('blocking_applications') != []:
        raise RuntimeError('unknown schema or blocked graph applications')
    coverage=graph.get('fact_coverage',{})
    unresolved=graph.get('unresolved_applications')
    if not isinstance(unresolved,list) or coverage.get('blocking')!=0 or coverage.get('bootstrap')!=len(unresolved):
        raise RuntimeError('unclassified graph applications')
    entries=[row for row in graph['nodes'] if row.get('kind')=='func' and row.get('name')=='envelope']
    if len(entries)!=1: raise RuntimeError('entry is absent or ambiguous')
    links=[row for row in graph['callable_linkages'] if row.get('callable')==entries[0]['id'] and row.get('origin')=='idol']
    if len(links)!=1 or not re.fullmatch(r'[A-Za-z_][A-Za-z0-9_]*',links[0]['symbol']):
        raise RuntimeError('missing graph-owned C linkage')
    symbol=links[0]['symbol']
    (OUT/(name+'.graph.json')).write_bytes(graph_run.stdout)
    # The test bridge only exposes the graph-selected physical entry to ctypes.
    bridge = OUT / (name+'.bridge.c')
    bridge.write_text('#include "'+gen.name+'"\nint64_t eyes_probe(int64_t p,int64_t n,int64_t out){ return '+symbol+'(p,n,out); }\n')
    lib=OUT/(name+'.so')
    p=subprocess.run(['cc','-std=c11','-O2','-fPIC','-shared','-Wno-builtin-declaration-mismatch','-Wl,-z,defs',str(bridge),'-o',str(lib)],capture_output=True,timeout=30)
    (OUT/(name+'.link.log')).write_bytes(p.stdout+p.stderr)
    if p.returncode: raise RuntimeError(p.stderr.decode(errors='replace'))
    receipt={'sourceSha256':hashlib.sha256(path.read_bytes()).hexdigest(),
             'graphSha256':hashlib.sha256(graph_run.stdout).hexdigest(),
             'generatedSha256':hashlib.sha256(gen.read_bytes()).hexdigest(),
             'binarySha256':hashlib.sha256(lib.read_bytes()).hexdigest(),
             'graphEntry':entries[0]['id'],'physicalSymbol':symbol,
             'graphComplete':not unresolved,'bootstrapApplications':unresolved,'factCoverage':coverage,
             'realization':'Idol C backend then cc -O2 native shared object; test-only ABI bridge'}
    (OUT/(name+'.receipt.json')).write_text(json.dumps(receipt,indent=2)+'\n')
    loaded=ctypes.CDLL(str(lib)); fn=loaded.eyes_probe
    fn.argtypes=[ctypes.c_void_p,ctypes.c_int64,ctypes.c_void_p]; fn.restype=ctypes.c_int64
    return fn

SOURCE=(ROOT/'protocol/ingress.id').read_text()
FN=build(SOURCE,'candidate')

def invoke(value, declared=None):
    data=value.encode() if isinstance(value,str) else value
    buf=ctypes.create_string_buffer(data)
    slots=(ctypes.c_int64*8)(*([-999]*8))
    rc=FN(ctypes.addressof(buf),len(data) if declared is None else declared,ctypes.addressof(slots))
    return rc,list(slots),data

def span(data,start,end):
    return data[start-1:end-1]

class Ingress(unittest.TestCase):
    def good(self, text):
        rc,slots,data=invoke(text)
        self.assertIn(rc,(0,1),(rc,text))
        return slots,data
    def bad(self,text):
        rc,slots,_=invoke(text)
        self.assertLess(rc,0,(rc,text))
        self.assertEqual(slots,[0]*8,'failed parse leaked partial fields')
    def test_request(self):
        slots,data=self.good('{"jsonrpc":"2.0","id":0,"method":"tools/call","params":{"name":"apply","arguments":{}}}')
        self.assertEqual(span(data,slots[0],slots[1]),b'0')
        self.assertEqual(span(data,slots[2],slots[3]),b'"tools/call"')
        self.assertEqual(json.loads(span(data,slots[4],slots[5])),{'name':'apply','arguments':{}})
    def test_notification(self):
        self.assertEqual(invoke('{"jsonrpc":"2.0","method":"notifications/cancelled","params":{"requestId":0}}')[0],1)
    def test_opaque_method_no_dispatch(self):
        slots,data=self.good('{"jsonrpc":"2.0","id":"request","method":"unknown","params":{"text":"tools/call"}}')
        self.assertEqual(span(data,slots[2],slots[3]),b'"unknown"')
    def test_embedded_field_is_not_request_field(self):
        self.bad('{"jsonrpc":"2.0","id":1,"params":{"method":"tools/call"}}')
    def test_id_large_lexeme_preserved(self):
        slots,data=self.good('{"method":"ping","id":92233720368547758081234567890,"jsonrpc":"2.0"}')
        self.assertEqual(span(data,slots[0],slots[1]),b'92233720368547758081234567890')
    def test_whitespace_field_order_and_escapes(self):
        slots,data=self.good(' { "metho\\u0064" : "ping", "id": "a\\\"b\\u0000", "jsonrpc" : "2.0" } ')
        self.assertEqual(json.loads(span(data,slots[0],slots[1])),'a"b\x00')
    def test_duplicate_control_keys(self):
        for key,value in {'id':'2','method':'"ping"','jsonrpc':'"2.0"','params':'{}'}.items():
            text='{"jsonrpc":"2.0","id":1,"method":"ping","params":{},"'+key+'":'+value+'}'
            with self.subTest(key=key): self.bad(text)
        self.bad('{"jsonrpc":"2.0","id":1,"method":"ping","metho\\u0064":"tools/call"}')
    def test_tool_name_is_structural(self):
        slots,data=self.good('{"jsonrpc":"2.0","id":1,"method":"tools/call","params":{"arguments":{"name":"evil"},"na\\u006de":"apply"}}')
        self.assertEqual(span(data,slots[6],slots[7]),b'"apply"')
    def test_tool_call_boundary(self):
        for params in ('{}','{"name":null}','{"name":""}','{"name":"apply","name":"other"}',
                       '{"name":"apply","arguments":[]}', '{"name":"apply","arguments":{},"arguments":{}}',
                       '{"name":"apply","_meta":1}', '{"name":"apply","_meta":{},"_meta":{}}'):
            with self.subTest(params=params): self.bad('{"jsonrpc":"2.0","id":1,"method":"tools/call","params":'+params+'}')
    def test_integral_json_number_ids(self):
        for ident in ('1.0','1e3','100e-2','0e-99999','1.000e0','-0.00','12.5e1'):
            with self.subTest(ident=ident):
                slots,data=self.good('{"jsonrpc":"2.0","id":'+ident+',"method":"ping"}')
                self.assertEqual(span(data,slots[0],slots[1]),ident.encode())
        for ident in ('1e-3','1.01','12.5e-1','1e-99999999999999999'):
            with self.subTest(ident=ident): self.bad('{"jsonrpc":"2.0","id":'+ident+',"method":"ping"}')
    def test_wrong_envelope(self):
        for text in ('[]','null','{}','{"method":"ping","id":1}',
                     '{"jsonrpc":"1.0","method":"ping","id":1}',
                     '{"jsonrpc":"2.0","method":{},"id":1}',
                     '{"jsonrpc":"2.0","method":"ping","id":null}',
                     '{"jsonrpc":"2.0","method":"ping","id":true}',
                     '{"jsonrpc":"2.0","method":"ping","id":1.5}',
                     '{"jsonrpc":"2.0","method":"ping","id":1,"result":{}}',
                     '{"jsonrpc":"2.0","method":"ping","id":1,"params":[]}'):
            with self.subTest(text=text): self.bad(text)
    def test_json_malformed(self):
        for value in ('01','+1','1.','1e','--1','NaN','Infinity','[1,]','{"a":1,}',
                      '"\\x41"','"\\uD800"','"\\uDC00"','"\\uD800\\u0041"','"\x00"','"\n"',
                      'true false','[}','{"x" 1}','"unterminated'):
            with self.subTest(value=value): self.bad('{"jsonrpc":"2.0","id":1,"method":"ping","params":{"x":'+value+'}}')
    def test_utf8(self):
        for raw in (b'\x80',b'\xc0\xaf',b'\xed\xa0\x80',b'\xf4\x90\x80\x80',b'\xf5\x80\x80\x80',b'\xe2\x82'):
            with self.subTest(raw=raw): self.bad(b'{"jsonrpc":"2.0","id":1,"method":"ping","params":{"x":"'+raw+b'"}}')
        self.good('{"jsonrpc":"2.0","id":1,"method":"ping","params":{"x":"中国🦋\\uD83D\\uDE00"}}')
    def test_limits_and_boundaries(self):
        self.bad(b' '*65537)
        self.bad('{"jsonrpc":"2.0","id":1,"method":"ping","params":{"x":'+'['*65+'0'+']'*65+'}}')
        self.bad('{"jsonrpc":"2.0","id":1,"method":"ping","params":{'+','.join('"k%d":0'%n for n in range(129))+'}}')
        self.assertLess(invoke(b'',-1)[0],0)
    def test_trailing_bytes(self):
        for ending in ('{}','null','x','\x00'):
            self.bad('{"jsonrpc":"2.0","id":1,"method":"ping"}'+ending)
    def test_random_valid_payloads(self):
        random.seed(193)
        def value(depth=0):
            choices=[None,True,False,random.randint(-10**15,10**15),random.random(),''.join(random.choices('abc\\"😀汉字\n\t',k=random.randrange(20)))]
            if depth<3:
                choices.extend([[value(depth+1) for _ in range(random.randrange(4))],{str(i):value(depth+1) for i in range(random.randrange(4))}])
            return random.choice(choices)
        for n in range(300):
            msg={'jsonrpc':'2.0','id':n,'method':'tools/call','params':{'name':'apply','arguments':{'payload':value()}}}
            text=json.dumps(msg,ensure_ascii=bool(n%2),separators=(',',':'))
            with self.subTest(n=n):
                slots,data=self.good(text)
                self.assertEqual(json.loads(span(data,slots[4],slots[5])),msg['params'])

if __name__=='__main__': unittest.main()
