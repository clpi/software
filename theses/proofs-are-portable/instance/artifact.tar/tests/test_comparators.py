"""Comparison-contract regressions, not desktop execution or performance proof."""
import copy
import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SPEC = importlib.util.spec_from_file_location('comparison_check', ROOT / 'tools/check.py')
CHECK = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(CHECK)


class Comparators(unittest.TestCase):
    def setUp(self):
        self.project = json.loads((ROOT / 'eyes.json').read_text())

    def test_both_owner_requested_comparators_are_mandatory(self):
        self.assertEqual(set(self.project.get('comparisons', [])),
                         {'bench/peekaboo.json', 'bench/agent-desktop.json'})
        self.assertTrue(callable(getattr(CHECK, 'catalog', None)))
        rows = CHECK.catalog(ROOT, self.project)
        self.assertEqual({c['baseline']['repository'] for c in rows},
                         {'openclaw/Peekaboo', 'vercel-labs/agent-desktop'})

    def desktop(self):
        return json.loads((ROOT / 'bench/agent-desktop.json').read_text())

    def test_source_and_release_are_separate_exact_pins(self):
        c = self.desktop()
        self.assertEqual(c['baseline']['commit'], 'b43ac4f6e892ef608f8851428613c4009f0e84c7')
        self.assertEqual(c['baseline']['released']['commit'], '2b0a7334fc111730454b726e6800aa41cdafc093')
        self.assertNotEqual(c['baseline']['commit'], c['baseline']['released']['commit'])
        self.assertIsNone(c['baseline']['binarySha256'])

    def test_every_root_command_and_nested_command_has_a_case(self):
        c = self.desktop()
        names = c['commandSurface']['names']
        self.assertEqual(len(names), 60)
        self.assertEqual(len(set(names)), 60)
        cases = {r['label'] for r in c['cases']}
        self.assertTrue({'command.' + x for x in names} <= cases)
        for parent, children in c['commandSurface']['subcommands'].items():
            self.assertTrue({'command.' + parent + '.' + x for x in children} <= cases)
        self.assertEqual(sum(map(len, c['commandSurface']['subcommands'].values())), 11)

    def test_four_held_input_names_are_refusal_contracts(self):
        c = self.desktop()
        refused = set(c['commandSurface']['refusalOnly'])
        self.assertEqual(refused, {'key-down','key-up','mouse-down','mouse-up'})
        for row in c['cases']:
            if row.get('command') in refused:
                self.assertEqual(row['expectation'], 'safe-refusal')

    def test_platform_modes_and_execution_routes_cannot_be_omitted(self):
        c = self.desktop()
        self.assertEqual(len(c['profiles']), 8)
        self.assertEqual(set(c['routes']), {'cli-cold','mcp-persistent','ffi-in-process'})
        for field in ('profiles', 'routes'):
            damaged = copy.deepcopy(c); damaged[field].pop()
            self.assertTrue(CHECK.validate(self.project, damaged), field)

    def test_missing_command_is_rejected_even_with_adjusted_count(self):
        c = self.desktop(); c['commandSurface']['names'].pop()
        c['commandSurface']['count'] = len(c['commandSurface']['names'])
        self.assertTrue(CHECK.validate(self.project, c))

    def test_same_count_command_substitution_is_rejected(self):
        c = self.desktop(); c['commandSurface']['names'][0] = 'invented-command'
        self.assertTrue(CHECK.validate(self.project, c))

    def test_missing_semantic_obligation_is_rejected(self):
        c = self.desktop()
        c['cases'] = [r for r in c['cases'] if r['label'] != 'semantic.identity']
        self.assertTrue(CHECK.validate(self.project, c))

    def test_missing_metric_is_rejected(self):
        c = self.desktop(); c['metrics'].pop()
        self.assertTrue(CHECK.validate(self.project, c))

    def test_duplicate_metrics_are_rejected(self):
        c = self.desktop(); c['metrics'].append(copy.deepcopy(c['metrics'][0]))
        self.assertTrue(CHECK.validate(self.project, c))

    def test_empty_case_requirement_is_rejected(self):
        c = self.desktop(); c['cases'][0]['requirement'] = '   '
        self.assertTrue(CHECK.validate(self.project, c))

    def test_source_registry_and_release_cannot_float(self):
        for field in ('commit', 'blob'):
            c = self.desktop(); c['sourceRegistry'][field] = 'main'
            self.assertTrue(CHECK.validate(self.project, c))
        c = self.desktop(); c['baseline']['released']['commit'] = 'latest'
        self.assertTrue(CHECK.validate(self.project, c))

    def test_prior_measurements_cannot_be_imported_as_success(self):
        for value in (True, 'false', 0):
            c = self.desktop(); c['superiorityEstablished'] = value
            self.assertTrue(CHECK.validate(self.project, c))
        for state in ('passing', 'equal', 'unsupported', 'skipped'):
            c = self.desktop(); c['cases'][0]['state'] = state
            self.assertTrue(CHECK.validate(self.project, c))

    def test_external_comparator_cannot_become_runtime(self):
        c = self.desktop(); c['baseline']['runtimeDependency'] = True
        self.assertTrue(CHECK.validate(self.project, c))

    def test_malformed_objects_fail_closed(self):
        for value in (None, 1, False, [], 'text'):
            self.assertTrue(CHECK.validate(self.project, value))
        for field in ('baseline', 'sourceRegistry', 'commandSurface'):
            c = self.desktop(); c[field] = None
            self.assertTrue(CHECK.validate(self.project, c))

    def test_catalog_removal_is_rejected(self):
        self.project['comparisons'] = ['bench/peekaboo.json']
        with self.assertRaises(ValueError): CHECK.catalog(ROOT, self.project)

    def test_duplicate_catalog_entry_is_rejected(self):
        self.project['comparisons'] *= 2
        with self.assertRaises(ValueError): CHECK.catalog(ROOT, self.project)

    def test_escaping_catalog_path_is_rejected(self):
        for path in ('../external.json', '/tmp/external.json', 'bench/../eyes.json'):
            p = copy.deepcopy(self.project); p['comparisons'][-1] = path
            with self.assertRaises(ValueError): CHECK.catalog(ROOT, p)

    def test_symlink_catalog_path_is_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td); (root/'bench').mkdir()
            for name in ('peekaboo.json', 'agent-desktop.json'):
                (root/'bench'/name).symlink_to(ROOT/'bench'/name)
            with self.assertRaises(ValueError): CHECK.catalog(root, self.project)

    def test_duplicate_json_member_is_rejected(self):
        with self.assertRaises(ValueError): CHECK.decode('{"a":1,"a":2}')
        with self.assertRaises(ValueError): CHECK.decode('{"a":NaN}')

    def test_malformed_nested_case_values_return_errors(self):
        for value in (None, [], {}, False, 1):
            for field in ('label', 'requirement', 'state'):
                c = self.desktop(); c['cases'][0][field] = value
                self.assertTrue(CHECK.validate(self.project, c), (field, value))

    def test_source_inventory_parser_happy_path_is_only_a_unit_fixture(self):
        import hashlib
        data = b'CommandMetadata::new("sample-a", true)\nCommandMetadata::new("sample-b", false)\n'
        fixture = self.desktop()
        fixture['sourceRegistry']['blob'] = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
        fixture['commandSurface']['names'] = ['sample-b', 'sample-a']
        self.assertEqual(CHECK.inventory(data, fixture), ['sample-a', 'sample-b'])
        self.assertTrue(CHECK.validate(self.project, fixture), 'synthetic parser fixture must never qualify the real comparator')

    def test_source_inventory_needs_exact_bytes_and_complete_names(self):
        c = self.desktop()
        with self.assertRaises(ValueError): CHECK.inventory(b'not the pinned registry', c)

    def test_successful_contract_check_is_not_qualification(self):
        r = subprocess.run([sys.executable, '-S', str(ROOT/'tools/check.py'), '--coverage'], capture_output=True, text=True)
        self.assertEqual(r.returncode, 0, r.stderr)
        data = json.loads(r.stdout)
        self.assertEqual(data['qualification'], 'unqualified')
        self.assertEqual(data['measuredCells'], 0)
        self.assertEqual(data['comparators']['vercel-labs/agent-desktop']['commandNames'], 60)
        self.assertGreater(data['comparators']['vercel-labs/agent-desktop']['requiredCells'], 1400)

    def test_release_gate_refuses_actual_unmeasured_catalog(self):
        r = subprocess.run([sys.executable, '-S', str(ROOT/'tools/check.py'), '--require-qualified'], capture_output=True, text=True)
        self.assertEqual(r.returncode, 2, r.stdout+r.stderr)
        self.assertIn('UNQUALIFIED', r.stderr)


if __name__ == '__main__':
    unittest.main(verbosity=2)
