import json
import os
import sys
import pathlib
import shutil
import subprocess
import tempfile
import unittest

ROOT = pathlib.Path(__file__).resolve().parents[1]

class Delivery(unittest.TestCase):
    def test_launcher_requires_source_build(self):
        with tempfile.TemporaryDirectory() as directory:
            root = pathlib.Path(directory)
            shutil.copy2(ROOT / 'mcp', root / 'mcp')
            result = subprocess.run([str(root / 'mcp')], capture_output=True)
            self.assertEqual(result.returncode, 69)
            self.assertIn(b'make server', result.stderr)
            self.assertEqual(result.stdout, b'')

    def test_launcher_executes_only_local_build(self):
        with tempfile.TemporaryDirectory() as directory:
            root = pathlib.Path(directory)
            shutil.copy2(ROOT / 'mcp', root / 'mcp')
            (root / '.build').mkdir()
            binary = root / '.build/eyes'
            binary.write_text('#!/bin/sh\nprintf "local-build\\n"\n')
            binary.chmod(0o755)
            result = subprocess.run([str(root / 'mcp')], capture_output=True)
            self.assertEqual((result.returncode, result.stdout), (0, b'local-build\n'))

    def test_missing_compiler_retains_failed_result(self):
        with tempfile.TemporaryDirectory() as directory:
            output = pathlib.Path(directory) / 'evidence'
            env = {k: v for k, v in os.environ.items() if k not in ('IDOL', 'IDOL_RUNTIME')}
            result = subprocess.run([sys.executable, str(ROOT / 'tools/verify.py'), '--output', str(output)], env=env, capture_output=True)
            self.assertEqual(result.returncode, 1)
            report = json.loads((output / 'report.json').read_text())
            self.assertEqual(report['outcome'], 'failed')
            self.assertEqual(report['runs'], [])
            self.assertIn('IDOL', report['error']['message'])

    def test_verification_never_overwrites_an_existing_result(self):
        with tempfile.TemporaryDirectory() as directory:
            output = pathlib.Path(directory)
            marker = output / 'report.json'
            marker.write_text('existing result')
            result = subprocess.run([sys.executable, str(ROOT / 'tools/verify.py'), '--output', str(output)], capture_output=True)
            self.assertNotEqual(result.returncode, 0)
            self.assertEqual(marker.read_text(), 'existing result')

if __name__ == '__main__':
    unittest.main(verbosity=2)
