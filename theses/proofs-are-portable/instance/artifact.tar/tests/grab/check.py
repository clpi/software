#!/usr/bin/env python3
"""Fixture battery for the capture coordination discipline
(docs/grab.md).

Runs a compiled grab binary (GRAB_BIN) against canned fact
blocks and checks the mocked arms of spec case A-O6's
coordination control:

  primary ok        pixels on the primary path, the record
                    says so, no blocker named;
  coordinated seat  a coordination failure with a coordinated
                    capture process also present still takes
                    the classic path only for an uncoordinated
                    blocker;
  blocker named     coordination failure, an uncoordinated
                    capture process present, fallback ok:
                    success on the classic path with the
                    blocker and its pid in the record;
  fallback fails    the same seat with a failed fallback
                    refuses by name with the blocker
                    identified in the refusal;
  no blocker        coordination failure, no process lines,
                    fallback failed: R-INTERNAL whose message
                    states that no blocking process was
                    identified - never an opaque failure;
  unstated fallback a coordination outcome with fallback
                    none refuses R-ARGS;
  permission        refuses R-PERM and tries no other path;
  platform          refuses R-PLATFORM and tries no other
                    path;
  bad facts         an unknown primary outcome and an
                    unknown command refuse R-ARGS.

The live arm (a deliberately uncoordinated process planted
on a real seat) is the capture coordination runbook in the
lane record of 2026-11-07; it is not run here.
"""
import json
import os
import subprocess
import sys


def run(binary, text):
    process = subprocess.run([binary], input=text,
                             capture_output=True, text=True, timeout=30)
    if process.returncode != 0:
        raise SystemExit("grab program failed: " + process.stderr.strip())
    return process.stdout.strip()


def main():
    binary = os.environ.get("GRAB_BIN", "./grab")
    failures = []

    def arm(name, condition, detail=""):
        print(("ok   " if condition else "FAIL ") + name +
              ((" - " + detail) if detail and not condition else ""))
        if not condition:
            failures.append(name)

    ok = json.loads(run(binary, "capture\nR\tok\nF\tnone\n"))
    arm("primary success names the primary path",
        ok.get("ok") is True and ok.get("data", {}).get("path") == "primary"
        and ok.get("data", {}).get("blocker") == "", json.dumps(ok))

    seat = ("R\tcoordination\nF\tok\n"
            "P\t4100\t1\tCoordinated Capture\n"
            "P\t4242\t0\tPeekaboo Bridge Capture\n")
    classic = json.loads(run(binary, "capture\n" + seat))
    data = classic.get("data", {})
    arm("coordination failure takes the classic path by name",
        classic.get("ok") is True and data.get("path") == "classic",
        json.dumps(classic))
    arm("the record names the uncoordinated blocker",
        data.get("blocker") == "Peekaboo Bridge Capture" and
        data.get("blocker_pid") == "4242", json.dumps(classic))

    failed = json.loads(run(binary, "capture\n" +
                            seat.replace("F\tok", "F\tfail")))
    error = failed.get("error", {})
    arm("a failed fallback refuses by name with the blocker identified",
        failed.get("ok") is False and error.get("code") == "R-PLATFORM" and
        error.get("blocker") == "Peekaboo Bridge Capture" and
        error.get("blocker_pid") == "4242", json.dumps(failed))

    noblock = json.loads(run(binary, "capture\nR\tcoordination\nF\tfail\n"))
    error = noblock.get("error", {})
    arm("no blocker and a failed fallback is never opaque",
        noblock.get("ok") is False and error.get("code") == "R-INTERNAL" and
        "no blocking process identified" in error.get("message", ""),
        json.dumps(noblock))

    noblockok = json.loads(run(binary, "capture\nR\tcoordination\nF\tok\n"))
    arm("no blocker with a working fallback records the classic path",
        noblockok.get("ok") is True and
        noblockok.get("data", {}).get("path") == "classic" and
        "no blocking process identified" in
        noblockok.get("data", {}).get("note", ""), json.dumps(noblockok))

    unstated = json.loads(run(binary, "capture\nR\tcoordination\nF\tnone\n"
                              "P\t4242\t0\tPeekaboo Bridge Capture\n"))
    arm("an unstated fallback outcome refuses R-ARGS",
        unstated.get("error", {}).get("code") == "R-ARGS",
        json.dumps(unstated))

    perm = json.loads(run(binary, "capture\nR\tpermission\nF\tok\n"))
    arm("a permission failure refuses R-PERM",
        perm.get("error", {}).get("code") == "R-PERM", json.dumps(perm))

    plat = json.loads(run(binary, "capture\nR\tplatform\nF\tok\n"))
    arm("a platform failure refuses R-PLATFORM",
        plat.get("error", {}).get("code") == "R-PLATFORM", json.dumps(plat))

    bad = json.loads(run(binary, "capture\nR\tmystery\nF\tok\n"))
    arm("an unknown primary outcome refuses R-ARGS",
        bad.get("error", {}).get("code") == "R-ARGS", json.dumps(bad))

    other = json.loads(run(binary, "snapshot\nR\tok\n"))
    arm("an unknown command refuses R-ARGS",
        other.get("error", {}).get("code") == "R-ARGS", json.dumps(other))

    print("grab battery: %s" % ("FAIL " + ", ".join(failures)
                                if failures else "all arms ok"))
    return 1 if failures else 0


if __name__ == "__main__":
    sys.exit(main())
