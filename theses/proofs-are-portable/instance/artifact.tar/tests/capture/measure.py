"""Paired real-display capture: default, exact-reconstruction delta, and changing scenes."""
import base64, hashlib, io, json, math, os, pathlib, platform, random, select, statistics, subprocess, sys, tempfile, time
from PIL import Image
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tests/server'))
import check
OUT=pathlib.Path(os.environ['EVIDENCE']).resolve();OUT.mkdir(parents=True,exist_ok=False)
paths={k:pathlib.Path(os.environ[k.upper()]).resolve() for k in ('baseline','candidate')}
rng=random.Random(20261101)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def stats(values):
 a=sorted(values);return {'medianNs':statistics.median(a),'p95Ns':a[math.ceil(.95*len(a))-1],'p99Ns':a[math.ceil(.99*len(a))-1]}
def expected(x,y,mode,seed):
 v=0x336699+seed
 if mode:
  v=(x*1664525+y*1013904223+12345+seed)&0xffffffff
  v=(v^(v<<13))&0xffffffff;v=(v^(v>>17))&0xffffffff;v=(v^(v<<5))&0xffffffff
 return ((v>>16)&255,(v>>8)&255,v&255)
# Count the actual returned bytes; decoding the line remains part of the timed request.
class Client(check.Client):
 def recv(self, timeout=3):
  end=time.monotonic()+timeout
  while b'\n' not in self.buf:
   if not select.select([self.p.stdout],[],[],max(0,end-time.monotonic()))[0]:raise TimeoutError('response deadline')
   chunk=os.read(self.p.stdout.fileno(),65536)
   if not chunk:raise RuntimeError('server ended: '+self.p.stderr.read().decode())
   self.buf+=chunk
  line,self.buf=self.buf.split(b'\n',1);self.wirebytes=len(line)+1;return json.loads(line)
report={'schema':'idol.eyes.capture.paired.v2','scope':'Same owned Linux/Xvfb scene and exact RGB observation. Timed client send through complete parsed MCP response; independent PNG decode/materialization outside timer. Delta mode maintains exact prior image; it is not wire-identical to full mode. Not a competitor campaign.','platform':platform.platform(),'clock':'perf_counter_ns','estimand':'geometric mean of paired baseline/candidate latency ratios; 95% percentile bootstrap of paired log ratios; exploratory, no multiplicity correction','binaries':{k:{'sha256':sha(v),'bytes':v.stat().st_size} for k,v in paths.items()},'rows':[]}
with tempfile.TemporaryDirectory(prefix='eyes-capture-bench-') as td:
 temp=pathlib.Path(td)
 subprocess.run(['cc','-O2','-Wall','-Wextra','-Werror',ROOT/'tests/capture/scene.c','-lX11','-o',temp/'scene'],check=True)
 x=subprocess.Popen(['Xvfb','-displayfd','1','-screen','0','640x480x24','-nolisten','tcp'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
 try:
  assert select.select([x.stdout],[],[],5)[0],'display startup timeout'
  display=x.stdout.readline().strip().decode();assert display.isdecimal()
  env={k:v for k,v in os.environ.items() if not k.startswith('IDOL_EYES_')};env.update(DISPLAY=':'+display,IDOL_EYES_X11='allow')
  for mode in (0,1):
   for demand in ('full','incremental','changing'):
    scene=subprocess.Popen([str(temp/'scene'),str(mode)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=env)
    clients={};seed=0
    try:
     assert select.select([scene.stdout],[],[],5)[0] and scene.stdout.readline()==b'ready\n'
     for k,path in paths.items():check.BINARY=path;clients[k]=Client(env);clients[k].init()
     for w,h in ((16,16),(64,64),(128,128),(512,384)):
      pairs=[];args={'x':0,'y':0,'width':w,'height':h};prior=None;materialized=None
      context=clients['candidate'].call('tools/call',{'name':'observe','arguments':{}})['result']['structuredContent']['context']
      for iteration in range(31):
       if demand=='changing':
        scene.stdin.write(b'n');scene.stdin.flush();seed+=1
        assert select.select([scene.stdout],[],[],5)[0] and scene.stdout.readline()==b'ready\n'
       want=[expected(xx,yy,mode,seed) for yy in range(h) for xx in range(w)]
       order=list(clients);rng.shuffle(order);pair={'order':order}
       for name in order:
        arguments=dict(args)
        if name=='candidate' and demand!='full':
         arguments.update(context=context,since=prior['frame'] if prior else 0)
        start=time.perf_counter_ns();r=clients[name].call('tools/call',{'name':'capture','arguments':arguments});elapsed=time.perf_counter_ns()-start
        assert 'result' in r and not r['result'].get('isError'),r
        result=r['result'];images=[c for c in result['content'] if c['type']=='image'];state=result.get('structuredContent')
        if images:
         assert len(images)==1
         raw=base64.b64decode(images[0]['data'],validate=True)
         im=Image.open(io.BytesIO(raw));assert im.size==(w,h);pixels=list(im.get_flattened_data())
         assert pixels==want
         if name=='candidate':materialized=pixels
        else:
         assert name=='candidate' and demand=='incremental' and prior and state['unchanged']
         assert state['frame']==prior['frame'] and state['context']==prior['context']
         assert materialized==want;raw=b''
        if name=='candidate':prior=state
        pair[name]=elapsed;pair[name+'PngBytes']=len(raw);pair[name+'WireBytes']=clients[name].wirebytes
       if iteration>=10:pairs.append(pair)
      logs=[math.log(p['baseline']/p['candidate']) for p in pairs]
      boots=sorted(math.exp(statistics.mean(rng.choices(logs,k=len(logs)))) for _ in range(4000))
      row={'scene':'noise' if mode else 'flat','demand':demand,'width':w,'height':h,'rounds':len(pairs),'warmups':10,'baseline':stats([p['baseline'] for p in pairs]),'candidate':stats([p['candidate'] for p in pairs]),'geometricPairedSpeedRatio':math.exp(statistics.mean(logs)),'pairedBootstrap95':[boots[100],boots[3899]],'pairs':pairs}
      report['rows'].append(row)
      print(row['scene'],demand,w,h,'ratio',round(row['geometricPairedSpeedRatio'],3),'CI',row['pairedBootstrap95'],flush=True)
      (OUT/'measurement.json').write_text(json.dumps(report,indent=2)+'\n')
    finally:
     for c in clients.values():c.close()
     scene.stdin.close();scene.wait(timeout=5);assert scene.returncode==0
     error=scene.stderr.read();assert not error,error
     scene.stdout.close();scene.stderr.close()
 finally:
  x.terminate();x.wait(timeout=5);x.stdout.close();x.stderr.close()
report['complete']=len(report['rows'])==24
(OUT/'measurement.json').write_text(json.dumps(report,indent=2)+'\n')
