"""Execute the real Idol capture with synthetic XImage layouts and a separate PNG oracle."""
import ctypes as C
import hashlib, io, itertools, json, os, pathlib, random, re, subprocess, tempfile, unittest
from PIL import Image
ROOT=pathlib.Path(__file__).resolve().parents[2]
OUT=pathlib.Path(os.environ['EVIDENCE']).resolve(); OUT.mkdir(parents=True,exist_ok=False)
IDOL=pathlib.Path(os.environ['IDOL']).resolve()
def command(args,name):
 p=subprocess.run(list(map(str,args)),capture_output=True,timeout=90)
 (OUT/(name+'.log')).write_bytes(p.stdout+p.stderr)
 if p.returncode:raise RuntimeError(name+': '+p.stderr.decode(errors='replace'))
 return p.stdout
command(['cc','-std=c11','-O2',ROOT/'tests/server/layout.c','-o',OUT/'layout'],'layout-build')
layout=command([OUT/'layout'],'layout').decode()
SOURCE=pathlib.Path(os.environ.get('CAPTURE_SOURCE', ROOT/'protocol/capture.id')).resolve()
source=SOURCE.read_text()
if os.environ.get('CAPTURE_COUNT')=='1':
 old=re.search(r'channel: i64 = [^\n]*\n',source).group(0)
 assert source.count(old)==1
 source='@ffi("eyes_tick")\ntick: void = ()\n\n'+source.replace(old,old+'  tick()\n')
source=layout+'\n@ffi("XDefaultScreen")\nscreen: i32 = (device: ptr)\n@ffi("XRootWindow")\nroot: u64 = (device: ptr, index: i32)\n'+source.replace('capture: i64 =','--- @export\ncapture: i64 =')
(OUT/'capture.id').write_text(source)
command([IDOL,'compile','--no-cache','--backend=c','--emit','c',OUT/'capture.id','-o',OUT/'capture.c'],'compile')
graph=json.loads(command([IDOL,'graph',OUT/'capture.id'],'graph'))
assert graph['blocking_applications']==[]
entry=[n for n in graph['nodes'] if n.get('kind')=='func' and n.get('name')=='capture'];assert len(entry)==1
links=[x for x in graph['callable_linkages'] if x.get('callable')==entry[0]['id'] and x.get('origin')=='idol'];assert len(links)==1
symbol=links[0]['symbol'];assert re.fullmatch('[A-Za-z_][A-Za-z0-9_]*',symbol)
cachearg=',cache' if 'cache: *i64)' in source else ''
(OUT/'bridge.c').write_text('#include "capture.c"\nint64_t eyes_probe(int64_t w,int64_t h,int64_t raster,int64_t png,int64_t length,int64_t cache){return '+symbol+'(0,0,0,w,h,raster,png,length'+cachearg+');}\n')
command(['cc','-std=c11','-O2','-fPIC','-shared','-Wno-builtin-declaration-mismatch',OUT/'bridge.c',ROOT/'tests/capture/platform.c',pathlib.Path(os.environ['IDOL_RUNTIME']).resolve(),'-Wl,-z,defs','-Wl,-Bsymbolic-functions','-lm','-lz','-ldl','-o',OUT/'capture.so'],'link')
lib=C.CDLL(str(OUT/'capture.so'));lib.eyes_image.argtypes=[C.c_void_p]+[C.c_int]*5+[C.c_ulong]*3
lib.eyes_probe.argtypes=[C.c_int64,C.c_int64,C.c_void_p,C.c_void_p,C.c_void_p,C.c_void_p];lib.eyes_probe.restype=C.c_int64
lib.eyes_calls.restype=C.c_uint64;lib.eyes_releases.restype=C.c_uint64

def sample(bits=32,order=0,masks=(0xff0000,0xff00,0xff),w=17,h=9,pad=3,seed=1):
 rng=random.Random(seed);stride=w*(bits//8)+pad;data=bytearray([0xcd]*(stride*h));expected=[]
 for y in range(h):
  for x in range(w):
   pixel=rng.randrange(1<<bits);at=y*stride+x*(bits//8)
   data[at:at+bits//8]=pixel.to_bytes(bits//8,'little' if order==0 else 'big')
   rgb=[]
   for mask in masks:
    shift=(mask & -mask).bit_length()-1; maximum=mask>>shift
    rgb.append(((pixel&mask)>>shift)*255//maximum)
   expected.append(tuple(rgb))
 return data,expected,stride

def invoke(data,w,h,stride,bits,order,masks,reuse=None):
 raw=(C.c_ubyte*len(data)).from_buffer_copy(data)
 raster,png,length,cache = reuse or ((C.c_ubyte*1048576)(),(C.c_ubyte*1048576)(),C.c_int64(),(C.c_int64*4)())
 lib.eyes_image(raw,w,h,stride,bits,order,*masks)
 rc=lib.eyes_probe(w,h,raster,png,C.byref(length),cache)
 assert lib.eyes_releases()==1,'snapshot not released exactly once'
 assert lib.eyes_images()==1,'cache substituted for fresh platform capture'
 return rc,bytes(png[:max(rc,0)])

class Capture(unittest.TestCase):
 def test_all_layouts_reuse_only_exact_observable_pixels(self):
  formats=[(16,(0xf800,0x7e0,0x1f)),(16,(0x7c00,0x3e0,0x1f)),(32,(0x3ff00000,0xffc00,0x3ff))]
  formats += [(bits,m) for bits in (24,32) for m in itertools.permutations((0xff0000,0xff00,0xff))]
  for bits,masks in formats:
   for order in (0,1):
    with self.subTest(bits=bits,masks=masks,order=order):
     reuse=((C.c_ubyte*1048576)(),(C.c_ubyte*1048576)(),C.c_int64(),(C.c_int64*4)())
     raw,want,stride=sample(bits,order,masks,w=17,h=9,pad=3)
     rc,first=invoke(raw,17,9,stride,bits,order,masks,reuse);self.assertGreater(rc,0)
     rc,second=invoke(raw,17,9,stride,bits,order,masks,reuse);self.assertEqual(first,second);self.assertEqual(lib.eyes_encodings(),0)
     # Alter only padding and unused channels. Observable RGB remains exactly equal.
     for row in range(9): raw[(row+1)*stride-1]^=0xff
     ignored=((1<<bits)-1) ^ (masks[0]|masks[1]|masks[2])
     value=int.from_bytes(raw[:bits//8], 'little' if order==0 else 'big') ^ ignored
     raw[:bits//8]=value.to_bytes(bits//8,'little' if order==0 else 'big')
     rc,third=invoke(raw,17,9,stride,bits,order,masks,reuse);self.assertEqual(first,third);self.assertEqual(lib.eyes_encodings(),0)
     # Change all meaningful channels of the last pixel. No tail may escape comparison.
     at=8*stride+16*(bits//8)
     pixel=int.from_bytes(raw[at:at+bits//8],'little' if order==0 else 'big') ^ (masks[0]|masks[1]|masks[2])
     raw[at:at+bits//8]=pixel.to_bytes(bits//8,'little' if order==0 else 'big')
     rc,last=invoke(raw,17,9,stride,bits,order,masks,reuse);self.assertGreater(rc,0);self.assertEqual(lib.eyes_encodings(),1)
     im=Image.open(io.BytesIO(last));actual=list(im.get_flattened_data());self.assertEqual(actual[:-1],want[:-1]);self.assertNotEqual(actual[-1],want[-1])
 def test_failed_encoding_cannot_resurrect_old_png(self):
  reuse=((C.c_ubyte*1048576)(),(C.c_ubyte*1048576)(),C.c_int64(),(C.c_int64*4)())
  masks=(0xff0000,0xff00,0xff);raw,want,stride=sample(w=17,h=9,pad=3)
  rc,original=invoke(raw,17,9,stride,32,0,masks,reuse);self.assertGreater(rc,0)
  raw[0]^=0xff;lib.eyes_failencode(1)
  try:
   rc,_=invoke(raw,17,9,stride,32,0,masks,reuse);self.assertEqual(rc,-1);self.assertEqual(reuse[3][0],0)
  finally:lib.eyes_failencode(0)
  rc,recovered=invoke(raw,17,9,stride,32,0,masks,reuse);self.assertGreater(rc,0);self.assertEqual(lib.eyes_encodings(),1);self.assertNotEqual(recovered,original)
  actual=list(Image.open(io.BytesIO(recovered)).get_flattened_data());self.assertEqual(actual[0],(want[0][0],want[0][1],want[0][2]^255));self.assertEqual(actual[1:],want[1:])
 def test_dimension_and_failure_invalidate_reuse(self):
  reuse=((C.c_ubyte*1048576)(),(C.c_ubyte*1048576)(),C.c_int64(),(C.c_int64*4)());masks=(0xff0000,0xff00,0xff)
  for w,h in [(64,32),(32,64),(512,512),(1,1),(17,9)]:
   raw,want,stride=sample(w=w,h=h,pad=7);rc,png=invoke(raw,w,h,stride,32,0,masks,reuse)
   self.assertGreater(rc,0);im=Image.open(io.BytesIO(png));self.assertEqual(im.size,(w,h));self.assertEqual(list(im.get_flattened_data()),want)
  bad=(0xf50000,0xff00,0xff);rc,_=invoke(raw,17,9,stride,32,0,bad,reuse);self.assertEqual(rc,-1);self.assertEqual(reuse[3][0],0)
  rc,png=invoke(raw,17,9,stride,32,0,masks,reuse);self.assertGreater(rc,0);self.assertEqual(lib.eyes_encodings(),1)

 def test_exact_pixels_across_layouts(self):
  formats=[(16,(0xf800,0x7e0,0x1f)),(16,(0x7c00,0x3e0,0x1f)),(32,(0x3ff00000,0xffc00,0x3ff))]
  for bits in (24,32):
   formats += [(bits,m) for m in itertools.permutations((0xff0000,0xff00,0xff))]
  for bits,masks in formats:
   for order in (0,1):
    for w,h,pad in [(1,1,0),(17,9,3),(64,4,7)]:
     with self.subTest(bits=bits,masks=masks,order=order,w=w,pad=pad):
      raw,want,stride=sample(bits,order,masks,w,h,pad)
      rc,png=invoke(raw,w,h,stride,bits,order,masks);self.assertGreater(rc,0)
      im=Image.open(io.BytesIO(png));self.assertEqual(im.size,(w,h));self.assertEqual(list(im.get_flattened_data()),want)
 def test_encoding_reuse_requires_fresh_equal_pixels(self):
  reuse=((C.c_ubyte*1048576)(),(C.c_ubyte*1048576)(),C.c_int64(),(C.c_int64*4)())
  masks=(0xff0000,0xff00,0xff);raw,want,stride=sample(w=17,h=9,pad=3)
  rc,first=invoke(raw,17,9,stride,32,0,masks,reuse);self.assertGreater(rc,0);self.assertEqual(lib.eyes_encodings(),1)
  rc,second=invoke(raw,17,9,stride,32,0,masks,reuse);self.assertEqual(second,first)
  self.assertEqual(lib.eyes_encodings(),0,'identical fresh pixels were encoded again')
  raw[-4] ^= 0x55
  rc,third=invoke(raw,17,9,stride,32,0,masks,reuse);self.assertGreater(rc,0)
  # Modify the last pixel's blue byte, not row padding or its ignored alpha.
  raw[8*stride+16*4] ^= 0x7f
  rc,changed=invoke(raw,17,9,stride,32,0,masks,reuse);self.assertGreater(rc,0)
  self.assertEqual(lib.eyes_encodings(),1,'changed pixels reused an old encoding')
  self.assertNotEqual(changed,third)
 def test_invalid_masks(self):
  for masks in [(0,0xff00,0xff),(0xff0000,0xff0000,0xff),(0xf50000,0xff00,0xff),(0x100000000,0xff00,0xff)]:
   raw,_,stride=sample();rc,_=invoke(raw,17,9,stride,32,0,masks);self.assertEqual(rc,-1,masks)
 def test_mask_work_independent_of_pixels(self):
  if os.environ.get('CAPTURE_COUNT')!='1':self.skipTest('instrumented qualification is a separate required invocation')
  for size in (1,8,64,512):
   raw,_,stride=sample(w=size,h=size,pad=0);rc,_=invoke(raw,size,size,stride,32,0,(0xff0000,0xff00,0xff));self.assertGreater(rc,0)
   self.assertLessEqual(lib.eyes_calls(),3,(size,lib.eyes_calls()))

if __name__=='__main__':
 (OUT/'source.json').write_text(json.dumps({'sourceSha256':hashlib.sha256(SOURCE.read_bytes()).hexdigest(),'compilerSha256':hashlib.sha256(IDOL.read_bytes()).hexdigest(),'instrumented':os.environ.get('CAPTURE_COUNT')=='1','graphCoverage':graph.get('fact_coverage')},indent=2))
 unittest.main(verbosity=2)
