/* Owned benchmark/test scene, not a production controller. */
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
static int paint(Display *d,Window w,int s,int mode,uint32_t seed) {
 char *bytes=calloc(640*480,4); if(!bytes)return 3;
 XImage *image=XCreateImage(d,DefaultVisual(d,s),DefaultDepth(d,s),ZPixmap,0,bytes,640,480,32,0); if(!image){free(bytes);return 3;}
 for(uint32_t y=0;y<480;++y)for(uint32_t x=0;x<640;++x){
  uint32_t v=0x336699u+seed;
  if(mode){v=x*1664525u+y*1013904223u+12345u+seed;v^=v<<13;v^=v>>17;v^=v<<5;}
  XPutPixel(image,x,y,v&0xffffffu);
 }
 GC gc=XCreateGC(d,w,0,NULL); XPutImage(d,w,gc,image,0,0,0,0,640,480);XSync(d,False);
 XDestroyImage(image);XFreeGC(d,gc);puts("ready");fflush(stdout);return 0;
}
int main(int argc,char **argv) {
 Display *d=XOpenDisplay(NULL); if(!d)return 2;
 int mode=argc>1?atoi(argv[1]):0, s=DefaultScreen(d);
 Window w=XCreateSimpleWindow(d,RootWindow(d,s),0,0,640,480,0,0,0);
 XMapWindow(d,w);XSync(d,False);uint32_t seed=0;
 if(paint(d,w,s,mode,seed))return 3;
 char b;while(read(0,&b,1)>0){if(b=='n' && paint(d,w,s,mode,++seed))return 3;}
 XDestroyWindow(d,w);XCloseDisplay(d);return 0;
}
