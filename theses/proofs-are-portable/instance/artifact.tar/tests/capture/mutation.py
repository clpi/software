"""Compile faults in actual Idol source; only named assertion failures count."""
import hashlib,json,os,pathlib,shutil,subprocess,sys
ROOT=pathlib.Path(__file__).resolve().parents[2]
OUT=pathlib.Path(os.environ['EVIDENCE']).resolve();OUT.mkdir(parents=True,exist_ok=False,mode=0o700)
faults=[
 ('direct-byte','capture.id','bluevalue = mem.read_byte(pixels, offset + bluebyte)','bluevalue = mem.read_byte(pixels, offset + redbyte)',1,'Capture.test_exact_pixels_across_layouts'),
 ('general-scale','capture.id','rm = r >> rs','rm = 255',1,'Capture.test_exact_pixels_across_layouts'),
 ('stale-pixels','capture.id','            same = false','            same = true',2,'Capture.test_all_layouts_reuse_only_exact_observable_pixels'),
 ('skipped-acquisition','capture.id','  cache[1] = 0','  if same\n    return previous\n  cache[1] = 0',1,'Capture.test_encoding_reuse_requires_fresh_equal_pixels'),
 ('failed-encode','capture.id','  cache[1] = 0','  cache[1] = previous',1,'Capture.test_failed_encoding_cannot_resurrect_old_png'),
 ('rectangle','observation.id','rectangle = state[12] == wide and state[13] == tall and state[16] == x and state[17] == y','rectangle = true',1,'Snapshot.test_rectangle_is_bound_to_observation'),
 ('context','server.id','if integer(text, context, 9007199254740991) != state[7]','if false',1,'Snapshot.test_invalid_tokens_do_not_grant_access'),
]
report=[]
for name,file,old,new,count,case in faults:
 work=OUT/name;work.mkdir()
 source=(ROOT/'protocol'/file).read_text();assert source.count(old)==count,(name,source.count(old))
 source=source.replace(old,new)
 if name not in ('rectangle','context'):
  altered=work/file;altered.write_text(source)
  env={**os.environ,'CAPTURE_SOURCE':str(altered),'CAPTURE_COUNT':'1','EVIDENCE':str(work/'qualification')}
  test=[sys.executable,'-S',str(ROOT/'tests/capture/check.py'),case]
 else:
  for folder in ('protocol','tools','tests/server'):shutil.copytree(ROOT/folder,work/folder,ignore=shutil.ignore_patterns('__pycache__'))
  (work/'protocol'/file).write_text(source)
  built=subprocess.run([sys.executable,'-S',str(work/'tools/server.py')],capture_output=True,timeout=90)
  (work/'build.log').write_bytes(built.stdout+built.stderr)
  if built.returncode:raise RuntimeError(name+': compilation failure is not behavioral evidence')
  env={**os.environ,'EYES':str(work/'.build/eyes')}
  test=[sys.executable,'-S',str(ROOT/'tests/capture/observe.py'),case]
 result=subprocess.run(test,env=env,capture_output=True,timeout=30)
 (work/'test.log').write_bytes(result.stdout+result.stderr)
 if result.returncode!=1 or b'FAILED (failures=' not in result.stderr or b'ERROR:' in result.stderr or case.split('.')[-1].encode() not in result.stderr:
  raise RuntimeError(name+': expected named behavioral assertion failure, not setup/build failure')
 if name not in ('rectangle','context') and not (work/'qualification/capture.so').is_file():raise RuntimeError(name+': missing compiled test object')
 report.append({'fault':name,'case':case,'compiled':True,'exit':result.returncode,'outputSha256':hashlib.sha256(result.stdout+result.stderr).hexdigest()})
 print(name,'caught',flush=True)
(OUT/'mutations.json').write_text(json.dumps(report,indent=2)+'\n')
