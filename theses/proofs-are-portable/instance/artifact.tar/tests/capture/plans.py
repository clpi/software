"""Fresh image identity survives alternating direct capture and input plans."""
import base64,io,pathlib,sys,unittest
sys.path.insert(0,str(pathlib.Path(__file__).parent))
from observe import Snapshot
from PIL import Image
class Combined(Snapshot):
 def perform(self,sequence,x=0):
  r=self.c.call('tools/call',{'name':'perform','arguments':{'context':self.context,'sequence':sequence,'steps':[{'name':'move','arguments':{'x':80,'y':90}}],'capture':{'x':x,'y':0,'width':64,'height':64}}})
  self.assertIn('result',r);r=r['result'];self.assertFalse(r.get('isError'),r)
  self.assertEqual(r['structuredContent']['submittedSteps'],1)
  image=next(v for v in r['content'] if v['type']=='image')
  return set(Image.open(io.BytesIO(base64.b64decode(image['data'],validate=True))).get_flattened_data())
 def test_plan_rectangle_change_invalidates_older_direct_token(self):
  initial=self.full(self.capture(),(51,102,153));self.assertEqual(self.perform(1,1),{(51,102,153)})
  changed=self.full(self.capture(context=self.context,since=initial['frame']),(51,102,153));self.assertGreater(changed['frame'],initial['frame'])
  self.assertEqual(self.perform(2),{(51,102,153)})
  self.assertTrue(self.capture(context=self.context,since=changed['frame'])['result']['structuredContent']['unchanged'])
 def test_plan_image_change_cannot_resurrect_old_frame(self):
  initial=self.full(self.capture(),(51,102,153))
  self.scene.stdin.write(b'n');self.scene.stdin.flush();self.ready()
  self.assertEqual(self.perform(1),{(51,102,154)})
  changed=self.full(self.capture(context=self.context,since=initial['frame']),(51,102,154))
  self.assertGreater(changed['frame'],initial['frame'])
  self.assertTrue(self.capture(context=self.context,since=changed['frame'])['result']['structuredContent']['unchanged'])
if __name__=='__main__':
 names=['test_plan_rectangle_change_invalidates_older_direct_token','test_plan_image_change_cannot_resurrect_old_frame']
 r=unittest.TextTestRunner(verbosity=2).run(unittest.TestSuite(Combined(n) for n in names));sys.exit(not r.wasSuccessful())
