"""Actual MCP -> owned X11 scene -> exact client image reconstruction."""
import base64,io,os,pathlib,select,subprocess,sys,tempfile,time,unittest
from PIL import Image
ROOT=pathlib.Path(__file__).resolve().parents[2]
sys.path.insert(0,str(ROOT/'tests/server'))
from check import Client
class Snapshot(unittest.TestCase):
 def setUp(self):
  self.tmp=tempfile.TemporaryDirectory(prefix='eyes-fresh-snapshot-');self.path=pathlib.Path(self.tmp.name)
  subprocess.run(['cc','-O2','-Wall','-Wextra','-Werror',ROOT/'tests/capture/scene.c','-lX11','-o',self.path/'scene'],check=True)
  self.x=subprocess.Popen(['Xvfb','-displayfd','1','-screen','0','640x480x24','-nolisten','tcp'],stdout=subprocess.PIPE,stderr=subprocess.PIPE)
  self.assertTrue(select.select([self.x.stdout],[],[],5)[0]);number=self.x.stdout.readline().strip().decode();self.assertTrue(number.isdecimal())
  self.env={**os.environ,'DISPLAY':':'+number,'IDOL_EYES_X11':'allow'}
  self.scene=subprocess.Popen([str(self.path/'scene')],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,env=self.env)
  self.ready();self.c=Client(self.env);self.c.init();self.context=self.c.call('tools/call',{'name':'observe','arguments':{}})['result']['structuredContent']['context']
 def ready(self):
  self.assertTrue(select.select([self.scene.stdout],[],[],5)[0]);self.assertEqual(self.scene.stdout.readline(),b'ready\n')
 def tearDown(self):
  self.c.close();self.scene.stdin.close();self.scene.wait(timeout=3);self.scene.stdout.close();self.scene.stderr.close()
  self.x.terminate();self.x.wait(timeout=3);self.x.stdout.close();self.x.stderr.close();self.tmp.cleanup()
 def capture(self,**more):
  if 'since' not in more and 'context' not in more:more={**more,'since':0,'context':self.context}
  return self.c.call('tools/call',{'name':'capture','arguments':{'x':0,'y':0,'width':64,'height':64,**more}})
 def full(self,r,color):
  self.assertIn('result',r);result=r['result'];self.assertIn('structuredContent',result)
  state=result['structuredContent'];self.assertFalse(state['unchanged'])
  im=Image.open(io.BytesIO(base64.b64decode(result['content'][0]['data'],validate=True)))
  self.assertEqual(set(im.get_flattened_data()),{color});return state
 def test_changed_and_unchanged_reconstruction(self):
  state=self.full(self.capture(),(51,102,153));self.assertGreater(state['frame'],0)
  args={'context':state['context'],'since':state['frame']}
  repeated=self.capture(**args)['result'];self.assertTrue(repeated['structuredContent']['unchanged'])
  self.assertFalse(any(c['type']=='image' for c in repeated['content']))
  self.assertEqual(repeated['structuredContent']['frame'],state['frame'])
  self.scene.stdin.write(b'n');self.scene.stdin.flush();self.ready()
  changed=self.full(self.capture(**args),(51,102,154));self.assertGreater(changed['frame'],state['frame'])
  self.assertFalse(self.capture(**args)['result']['structuredContent']['unchanged'],'stale frame must not suppress delivery')
  self.assertTrue(self.capture(context=changed['context'],since=changed['frame'])['result']['structuredContent']['unchanged'])
 def test_rectangle_is_bound_to_observation(self):
  first=self.full(self.capture(),(51,102,153))
  second=self.full(self.capture(x=1,context=first['context'],since=first['frame']),(51,102,153))
  self.assertGreater(second['frame'],first['frame'],'same pixels at a different rectangle are a new observation')
 def test_invalid_tokens_do_not_grant_access(self):
  first=self.full(self.capture(),(51,102,153))
  for args in [{'since':first['frame']},{'context':first['context']},{'since':first['frame'],'context':0},{'since':first['frame']+1,'context':first['context']}]:
   with self.subTest(args=args):
    r=self.capture(**args);self.assertTrue('error' in r or r.get('result',{}).get('isError'))
  self.c.call('tools/call',{'name':'close','arguments':{}})
  r=self.capture(context=first['context'],since=first['frame']);self.assertTrue(r['result']['isError'])
 def test_cached_observation_cannot_cross_expiry_or_process(self):
  self.c.close();self.c=Client({**self.env,'IDOL_EYES_SECONDS':'1'});self.c.init();self.context=self.c.call('tools/call',{'name':'observe','arguments':{}})['result']['structuredContent']['context']
  first=self.full(self.capture(),(51,102,153))
  successor=Client(self.env)
  try:
   successor.init();r=successor.call('tools/call',{'name':'capture','arguments':{'x':0,'y':0,'width':64,'height':64,'since':first['frame'],'context':first['context']}})
   self.assertTrue(r['result']['isError'])
  finally:successor.close()
  time.sleep(1.1)
  r=self.capture(since=first['frame'],context=first['context']);self.assertTrue(r['result']['isError']);self.assertNotIn('structuredContent',r['result'])
 def test_default_request_still_returns_full_image(self):
  for _ in range(2):
   response=self.c.call('tools/call',{'name':'capture','arguments':{'x':0,'y':0,'width':64,'height':64}})
   self.assertEqual(set(response['result']),{'content'},'unrequested tracking metadata bloats the legacy response')
   image=response['result']['content'][0];self.assertEqual(image['type'],'image')
   im=Image.open(io.BytesIO(base64.b64decode(image['data'],validate=True)))
   self.assertEqual(im.size,(64,64));self.assertEqual(set(im.get_flattened_data()),{(51,102,153)})
if __name__=='__main__':unittest.main(verbosity=2)
