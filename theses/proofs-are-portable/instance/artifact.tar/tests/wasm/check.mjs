// Test-only Wasm engine fixture. No production host or device policy lives here.
import assert from 'node:assert/strict';
import { createHash } from 'node:crypto';
import { readFileSync } from 'node:fs';

const bytes = readFileSync(process.argv[2]);
const selected = process.argv[3];
const report = { schema: 'idol.eyes.wasm.execution.v1', outcome: 'failed',
  scope: 'actual Idol parser in a Wasm engine; no desktop effects or dispatch',
  artifactSha256: createHash('sha256').update(bytes).digest('hex'),
  engine: { node: process.version, v8: process.versions.v8 }, tests: [], hostCalls: [] };
let current = 'module';
try {
  assert.ok(WebAssembly.validate(bytes), 'invalid Wasm binary');
  const module = new WebAssembly.Module(bytes);
  report.imports = WebAssembly.Module.imports(module);
  report.exports = WebAssembly.Module.exports(module);
  const names = ['fd_write', 'proc_exit', 'fd_read', 'args_sizes_get', 'args_get'];
  assert.deepEqual(report.imports, names.map(name => ({ module: 'wasi_snapshot_preview1', name, kind: 'function' })));
  const helpers = ['space', 'hex', 'quartet', 'spell', 'quoted', 'literal', 'numeric', 'scan', 'field', 'integral'];
  const byName = entries => [...entries].sort((a, b) => a.name.localeCompare(b.name));
  assert.deepEqual(byName(report.exports), byName([{name: 'memory', kind: 'memory'},
    ...helpers.map(name => ({name: 'idol_ingress__' + name, kind: 'function'})),
    {name: 'envelope', kind: 'function'}]));
  assert.throws(() => new WebAssembly.Instance(module, {}), TypeError);
  const host = Object.create(null);
  for (const name of names) host[name] = () => {
    report.hostCalls.push(name);
    throw Error('ungranted host import: ' + name);
  };
  const instance = new WebAssembly.Instance(module, {wasi_snapshot_preview1: host});
  const memory = instance.exports.memory;
  const base = memory.grow(3) * 65536;
  const output = base + 131072 + 64;
  const input = base + 64;
  const width = 64;
  const tests = [];
  const test = (name, body) => tests.push([name, body]);
  const encode = value => Buffer.isBuffer(value) ? value : Buffer.from(value);

  // These are ABI preconditions for a trusted embedding, not device grants.
  // They prevent this fixture from confusing wrapping i64 addresses or aliasing
  // with a parser refusal. Production embedders must enforce the same bounds.
  function invoke(value, size, address = input, destination = output) {
    const data = encode(value);
    const length = size ?? data.length;
    assert.ok(Number.isSafeInteger(length));
    if (length >= 1 && length <= 65536) assert.equal(length, data.length, 'declared input extent differs from fixture');
    assert.ok(Number.isSafeInteger(address) && address > 0 && address <= 0xffffffff);
    assert.ok(Number.isSafeInteger(destination) && destination > 0 && destination <= 0xffffffff);
    assert.equal(destination % 8, 0);
    assert.ok(address + data.length <= memory.buffer.byteLength);
    assert.ok(destination + width + 8 <= memory.buffer.byteLength);
    assert.ok(address + data.length <= destination - 8 || destination + width + 8 <= address);
    const view = new Uint8Array(memory.buffer);
    view.fill(0x5a, destination - 8, destination + width + 8);
    view.set(data, address);
    const previous = memory.buffer;
    const rc = instance.exports.envelope(BigInt(address), BigInt(length), BigInt(destination));
    assert.equal(memory.buffer, previous, 'parser unexpectedly grew memory');
    assert.equal(typeof rc, 'bigint');
    const slots = Array.from({length: 8}, (_, i) => new DataView(memory.buffer).getBigInt64(destination + i * 8, true));
    if (rc === 0n || rc === 1n) {
      for (let i = 0; i < slots.length; i += 2) {
        const [start, end] = slots.slice(i, i + 2);
        assert.ok((start === 0n && end === 0n) ||
          (start >= 1n && end > start && end <= BigInt(data.length + 1)), 'span outside original input extent');
      }
    } else {
      assert.ok(rc === -32700n || rc === -32600n, 'unexpected parser status');
      assert.deepEqual(slots, Array(8).fill(0n), 'refusal leaked partial fields');
    }
    assert.deepEqual(Buffer.from(view.subarray(address, address + data.length)), data, 'input mutated');
    assert.deepEqual(Array.from(view.subarray(destination - 8, destination)), Array(8).fill(0x5a));
    assert.deepEqual(Array.from(view.subarray(destination + width, destination + width + 8)), Array(8).fill(0x5a));
    assert.deepEqual(report.hostCalls, [], 'parser invoked an ungranted host');
    return {rc, slots, data};
  }
  const span = (result, position) => result.data.subarray(Number(result.slots[position]) - 1, Number(result.slots[position + 1]) - 1).toString();
  const bad = value => {
    const result = invoke(value);
    assert.ok(result.rc === -32700n || result.rc === -32600n, 'malformed request was accepted');
    assert.deepEqual(result.slots, Array(8).fill(0n), 'refusal leaked partial fields');
  };
  const request = (id = '1', method = '"ping"', rest = '') => '{"jsonrpc":"2.0","id":' + id + ',"method":' + method + rest + '}';

  test('request', () => {
    const r = invoke(request('9007199254740993123456789'));
    assert.equal(r.rc, 0n); assert.equal(span(r, 0), '9007199254740993123456789');
    assert.equal(span(r, 2), '"ping"'); assert.deepEqual(r.slots.slice(4), [0n, 0n, 0n, 0n]);
  });
  test('notification', () => {
    const r = invoke('{"jsonrpc":"2.0","method":"notifications/cancelled","params":{"requestId":1}}');
    assert.equal(r.rc, 1n); assert.deepEqual(r.slots.slice(0, 2), [0n, 0n]);
  });
  test('structural', () => {
    const r = invoke(request('"a,b"', '"tools/call"', ',"params":{"arguments":{"name":"evil"},"na\\u006de":"apply"}'));
    assert.equal(r.rc, 0n); assert.equal(span(r, 6), '"apply"');
    assert.equal(JSON.parse(span(r, 4)).arguments.name, 'evil');
  });
  test('duplicates', () => {
    for (const extra of [',"id":2', ',"\\u0069d":2', ',"method":"tools/call"', ',"jsonrpc":"2.0"']) bad(request('1', '"ping"', extra));
    bad(request('1', '"tools/call"', ',"params":{"name":"apply","name":"other"}'));
  });
  test('wrong', () => {
    for (const value of ['[]', 'null', '{}', '{"id":1,"method":"ping"}', request('null'), request('true'), request('1.5'), request('1', '{}'), request('1', '"ping"', ',"result":{}'), request('1', '"ping"', ',"params":[]')]) bad(value);
  });
  test('arguments', () => {
    for (const params of ['{}', '{"name":null}', '{"name":""}', '{"name":"apply","arguments":[]}', '{"name":"apply","arguments":{},"arguments":{}}', '{"name":"apply","_meta":1}', '{"name":"apply","_meta":{},"_meta":{}}']) bad(request('1', '"tools/call"', ',"params":' + params));
  });
  test('numbers', () => {
    for (const id of ['1.0', '1e3', '100e-2', '0e-99999', '1.000e0', '-0.00', '12.5e1']) { const r = invoke(request(id)); assert.equal(r.rc, 0n); assert.equal(span(r, 0), id); }
    for (const id of ['1e-3', '1.01', '12.5e-1', '1e-99999999999999999']) bad(request(id));
  });
  test('malformed', () => {
    for (const value of ['01', '+1', '1.', '1e', '--1', 'NaN', 'Infinity', '[1,]', '{"a":1,}', '"\\x41"', '"\\uD800"', '"\\uDC00"', '"\\uD800\\u0041"', '"\0"', '"\n"', 'true false', '[}', '{"x" 1}', '"unterminated']) bad(request('1', '"ping"', ',"params":{"x":' + value + '}'));
  });
  test('unicode', () => {
    for (const raw of [[0x80], [0xc0, 0xaf], [0xed, 0xa0, 0x80], [0xf4, 0x90, 0x80, 0x80], [0xf5, 0x80, 0x80, 0x80], [0xe2, 0x82]]) bad(Buffer.concat([Buffer.from(request().slice(0, -1) + ',"params":{"x":"'), Buffer.from(raw), Buffer.from('"}}')]));
    const r = invoke(request('"中国🦋\\uD83D\\uDE00"'));
    assert.equal(r.rc, 0n); assert.equal(JSON.parse(span(r, 0)), '中国🦋😀');
  });
  test('limits', () => {
    bad(' '.repeat(65537));
    bad(request('1', '"ping"', ',"params":{"x":' + '['.repeat(65) + '0' + ']'.repeat(65) + '}'));
    bad(request('1', '"ping"', ',"params":{' + Array.from({length:129}, (_, i) => '"k' + i + '":0').join(',') + '}'));
    for (const size of [-1, 0, 65537]) { const r = invoke('', size); assert.equal(r.rc, -32700n); assert.deepEqual(r.slots, Array(8).fill(0n)); }
    const r = invoke(request() + ' '.repeat(65536 - request().length)); assert.equal(r.rc, 0n);
    const padding = ' '.repeat(65536 - request().length);
    const high = invoke(padding + request());
    assert.equal(high.rc, 0n);
    assert.equal(span(high, 0), '1'); assert.equal(span(high, 2), '"ping"');
    assert.equal(high.slots[2], BigInt(padding.length + request().indexOf('"ping"') + 1));
    assert.equal(high.slots[3], high.slots[2] + 6n);
    const members = count => ',"params":{' + Array.from({length: count}, (_, i) => '"k' + i + '":0').join(',') + '}';
    assert.equal(invoke(request('1', '"ping"', members(128))).rc, 0n);
    bad(request('1', '"ping"', members(129)));
    const nested = count => ',"params":{"x":' + '['.repeat(count) + '0' + ']'.repeat(count) + '}';
    assert.equal(invoke(request('1', '"ping"', nested(62))).rc, 0n);
    bad(request('1', '"ping"', nested(63)));
  });
  test('trailing', () => { for (const end of ['{}', 'null', 'x', '\0']) bad(request() + end); });
  test('recovery', () => { bad(request('null')); const r = invoke(request('2')); assert.equal(r.rc, 0n); assert.equal(span(r, 0), '2'); });
  test('boundary', () => {
    const data = Buffer.from(request());
    // A length-delimited input ends exactly at memory end, without a C NUL.
    const r = invoke(data, undefined, memory.buffer.byteLength - data.length, output);
    assert.equal(r.rc, 0n);
    assert.throws(() => invoke(data, undefined, input + 2 ** 32), assert.AssertionError);
    assert.throws(() => invoke(data, undefined, output), assert.AssertionError);
    // Invalid raw pointers are caller errors and may partly write then trap.
    // Discard the whole instance after a deliberate ABI violation.
    const broken = new WebAssembly.Instance(module, {wasi_snapshot_preview1: host});
    const end = broken.exports.memory.buffer.byteLength;
    assert.throws(() => broken.exports.envelope(1n, 1n, BigInt(end - 8)), WebAssembly.RuntimeError);
    const other = new WebAssembly.Instance(module, {wasi_snapshot_preview1: host});
    const start = other.exports.memory.grow(1) * 65536;
    assert.throws(() => other.exports.envelope(BigInt(other.exports.memory.buffer.byteLength), 1n, BigInt(start)), WebAssembly.RuntimeError);
  });
  if (selected && !tests.some(([name]) => name === selected)) throw Error('unknown selected case: ' + selected);
  for (const [name, body] of tests) {
    if (selected && name !== selected) continue;
    current = name; body(); report.tests.push(name);
  }
  assert.deepEqual(report.hostCalls, []);
  report.outcome = 'pass';
} catch (error) {
  report.failure = { case: current, kind: error instanceof assert.AssertionError ? 'assertion' : 'harness', name: error.name, message: error.message };
  process.exitCode = error instanceof assert.AssertionError ? 1 : 2;
}
console.log(JSON.stringify(report, null, 2));
