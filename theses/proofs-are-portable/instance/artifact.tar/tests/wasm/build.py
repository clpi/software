"""Offline controls for build orchestration, not parser behavior."""
import importlib.util
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('eyeswasm', ROOT / 'tools/wasm.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


class Build(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.source = self.root / 'ingress.id'
        self.source.write_text('fixture only\n')
        self.compiler = self.root / 'compiler'
        self.capture = self.root / 'capture'

    def tool(self, body):
        self.compiler.write_text('#!' + sys.executable + '\nimport sys,time\nfrom pathlib import Path\n' + body)
        self.compiler.chmod(0o700)

    def report(self):
        return json.loads((self.capture / 'build.json').read_text())

    def test_artifact_is_not_execution(self):
        self.tool("Path(sys.argv[-1]).write_bytes(b'\\0asm\\x01\\0\\0\\0')\n")
        report = module.build(self.compiler, self.capture, self.source)
        self.assertEqual(report['outcome'], 'built-not-executed')
        self.assertFalse(report['compilerRevisionVerified'])
        self.assertNotIn('--lib', report['command'])
        self.assertIn('--no-cache', report['command'])

    def test_compile_failure_preserves_log(self):
        self.tool("print('named refusal',flush=True)\nsys.exit(7)\n")
        with self.assertRaises(RuntimeError): module.build(self.compiler, self.capture, self.source)
        self.assertEqual(self.report()['exit'], 7)
        self.assertEqual(self.report()['outcome'], 'failed')
        self.assertIn('named refusal', (self.capture / 'compile.log').read_text())

    def test_wrong_artifact_fails(self):
        self.tool("Path(sys.argv[-1]).write_bytes(b'ELF not wasm')\n")
        with self.assertRaises(RuntimeError): module.build(self.compiler, self.capture, self.source)
        self.assertEqual(self.report()['outcome'], 'failed')

    def test_missing_artifact_fails(self):
        self.tool('pass\n')
        with self.assertRaises(FileNotFoundError): module.build(self.compiler, self.capture, self.source)
        self.assertEqual(self.report()['outcome'], 'failed')

    def test_changed_source_fails(self):
        self.tool("Path(sys.argv[-3]).write_text('changed')\nPath(sys.argv[-1]).write_bytes(b'\\0asm\\x01\\0\\0\\0')\n")
        with self.assertRaises(RuntimeError): module.build(self.compiler, self.capture, self.source)
        self.assertEqual(self.report()['outcome'], 'failed')

    def test_stale_directory_refuses(self):
        self.tool("raise RuntimeError('must not execute')\n")
        self.capture.mkdir()
        sentinel = self.capture / 'sentinel'
        sentinel.write_text('retained')
        with self.assertRaises(FileExistsError): module.build(self.compiler, self.capture, self.source)
        self.assertEqual(sentinel.read_text(), 'retained')

    def test_timeout_is_not_success(self):
        self.tool("print('partial',flush=True)\ntime.sleep(10)\n")
        with self.assertRaises(module.subprocess.TimeoutExpired): module.build(self.compiler, self.capture, self.source, limit=0.2)
        self.assertTrue(self.report()['timeout'])
        self.assertEqual(self.report()['outcome'], 'failed')


if __name__ == '__main__':
    unittest.main(verbosity=2)
