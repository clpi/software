#!/usr/bin/env python3
"""Compile damaged Idol parsers and require a named Wasm behavioral assertion."""
import argparse
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[2]
spec = importlib.util.spec_from_file_location('eyeswasm', ROOT / 'tools/wasm.py')
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('compiler', type=Path)
    parser.add_argument('capture', type=Path)
    parser.add_argument('--node', default='node')
    args = parser.parse_args()
    capture = args.capture.absolute()
    capture.mkdir(mode=0o700)
    source = (ROOT / 'protocol/ingress.id').read_text()
    cases = [
        ('duplicates', 'if invalid or version <= 0', 'if version <= 0'),
        ('wrong', 'if not integral(text, start, finish)', 'if false'),
        ('unicode', 'character >= 194 and character <= 223', 'character >= 192 and character <= 223'),
    ]
    report = {'schema': 'idol.eyes.wasm.mutations.v1', 'outcome': 'failed', 'cases': []}
    try:
        for name, before, after in cases:
            if source.count(before) != 1:
                raise RuntimeError(name + ': mutation must match exactly once')
            home = capture / name
            home.mkdir()
            path = home / 'ingress.id'
            path.write_text(source.replace(before, after))
            built = module.build(args.compiler, home / 'build', path)
            command = [args.node, str(ROOT / 'tests/wasm/check.mjs'), str(home / 'build/ingress.wasm'), name]
            child = subprocess.run(command, capture_output=True, timeout=30, check=False)
            (home / 'check.json').write_bytes(child.stdout)
            (home / 'check.err').write_bytes(child.stderr)
            result = json.loads(child.stdout)
            failure = result.get('failure', {})
            if (child.returncode != 1 or result.get('outcome') != 'failed' or
                    failure.get('case') != name or failure.get('kind') != 'assertion' or
                    result.get('hostCalls') != []):
                raise RuntimeError(name + ': no named behavioral rejection; compile/engine/harness failures do not count')
            report['cases'].append({'name': name, 'compiled': True, 'detected': True,
                                    'artifactSha256': built['artifactSha256'], 'failure': failure})
        report['outcome'] = 'pass'
        return 0
    except Exception as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        return 1
    finally:
        (capture / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
        print(json.dumps(report, indent=2))


if __name__ == '__main__':
    sys.exit(main())
