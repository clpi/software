# Grab — the capture coordination discipline

Status: decision slice, standalone Idol program
(`protocol/grab.id`) with a fixture battery
(`tests/grab/check.py`). This is the capture leg's
coordination discipline, filed after the 2026-11-06 live
exposure on the fleet's MacBook Pro: ScreenCaptureKit
capture through the bridge refused with a coordination
failure while an uncoordinated capture process existed on
the seat, the classic engine path answered, and a human
took that fallback by hand. This program makes the
discipline a producer: no human chooses the fallback, and
no outcome is opaque.

## What it does

The program reads a command line and a fact block on stdin
and prints one envelope. The facts are stated by the caller
(the seat driver gathers them live; the battery cans them):

```
R <primary outcome>     ok | coordination | permission | platform
F <fallback outcome>    ok | fail | none
P <process id> <coordinated 0 or 1> <process name>
```

The decisions, made here in Idol and nowhere else:

- Primary ok: success, the record's path is `primary`.
- Coordination with an uncoordinated capture process
  present and the fallback ok: success on the classic
  path, the record naming the blocking process and its
  pid. When several uncoordinated processes are present,
  the first in the block is the named blocker.
- Coordination, fallback failed, blocker present: refusal
  R-PLATFORM with the blocker identified in the refusal.
- Coordination, fallback failed, no blocker identified:
  refusal R-INTERNAL whose message states that no blocking
  process was identified. An opaque coordination failure
  is never printed: every outcome names its path, its
  blocker, or the absence of both.
- Coordination with the fallback outcome unstated refuses
  R-ARGS: the discipline does not guess whether the
  fallback ran.
- Permission refuses R-PERM and platform refuses
  R-PLATFORM, each without trying another path: neither is
  a coordination fact, and a fallback taken for them would
  falsify the record.

This program decides; it does not capture, and it does not
identify processes: the P rows are the driver's statement
of which capture processes the seat holds and whether each
runs coordinated with the bridge. Pixel checks (the beat
spec's A-O6 pass condition) belong to the capture leg that
consumes this decision, not to the decision itself.

## Run it

```
idol compile protocol/grab.id -o grab        # or: idol run
printf 'capture\nR\tcoordination\nF\tok\nP\t4242\t0\tSome Capture\n' | ./grab
GRAB_BIN=./grab python3 tests/grab/check.py
```

The battery runs the mocked arms wherever a compiled
binary exists. The live arm — a deliberately uncoordinated
process planted on the seat, the window capture run under
it, the record checked for the blocker and the path — is
staged as the capture coordination runbook in the Idol
Eyes lane record of 2026-11-07 and runs on the seat's
venue trigger.
