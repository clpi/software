# Eyes WebAssembly target

Eyes remains in this repository and its production behavior is authored in Idol. The first executable WebAssembly target is the existing, unchanged `protocol/ingress.id` request parser. It is emitted directly from Idol's shared graph/DNIR by the Wasm backend, with no generated-C step. It is not a port of the controller to JavaScript.

This target validates and extracts an MCP request. It does not dispatch that request, capture a desktop, execute input, establish graph-owned identity or grant authority. A parser return of zero means a valid request, never a successful device action. Missing desktop functionality remains unsupported; there is no native fallback.

## Build and qualify

Use a trusted, provenance-verified Idol compiler. Building does not download or rebuild a compiler, change a compiler pin, or grant device access.

```sh
IDOL=/absolute/idol make wasm
python3 tools/wasm.py --compiler /absolute/idol --capture /absolute/new-build
node tests/wasm/check.mjs /absolute/new-build/ingress.wasm
python3 tests/wasm/mutation.py /absolute/idol /absolute/new-mutations
make source
```

The build prints the artifact and receipt paths, retains compiler output, requires a fresh capture directory, checks WebAssembly magic/version and source/compiler stability, and records `built-not-executed`. That receipt is not binary validation or execution evidence. The separate engine test validates the actual binary, calls its Idol entry, checks results and denies every host import. Mutations must compile and fail their selected behavioral assertion; compilation errors, import failures and harness failures do not pass a negative control.

Node/V8 is a qualification engine only. The product artifact is a Wasm binary, not a JavaScript package, and no Node production dependency is introduced. Other engine embeddings require their own exact-artifact qualification. Build-driver tests run within `make check`; real Wasm execution is explicit and never silently skipped as passing when its engine/compiler is missing.

The tested compiler uses absence of a source process entry to select a library. Do not add `--lib`: that flag currently reaches a refused legacy route at the pinned compiler. No source rewrite or prefix directive is introduced by the build.

## Embedding contract

The supported entry is `envelope`, with physical signature `(i64, i64, i64) -> i64`: input address, actual byte length, output address. It returns the statuses and one-based byte spans described in [the protocol interface](protocol.md). The output is a distinct, live, writable region of eight little-endian signed i64 words. Input remains immutable and needs no trailing NUL. The caller owns both regions for the entire call.

Addresses are canonical wasm32 offsets carried as i64. The current compiler truncates pointer high bits; negative or greater-than-u32 addresses can alias lower memory rather than trap. The embedding must reject such addresses, arithmetic wrap, out-of-memory extents, aliases, and concurrent mutation before calling. Invalid raw pointers are ABI errors, not a promised parser refusal. The entry clears output before input validation, so an invalid output extent can partially write and then trap. Discard an instance after an ABI violation; do not claim safe recovery of arbitrary runtime state.

The tests append private pages to the module's memory, leaving compiler static data, heap and stack untouched. The parser does not allocate or grow memory during supported calls. The artifact itself has no declared memory maximum, so bounded request size is not a memory/resource sandbox claim. An embedding must apply its own engine resource limits.

Current emission also exports internal parser helpers. Those helpers do not have the entry's preconditions and are not supported product entry points. The qualification records and checks the complete import/export inventory; consumers use only `envelope` and `memory`.

## Host boundary

Current library emission declares WASI preview1 imports `fd_write`, `proc_exit`, `fd_read`, `args_sizes_get` and `args_get`, even though this pure parser needs none. Instantiation without required imports fails. A host must explicitly provide the imports; the qualification provides implementations that throw and record an attempted call, including `proc_exit(0)`. Accepted and refused parser cases require zero import calls. There is no filesystem preopen, process access, network, display access or implicit host permission.

This is not a desktop host API. Future device realization must consume the existing graph-owned callable, target, world/effect, lifetime, ownership and failure facts and require the specific granted host support. X11, AX and UIA do not become Wasm instructions. Missing, denied, stale or revoked support must refuse before effects; partial or uncertain submitted effects must retain their outcome without replay. No host language may become a second policy owner.

## Remaining boundaries

The standalone observation program currently fails Wasm compilation at `call_extern/call-arity` in `main`: its zero-argument stdin-read lowering disagrees with the Wasm helper's operand contract. The full native server separately fails on its nine-operand XQueryPointer signature. These failures are retained, not hidden by routing through C or stubbing successful reads. Compiler changes and their qualification remain separate work under upstream ownership and the user's run scope.

This delivery does not claim the full Eyes server, desktop integrations, browser embedding, comparator parity or performance superiority. Original historical native evidence remains attached to its own source and realization; it is not Wasm proof.
