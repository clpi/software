# Idol Eyes repository initialization

Goal: create clpi/idol-eyes as the private product home for Idol-native computer perception, control and UI, with measured superiority to Peekaboo as the release objective.

Architecture: compose the already merged native realization through an exact Git submodule pin. Idol remains the semantic authority. Do not copy the value transaction into a competing implementation. This repository initially owns product integration, acceptance criteria and entry points into the existing native qualification.

Validation work:
1. Pin the merged native source, required compiler, and externally verified Peekaboo release.
2. Test manifest rejection for moving refs, absent coverage, duplicate case labels and unsupported superiority claims.
3. Add the product charter, architecture and complete comparison contract.
4. Run repository tests and verify all uploaded Git blobs and the native gitlink.
5. Record repository creation separately from native product qualification.

Review boundaries: inherited native ABI evidence is not real UI evidence; self-reported benchmark results are not proof; missing permissions stay blocked; no host controller masquerades as native ownership; no copied implementation can drift from its producer.
