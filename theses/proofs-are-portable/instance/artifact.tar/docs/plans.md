# Native action plans

`perform` submits a known sequence of one to 32 existing input operations in a single MCP request. It is implemented in Idol and invokes the same action implementation as individual tools. It does not execute shell strings, invoke another computer-use framework, infer permission, or create a second scheduler or semantic graph.

Use an existing authorized local X11 launcher, initialize the MCP client, and call `observe` for the current physical context. Pass that context, the next sequence, and `steps` containing `name` and `arguments` for move, click, key, scroll, type, chord or drag. Inner arguments cannot replace the context or sequence. An optional top-level `capture` rectangle returns a final lossless PNG. The existing stdio launcher and native build instructions in `runtime.md` apply unchanged.

Example tool arguments, with the actual observed context substituted:

```json
{"context":123,"sequence":1,"steps":[{"name":"move","arguments":{"x":80,"y":90}},{"name":"type","arguments":{"text":"Hello, Idol!"}}],"capture":{"x":30,"y":30,"width":32,"height":32}}
```

The example context is not a grant. Access remains denied unless the operator explicitly enables the assigned display. Existing expiration, revocation, read-only, keyboard-map and held-input checks remain active. Never send a plan whose next action depends on an unobserved application outcome. Split that plan, observe the application, then choose the next action.

## Execution and verification

Every multi-step plan is completely validated without submitting input. Live execution then repeats the relevant admission checks before each step. An invalid later step or capture prevents the entire input prefix. Unsupported characters are rejected before typing. One five-second platform deadline bounds the plan; cancellation or process loss after possible submission remains uncertain.

The result names `submittedSteps`, `failedStep`, `diagnosticCode` and `nextSequence`. Submitted steps include a possibly partially submitted failed step; they are not confirmed application outcomes. A stopped plan is not rolled back and must not be blindly retried. `atomic` is explicitly false. On observation/permission failure, no image or position is returned. Application-level confirmation remains the caller's responsibility.

For consecutive moves, the next step's fresh pointer query verifies the previous position before dependent input. The last position is independently queried. The same query also checks held mouse buttons; a fresh keymap query checks held keys. This removes redundant synchronization and duplicate observations without removing the measured position checks. It does not eliminate X11 races or prove application target identity.

Physical context nonces, sequence numbers and bounded shadow preflight storage are not semantic IDs or graph-issued worlds. The same existing graph-owned authorization, outcome-publication, native UI, cross-platform, durable recovery and Ocean/Lake/Sea integration gaps remain open. No comparator state or authority pin is changed.

## Qualification

`./verify` includes the existing tests and `tests/server/plans.py`. `tests/server/mutation.py` also runs four compiled plan faults through `planmutation.py`; each must compile and then fail the named behavioral assertion. `probe.c` is test-only instrumentation around real X11 operations, never a production controller.

The build uses `-Os -flto` for compact native output and records the flags. This is a physical code-generation choice, not proof of Pareto dominance. Measurements must compare equally tuned alternatives and retain regressions. No universal speed or competitor-superiority claim is established by this change.
