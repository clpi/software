# Tree — the second form of the observation producer, and identity resolution

Status: producer slice, standalone Idol program
(`protocol/tree.id`) with a fixture battery
(`tests/tree/check.py`). This is the growth the observe
slice's doc names: the observation producer's tree form
(producers 1 and 2 of the agent-desktop beat spec) and the
reference producer's identity resolution. It is not the
finished producer; its bounds are stated below.

Like the observe slice, this is a preview and qualification
path: the block is produced by a foreign transport today, and
the native substrate move (and its elimination order) is the
one stated in docs/observe.md. References here carry the same
premise discipline as the observe slice: a reference is a
derived value of one observation, never a standing name.

## The block

One line per row, fields separated by tab characters:

```
S <snapshot token> <application name>
N <identity> <parent identity or -> <role> <actionable 0 or 1> <value> <state or -> <label>
```

A state of `-` means the element carries no state of the
kind a state read asks for; it is not a false value. The
label is the last field and may contain spaces.

## Commands

`tree full | compact | skeleton` prints one envelope whose
data carries the nested tree: each node with its identity,
role, name, value, state (or null with applicable false),
its reference when actionable (numbered over actionable
nodes in block order, the observe slice's rule), and its
children. Full emits every node and reads complete. Compact
collapses a single-child unnamed group wrapper into its
child, repeatedly. Skeleton clamps depth at 3: a container
cut at the clamp carries its child count, the envelope's
cutpoints list names every cut container, and completeness
reads false whenever a cut exists — a complete flag is never
printed over a cut tree.

`drill <identity>` prints an envelope whose tree is exactly
the named node's region, references fresh from the same
observation. A missing identity refuses R-ELEM.

`search <role> <name>` prints the matches (identity, plus
reference when actionable) and the list of roles the block
actually holds, so a zero-match answer is checkable.

`read <ref> <premise> value | state` prints one element's
value, or its state with applicable true; a `-` state
answers applicable false, distinct from any state value.
Refusals are the observe slice's: R-ARGS for a bare or
malformed reference, R-STALE for a foreign snapshot, a
changed premise, or an ordinal the block does not hold.

`resolve <ref> <premise>` is the reference producer's
identity resolution. Its input carries two flat blocks (the
observe slice's E form) separated by a line holding only
`L`: the block the reference was issued from, then the live
block. The premise is folded over the issuing block's bytes
as presented before the separator line. Resolution finds the
reference's element identity in the issuing block, then
matches that identity in the live block:

- exactly one live match prints the transport action line
  (`act <identity> <live snapshot>`), wherever the element
  now sits in the block;
- no live match refuses R-STALE, carrying the live snapshot
  in the refusal's retracted_by field — the retracting
  observation, as the beat spec requires;
- several live matches refuse R-AMBIG, listing the candidate
  references in the live block;
- a block with no snapshot header refuses R-NOSNAP.

A refusal prints an envelope and nothing else: resolution
delivers no input, ever. Silent re-resolution to a similar
element is forbidden and does not occur: matching is by
identity alone, never by role or label.

## Bounds of this slice

- The timed observation budget (the beat spec's
  one-millisecond case, A-O2) is not in this slice: no
  deadline mechanism exists here yet. Skeleton cut points
  (A-O3) are; the budget arm remains the tree producer's
  named remainder.
- References in the tree form are still positional numbers
  over one observation, as in the observe slice; identity
  resolution across observations is the resolve command's
  job, and it works on the flat form today.
- Bounds rectangles, window identity and surface kinds are
  not in the block yet; the tree carries role, name, value
  and state only.
- NUL input refuses before parsing, as in the observe
  slice, for the same stated reason.

## Run it

```
idol compile protocol/tree.id -o tree        # or: idol run
printf 'tree full\nS\ts1\tForm\nN\tw\t-\twindow\t0\t\t-\tForm\n' | ./tree
TREE_BIN=./tree python3 tests/tree/check.py
```

The fixture battery runs the full, skeleton and compact
forms, drill, search, both reads, and the four resolve arms
(moved, vanished, duplicated, headerless) against canned
blocks wherever a compiled binary exists; its event log —
the act lines it collected — proves the refusals delivered
zero input.
