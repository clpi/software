# Agent-desktop is a mandatory Idol Eyes comparator

## Owner requirement and current boundary

Idol Eyes must meet and measurably exceed vercel-labs/agent-desktop across capability, verified performance, resource cost, usability, safety, distribution and integration. This adds a comparator; it does not remove Peekaboo, CUA or the broader product requirements. No weighted average can buy off a losing capability or metric. A component merge is not product completion.

This change is a source-pinned coverage contract and an executable omission/claim guard. It implements no new desktop action and runs no external performance campaign. Every case remains unmeasured; the product remains pre-alpha. The native production path, compiler/native pins, licenses and private repository visibility are unchanged.

## Frozen source and separate release

Source inventory: `vercel-labs/agent-desktop` at `b43ac4f6e892ef608f8851428613c4009f0e84c7`, inspected November 6, 2026. `src/cli/mod.rs` has Git blob `2f9a8fdc54108244c1fd593d3e8b0002c62693ec`. It declares 60 top-level command names. The four held-input commands (`key-down`, `key-up`, `mouse-down`, `mouse-up`) deliberately refuse; they are refusal obligations, not four working competitor capabilities. Eleven declared subcommands under session, trace, skills and cursor-overlay are recorded separately. This inventory does not imply every flag, platform or route has been executed.

The latest released version observed was `v1.2.0`, source `2b0a7334fc111730454b726e6800aa41cdafc093`, published November 5, 2026. It is NOT the same commit as the source inventory. Run released and source-head comparisons separately when relevant. Re-fetch the latest release before a new campaign, record binary/configuration digests and preserve old campaign identities. Do not use a version string as a binary identity.

## Capability floor

Agent-desktop is accessibility-first: snapshots with qualified refs, property/state queries, filtering, partial/skeleton observations and drill-down, semantic activation/value/selection/state operations, explicitly headed physical input, apps/windows/displays/shell surfaces, notifications, typed clipboard, bounded waits, sessions/traces/overlays, diagnostics, bundled skills, CLI, MCP and a C library. Source implementations use AX on macOS, UI Automation on Windows and AT-SPI on Linux. Headless behavior and unsupported capabilities differ by platform and toolkit. The manifest represents obligations to verify those distinctions, NOT universal support claims.

A pixel-coordinate click is not equivalent to semantic ref activation. A pointer readback is not proof of an application change. An image hash is not target identity. A faster region capture cannot replace a whole-window request. The C library must be compared with an in-process Idol entry, not only with CLI startup. Native archives must be included; a JavaScript package launcher is not an excuse to claim the competitor inherently needs a JS runtime.

The required profiles cover ARM64 and x86-64 on macOS, Windows, Linux/X11 and Linux/Wayland. Routes are cold native CLI, persistent MCP and in-process native library. The full cross-product is a coverage obligation. A baseline-unsupported combination requires actual source/runtime disposition and a declared applicability decision; it cannot disappear. Refusal-only commands are tested for safe refusal rather than timed as successful actions. CLI flags, default behavior, subcommands, secret stdin, DPI, partial trees and all claimed surface types need specimens within these cells.

## One Idol-owned execution model

The product stays: ordinary user intent -> constrained plan -> existing graph subjects and world authority -> specialized admissible realization -> independently observed outcome. CLI, MCP, embedding, Idiom and idol-model are projections of that same execution, not separate controllers. Lake/Sea and Ocean are execution placements under their existing authenticated leases; no side queue or scheduler is added.

Native platform providers supply exact incarnation and capability evidence. Resolve and revalidate identity before effects; fail on ambiguity, expired authority or unproven continuity. An Idol semantic ID does not manufacture a stable OS object. Use direct application APIs, accessibility and physical input only when their behavior is equivalent under the requested contract. A full property replacement is not automatically equivalent to a sequence of keystrokes with observable intermediate events.

Cache observations/plans only under witnessed dependencies. Event gaps, process/window recreation, permission changes and unknown provider state invalidate or force reacquisition. Stream only demanded semantic changes; request pixels when semantics cannot answer. Delta frames need a retained exact base and bounded resynchronization. Their client reconstruction, memory, transport and verification costs count.

Retain one authoritative submitted prefix and outcome. Do not infer success from an IPC acknowledgment. Cancellation cannot undo effects already sent. Uncertain outcomes are observed/reconciled, not automatically resent. Foreground focus, clipboard and held inputs require scope and privacy controls; untrusted app text never issues grants.

## What construction-level proofs may establish

1. No admitted effect reaches a platform provider without its required existing world/lease witness, assuming the authority verifier and provider boundary enforce the contract.
2. No optimization changes the declared observable semantics: reordering requires independence; coalescing requires intermediate-event unobservability; replacing a mechanism requires equivalence, not just a similar final screenshot.
3. An exact delta representation reconstructs the fresh image and falls back when its real serialized cost exceeds the full-frame alternative, under explicit memory/base/frame assumptions.
4. A plan selector chooses the lowest modeled cost from its admitted equivalent candidates. This proves only selection relative to that candidate set and cost model. It does not prove physically minimal wall-clock execution across every unknown implementation.

These are obligations, not newly proved runtime properties. Formal arguments do not substitute for compiler admission, OS/race controls or external measurements. Existing bootstrap/C-backend evidence stays explicitly scoped.

## Measurement contract

Freeze the candidate and comparator source/build/binary/configuration per target. Within a target campaign, all winning claims must belong to the same integrated candidate artifact. Do not assemble a product win from unrelated branches, physical targets or runtime versions. Match hardware, OS, application builds, app state, permissions, operation semantics, output fidelity, observation scope and independent outcome verifier.

Measure cold startup separately from warm steady-state. Time until the requested state is independently confirmed, not merely until events are submitted. Use representative third-party applications as well as owned adversarial fixtures. Randomize paired order; retain timeouts, failed actions, invalid targets and all raw samples. Preregister practical win margins, precision/power and uncertainty control across the full family of comparisons. Report p50/p95/p99 separately; a nonsignificant difference is not equivalence and a mean cannot hide a tail regression.

Account for the whole process tree and helpers: CPU, allocations, resident/peak/loaded memory, energy when instrumented, binary/package/dependency size, build cost, image/IPC/network bytes and reconstruction. Natural-language end-to-end evaluation must use identical model/version/configuration and goals; include model latency, tokens, tool turns, success, recovery and human interventions. Operator usability includes setup, permission onboarding, diagnostics and authoring burden. Disabled/unsupported counters are unavailable, not zero. Known physical lower-bound ties must be called ties and cannot be advertised as large wins.

The first implementation priority is graph-owned semantic discovery, exact target resolution and verified accessibility actions; more pixel compression alone does not close the capability gap. Then complete surfaces, pipeline/mesh realization, interface parity and target-specific qualification. Agent-desktop already has batching, MCP and native embedding: those are baseline requirements, not unique advantages.

## Executable guard and remaining work

`python3 tools/check.py` validates both required comparator contracts. `python3 tools/check.py --coverage` prints required cells and an explicit UNQUALIFIED state. `python3 tools/check.py --require-qualified` exits nonzero: this metadata checker is not an evidence producer/statistical reducer and cannot certify superiority. `--upstream-registry /path/to/src/cli/mod.rs` additionally verifies exact source bytes and the complete top-level name inventory. It executes no desktop actions.

Hosted `make check` discovers the added regression tests through the existing path. Do not weaken the guard or change rows to passing to claim completion. Implement and independently review actual native fixtures, capability/argument discovery, exact-target outcomes, campaign execution, raw-evidence validation and statistical reduction first. Expand coverage when new source capabilities are discovered. All existing product gaps remain open.
