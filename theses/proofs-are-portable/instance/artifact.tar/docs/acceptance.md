# Peekaboo parity and dominance acceptance

Owner requirement: Idol Eyes must be native Idol and better than Peekaboo in all relevant respects. A rename or a native value primitive alone does not meet that requirement.

## External baseline

The initial baseline was verified from the [upstream release API](https://api.github.com/repos/openclaw/Peekaboo/releases/latest) and the [v4.9.7 tag](https://github.com/openclaw/Peekaboo/releases/tag/v4.9.7) on 2026-10-29. `bench/peekaboo.json` pins the peeled source commit. Refresh the released comparator before a campaign; record the exact binary digest, build settings, dependencies and runtime configuration. Do not silently mutate an existing campaign's baseline.

[Upstream architecture](https://peekaboo.sh/ARCHITECTURE.html) documents a native core, app, CLI, authenticated bridge, warm daemon and agent/MCP adapters. [Automation documentation](https://peekaboo.sh/automation.html) documents identity-bound targets, background-first operation, consented foreground effects and retry-unsafe partial/indeterminate outcomes. Those are parity requirements, not Idol innovations. Live documentation may be ahead of a release: derive each frozen executable test from pinned source and command help.

## Coverage

The JSON matrix records requested coverage across perception/capture, exact targets, native input, desktop surfaces, human/agent interfaces, security, concurrency/recovery, distribution and Idol integration. Rows with unavailable implementations or measurements stay unmeasured. Platform-specific or non-overlapping capabilities must be separately classified with justification; they cannot silently disappear from coverage or imply baseline capability that has not been tested.

## Matched campaigns

Use identical hardware, OS and application builds, target state, permissions, workload semantics, output fidelity and verification strength. Compare the strongest applicable native-library, warm-daemon, cold-CLI and agent routes separately. Randomize paired ordering, retain all failures/timeouts, allow thermal stabilization, report the sampling design, uncertainty and precision. Include real third-party applications alongside owned fixtures and ordinary tasks alongside constructed stress cases.

Latency ends at independently confirmed effect, not event submission. Account for the whole process tree: CPU, peak/resident memory, allocations, capture/IPC/network bytes, artifact/loaded bytes, dependencies, compile cost and energy where actually measurable. Report p50/p95/p99 independently. Record user-visible success, recovery behavior, action/recipe steps and model/token cost where relevant. An unsupported energy counter is unavailable, never zero.

## Decision rule

Every shared capability must meet its correctness/safety/UX contract. No material regression is allowed on any preregistered dimension; no mean score can compensate for a losing row. Strict improvements are required on optimizable axes. Equality at a demonstrated physical lower bound is a bound result, not an invented speed win. A nonsignificant difference is not evidence of equivalence; use declared margins and appropriately powered comparisons. Finite campaigns support only their declared scope, not claims about every possible future workload.

Any performance advantage obtained by dropping checks, reducing capture fidelity, ignoring failures, changing the app state, selecting a weaker comparator route or excluding its warm service invalidates the comparison. Brand, LOC, design elegance and cross-platform expansion cannot compensate for a macOS correctness or performance regression.

## Required product exits

1. Graph-owned subject/world/effect/outcome integration, with the native transaction and real allowed effects verified against owned and third-party apps.
2. Complete desktop control and perception surfaces, signed/usable permission onboarding, native inspector/UI library, CLI, embedding and MCP from the same graph.
3. Revocation, stale identity, hostile UI content, concurrent human input, hung AX work, saturation, crash/reconnect and uncertain submission adversarial controls.
4. Reproducible paired Peekaboo campaigns covering the matrix and resource metrics, independently reviewed with source/binary/world/evidence pins.

The current check script validates only repository composition and rejects an unsupported superiority flag. It is not a statistical reducer or completed benchmark harness. Implement that producer/verifier before changing comparison states. All four exits remain open.
