# Steward — the state-reset campaign producer

Status: campaign slice (`tools/steward.py`) with a battery
(`tests/test_steward.py`, part of `make check`). This is
the first form of the state steward, over the landed
observe-and-click preview, for the calculator fixture
shape. Its control is a filed campaign record whose
pre-state, baseline and verification observations are all
recorded.

## Why it exists

Third-party application state is currently whatever the
last lane left behind: the fleet Calculator carried a prior
probe's unit-conversion input into the observe landing
lane's captures, and the live proof left it showing 777.
A campaign that does not record and reset the fixture's
state measures an unknown application.

## What it does

Given a transport (observe and act, injected), the steward:

1. records the pre-state by observation;
2. drives the fixture to a named baseline through the
   action path — the clear element's reference, taken from
   the fresh observation itself;
3. verifies the baseline by re-observation, and records
   that observation as the campaign's `after`;
4. restores the pre-state when it is restorable — on the
   calculator shape, a plain digit string re-entered digit
   by digit, each press resolved from a fresh observation —
   or records the pre-state as the campaign's residue.

Every action is taken on a reference from the immediately
preceding observation under that observation's premise; the
steward never carries a reference across observations, so
it cannot submit a stale action by construction. A fixture
with no clear element, or a baseline the clear does not
reach, ends the campaign with the residue recorded and the
status naming which happened; nothing is retried blindly.

The campaign record is filed as JSON and read back before
the campaign reports it filed: a record whose bytes do not
read back is not a record.

## Bounds

- The steward is foreign campaign orchestration, like the
  observe driver; reference and premise decisions remain
  the compiled Idol program's, printed verbatim. The
  BlockTransport adapter parses the observe program's
  envelope for seat use; performing the resolved transport
  action on a seat stays the driver's job.
- Restoration covers the calculator shape's digit-string
  pre-states. Any other pre-state is recorded as residue,
  never approximated.
- Generalizing past the calculator shape rides the action
  producer's growth (named baselines per fixture shape);
  it is not claimed here.

## Run it

```
python3 -m unittest tests.test_steward -v
```

The battery's fake calculator issues a fresh premise per
observation and asserts any stale act, so the freshness
discipline is proven, not described; its event log asserts
the exact act sequence of each arm (clear and three digits
for a 777 pre-state, no acts at all for a clean one).
