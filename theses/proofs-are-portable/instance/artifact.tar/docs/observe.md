# Observe — the macOS observe leg

Status: first slice, landed as a standalone Idol program
(`protocol/observe.id`) with a foreign driver (`tools/observe.py`)
and a fixture battery (`tests/observe/check.py`). This is the
first slice of the observation producer and the reference
producer in the agent-desktop beat spec
(`spec-idol-eyes-agent-desktop-2026-11-06`, producers 1 and 2,
queue entries EYES-OBS-MAC and EYES-REF). It is not the finished
producer; its bounds are stated below, not implied away.

This is a preview and qualification path, not the native production path.
It depends on Python and Peekaboo, contrary to the finished product runtime
requirement. Its byte digest and positional refs are not graph-owned target
identity or grants. The 28-bit fold can collide, so it cannot prove exact
observation continuity. These remain release blockers, not closed gaps.

## What it does

The program reads a command line and an observation block on
stdin and answers on stdout.

The observation block is a transport-neutral canonical form,
one line per element, fields separated by tab characters:

```
S <snapshot token> <application name>
E <transport id> <role> <actionable 0 or 1> <label>
```

`snapshot` prints one envelope in the shape of the rival's
snapshot command: contract version, success flag, command name,
and a data object carrying the application name, the snapshot
token, the actionable element count, a false completeness flag, the
snapshot premise, and the element list. Each actionable element
carries a ref of the form `@<snapshot>:e<n>`, numbered in block
order over actionable elements only, plus its available actions.

The premise is a digest folded byte by byte over the exact
observation bytes (the fold is defined in the program and is
recomputed identically by the checker). A ref is a derived
value whose premise is that digest plus the snapshot token:
it names an element of one observation, never an element in
general.

`act <ref> <premise>` resolves a ref against the observation
block it was issued from and prints the single transport action
the caller may perform. Refusals are by name, in the refusal
vocabulary of the beat spec, and deliver nothing:

- R-ARGS — the ref does not carry its snapshot (a bare element
  number is not a ref), the command is unknown, or raw input contains NUL.
  NUL input refuses before command parsing and carries an empty command field.
- R-STALE — the ref's snapshot token is not this block's, the
  presented premise does not match the block's digest (the
  observation changed since the ref was issued), or the ref
  numbers an actionable element the block does not hold. Empty,
  non-decimal and overflowing ordinal fields also refuse; integer
  overflow must never alias an oversized ref to an existing element.

On a match the program prints `act <transport id> <snapshot
token>` and nothing else. The driver submits that transport command and
prints a fresh display observation as evidence for its caller. It does not
implement an application postcondition verifier. A zero subprocess exit
does not establish delivery or successful effect. Nonzero exit or timeout
fails without automatic replay; a possible submitted effect stays uncertain.

## The transport, and its elimination order

Today the observation block is produced from the Peekaboo
seat on a Mac: `peekaboo see` reads the accessibility tree
through the bridge host, and `peekaboo click` performs the
resolved action against the same snapshot. This is a test/preview
dependency, not an OS ABI or a permitted finished-product dependency.
Some serialization and ref checks execute in Idol, but the source hash
does not establish live target continuity, graph identity or action authority.
Observation and device submission still belong to the foreign transport.

Elimination order: the block producer moves to the pinned
native substrate's macOS accessibility transaction
(`native/control/value.id` line, through `make device`), and
the action performer to the same substrate, at which point
the Peekaboo seat leaves this path entirely and returns to
its standing role as external comparator. The known blocker
for that move is recorded as its own queue entry: a freshly
built Idol binary carries no accessibility grant of its own
on macOS (grants are per signed application; the grants proven
on the fleet's Macs belong to the Peekaboo application), so
the native device path needs a signed, grant-holding host
form before its real-device evidence can run.

## Bounds of this slice

- The element list is flat: roles and labels in traversal
  order, no parent/child nesting, no bounds, no value or
  state fields. The observation definition in the beat spec
  (window identity, surface, scope, time, trust, completeness
  cut points, the three density forms) is the producer this
  slice grows into, not what it already is.
- The only projected action is Click. The remaining fifteen
  reference actions belong to the action producer
  (EYES-ACT in the queue).
- Ref resolution is positional within one block (the n-th
  actionable element), so the ambiguity refusal (R-AMBIG) of
  the spec cannot arise here; identity-based resolution is
  part of the reference producer's remaining work.
- Label text is carried as the transport reported it; quote
  and backslash are escaped at emission and admitted non-NUL control bytes are
  preserved with JSON escapes after projection. NUL input explicitly refuses
  in Idol before slicing, and the preview driver refuses it before invoking
  the program. The pinned compiler's substring/helper-string extent loss
  remains an upstream limitation; successful NUL preservation is unsupported.
  The preview driver retains
  its existing label-tab/newline normalization to spaces before making the
  block, so this is not a lossless copy of the original accessibility bytes.
  It refuses controls in framing fields, spaces in physical ID tokens, and
  the reserved `:e` ref delimiter in snapshot tokens,
  rather than allowing them to create extra rows or command fields.
  Names are evidence, never identity (the repo's
  standing rule), and nothing in this slice treats them as
  grants.
- Screenshot capture is evidence only and is not part of this
  slice. On the fleet's Pro, ScreenCaptureKit capture through
  the bridge is refused while an uncoordinated Peekaboo
  process exists; the classic engine path answers. That
  operational fact is recorded in the lane record, and the
  capture leg of the observation producer inherits it.

## Run it

```
idol compile protocol/observe.id -o observe        # or: idol run
printf 'snapshot\nS\ts1\tCalculator\nE\te1\tbutton\t1\t7\n' | ./observe
```

The fixture battery (`tests/observe/check.py`) runs the
snapshot, act, stale, and bare-ref arms against a canned
Calculator-shaped block wherever a compiled binary exists.
The live proof (a real Mac, a real application, an acted ref,
a re-observed change) is recorded in the lane record of
2026-11-06, not asserted here.

The preview driver retains its private temporary captures through the whole
capture/action/reobservation invocation, then cleans them up. It does not
overwrite a fixed file in the user's home. These captures are not persisted
qualification evidence. Mocked-driver controls live in
`tests/test_observe_driver.py`; the separate compiled-program battery still
requires an explicitly built exact-source `OBSERVE_BIN`. Neither test source
nor a passing mocked-driver check is native or device qualification.
