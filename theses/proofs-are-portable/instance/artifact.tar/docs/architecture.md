# Native product architecture

Idol Eyes is the computer-use product of Idol. It consumes ordinary semantic graph facts and produces observable device outcomes through lawful native realizations. Product branding does not change language identity.

## One semantic path

Observation carries source, target incarnation, scope, time, trust and invalidation. Resolved graph subjects and world witnesses authorize actions. The compiler specializes queries and ordered effects, selects a lawful physical realization, and retains independently observed outcomes. The inspector, CLI, embedded library, MCP and agent projections consume that same state. They must not independently invent target IDs or reinterpret effect success.

`clpi/idol` owns semantic law; `clpi/idol-native` owns shared physical mechanisms. This repository owns product integration and presentation. The `native` gitlink is composition, not a fork. A future product-specific `.id` entry must invoke the actual graph-owned producer; an unimplemented entry point or invented API must not be committed as working code.

## Native execution requirement

The production path must run without Node, Python, a browser, a handwritten Swift/C controller or the Peekaboo executable. Native framework ABIs are legitimate dependencies; delegation of transaction policy to those host languages is not. Existing C/Objective-C fixtures and Python qualification code remain test-only. Their deletion condition is equivalent Idol-owned qualification with independently retained evidence, not filename conversion.

## Performance direction — not measured claims

Keep one resident native execution context. Use demand-driven accessibility subscriptions and witnessed incremental updates rather than repeated full-tree scans or screenshots. Specialize recurring query/action plans; invalidate plans when facts cease to hold. Share immutable observations and use compact representations; batch only independent operations or sequences whose intermediate observations are not required. Keep blocking framework work off the UI executor with bounded capacity and backpressure.

Use semantic application APIs, accessibility, raw input or pixels according to proven equivalence, authority and measured cost—not an unconditional preference that drops behavior. No inference call is required for a deterministic already-resolved task. Cold-start and warm-service paths have independent budgets.

## Reliability

An IPC acknowledgement is not a successful effect. Cancellation cannot retroactively undo a submitted event. Uncertain/partial outcomes retain their submitted prefix and are reconciled by observation rather than resending. AX value changes are not atomic compare-and-swap. Lifetime and admission checks cannot claim to eliminate platform races they do not control.

Longer-term surfaces include capture, input, app/window/menu/dialog/clipboard control, native UI composition, remote devices and agent workflows. These are open requirements, not implemented modules.
