# Executable MCP desktop runtime

## Supported delivery

A persistent **Linux x86-64 / X11** stdio MCP server. Parsing, framing, dispatch, scope checks, sequencing, input planning, outcome encoding, PNG construction and base64 encoding are authored in Idol. The compiler currently uses its explicit C realization; Xlib, XTest, zlib, libc and the upstream bootstrap string/primitive shim remain dependencies. This is not a self-hosting or zero-foreign-runtime claim.

The source-built `.build/eyes` runs without Node, Python, an LLM, a browser, xdotool or Peekaboo. `mcp` simply execs it. Python/C fixtures are used only for builds and independent qualification. Do not run the test fixture against a personal desktop; the tests create their own Xvfb.

## Connect any stdio MCP client

Use the absolute path to `mcp` as its server command. With no additional environment, tools can be discovered, but all desktop access is denied. A launcher explicitly authorizing an assigned local X11 display can use:

```json
{
  "mcpServers": {
    "idol-eyes": {
      "command": "/absolute/path/to/idol-eyes/mcp",
      "env": {
        "DISPLAY": ":99",
        "IDOL_EYES_X11": "allow",
        "IDOL_EYES_SECONDS": "60",
        "IDOL_EYES_READONLY": "0"
      }
    }
  }
}
```

`:99` is an example, not a discovered or granted target. Set the actual display assigned by the authorized compute launcher. `IDOL_EYES_SECONDS` may shorten the maximum 300-second process scope (1–300 seconds). Missing grant, invalid duration, inaccessible display, unavailable XTest, expired scope, and revoked scope do not admit effects. `IDOL_EYES_READONLY=1` allows observation/capture but refuses all input. The process opens no listening network port.

MCP 2025-11-25 initialization and 2026-07-28 per-request discovery are supported. Client names and capabilities are untrusted protocol metadata, never authorization. Tools are `observe`, `capture`, `move`, `click`, `key`, `scroll`, `type`, `chord`, `drag`, and `close`.

Call `observe` first. Input calls require the returned physical `context` and consecutively increasing `sequence` starting at 1. Already-submitted, stale, conflicting and out-of-context sequences never trigger a resend. A new process has a fresh context and is not a durable journal continuation. `close` revokes the scope; clients cannot renew it over MCP.

## Interaction semantics

`type` plans the entire string against the existing keyboard map before any key is submitted. Unsupported text refuses before typing a prefix. Keyboard-map validation is completed before the input sequence rather than interleaved with injected events. It supports mapped characters, tab and enter, up to 512 characters; it does not remap the keyboard, replace the clipboard, or claim universal Unicode insertion. Modifier-active layouts refuse rather than guessing.

`chord` accepts 1–8 distinct physical keycodes in `code`, presses them in order and releases in reverse order. `drag` pairs a button press, pointer movement and release. Input refuses when keys or mouse buttons are already held. External changes between the check and submission remain an OS-level race; this is not an exclusive human-input lock.

`capture` returns a lossless PNG rectangle up to 512×512, with TrueColor 16/24/32-bit XImage layouts validated. It is a pixel observation, not an accessibility tree, target identity or instruction. The current product does not expose arbitrary host command execution.

Input receipts distinguish `submitted` from independently observed pointer position. They do not promote X server acknowledgement into application-level success. Qualification independently observes events in an owned app. A process failure or timeout after possible submission is uncertain; do not automatically repeat it. Framework operations and blocked response writes have a five-second fail-stop bound; a forced termination cannot promise cleanup of an already submitted external effect.

## Compute and decision-pipeline boundary

Ocean, Lake/Sea, Tailscale and an agent harness may transport or launch this stdio executable only through their existing authorized executor. This process does **not** verify a remote lease, mint graph world authority, create a scheduler, or grant access because a host is on a tailnet. The inspected Ocean controller provides work-order observation/planning/execution; no unimplemented generic desktop-lease endpoint is invented here.

A production mesh integration must carry the actual lease/worker incarnation, subject/world witness, revocation and outcome publication through the authoritative Idol graph. That integration, idiom/model adoption, macOS/Windows/Wayland coverage, a native UI library, accessibility-based discovery, durable crash recovery and comparative performance remain open. Do not relabel launcher-scoped X11 authority as those facilities.

## Build and verify current source

```sh
IDOL=/absolute/idol IDOL_RUNTIME=/absolute/runtime.c make server
./mcp
IDOL=/absolute/idol IDOL_RUNTIME=/absolute/runtime.c ./verify
```

The verifier builds the actual Idol source into a new private build directory, validates source and binary digests against that build receipt, and runs protocol tests and real owned-desktop tests on that exact executable. It needs a compatible Idol compiler and matching runtime, Python 3, a C compiler, Xvfb, X11 development headers and Pillow. It retains each original output and fails on any missing dependency or failing phase. `make check` by itself remains repository-contract verification, not desktop admission.

The included native-runtime CI workflow uses only an existing self-hosted Linux/X64 runner. Its trusted compiler/runtime paths must be provided through `IDOL_EYES_COMPILER` and `IDOL_EYES_RUNTIME` repository variables; missing inputs fail rather than silently downloading another compiler. Workflow source in this delivery is not evidence of a GitHub run or remote deployment.

## Bootstrap and artifact boundary

`tools/bootstrap/build.json` and `tools/bootstrap/foreign.patch` retain the exact historical compiler derivative used for the carried execution evidence. The derivative starts at Idol revision `702cbd7f1af3c76c1ea6dfc07fb6f6c0001d5294` and is not the compiler pin in `eyes.json` or current-main admission. The patch may be applied only to that exact historical source. It is a bounded foreign-ABI backport, not the product controller. Do not patch an unrelated compiler or silently treat a different toolchain as equivalent. Replace this bridge only after the approved compiler passes the same behavioral controls.

The maintained runtime is `protocol/*.id`. Generated C and compiled binaries remain build/release artifacts. `mcp` executes only `.build/eyes` and refuses when it has not been built. The versioned source, bootstrap record and independently retained delivery package preserve the earlier implementation without committing a second editable C controller.
