# Fresh observation with demand-selected delivery

This is a physical X11/MCP realization, not a second graph or a new source of device authority. It extends the existing `capture` tool. All policy and pixel decisions are authored in Idol. Existing explicit X11/zlib/libc boundaries and the bootstrap runtime remain dependencies.

## Client contract

An ordinary `capture` request with `x`, `y`, `width`, `height` still returns the same complete PNG content without extra tracking fields. Bounds and permission checks are unchanged. No existing client must implement a cache.

A client retaining images may opt in. First obtain the execution `context` from `observe`. Request `capture` with its rectangle plus `context` and `since: 0`. The full-image result then includes `structuredContent: {context, frame, unchanged: false}`. Retain the decoded image keyed by execution context, rectangle, and frame. A later request for that exact rectangle may supply that frame as `since`. If a newly acquired snapshot has exactly the same observable RGB, the result contains text `unchanged` and the matching context/frame with `unchanged: true`; no image is transmitted. Keep the retained image. Otherwise replace it with the returned full image and frame. A client without that retained image must request `since: 0`, never guess a token.

Both optional arguments are required together. Invalid, duplicate, future, and wrong-context references refuse. Moving the rectangle or changing its dimensions advances the frame, even when its RGB happens to be identical. Old process contexts cannot be reused after restart. Revocation and monotonic lease expiry are checked before capture and before result delivery. The frame is a process-local physical correlation value, NOT a semantic graph ID, capability, freshness deadline, atomic transaction, or causal proof. There is no cache validity across processes or leases. Frame exhaustion refuses rather than wrapping.

## Work removed

The old conversion normalized and checked every color mask for every pixel. The new conversion validates the three masks once per acquired snapshot. For byte-aligned eight-bit channels, the derived byte offsets directly select the output channels. Other supported layouts retain exact integer scaling. The generic path still supports 16/24/32-bit pixels, either byte order, and row padding. Masks outside the pixel width are now rejected rather than converted under an invalid layout.

Every request still acquires a fresh XImage. It compares the actual newly observed RGB against the existing canonical raster. Exact equality reuses the existing PNG, avoiding compression and reconstruction; it does not reuse an old acquisition. Padding and unused channel bits do not invalidate an identical RGB observation. A change in the final pixel is as significant as a change in the first. Failed conversions or encoders invalidate reuse.

No extra image buffer or image-cache allocation is added. Seven additional i64 state cells (56 bytes) carry encoding validity, dimensions, the equality result, frame and rectangle. The executable grows; this is a latency/traffic improvement with a documented code-size cost, not Pareto dominance on every axis. Opted-in changed-image responses carry tracking metadata; default full-image responses do not.

## Equivalence argument and bounds

For a validated contiguous mask `m = (2^n - 1) << s`, the previous result is `floor(((pixel & m) >> s) * 255 / (2^n - 1))`. Hoisting `s` and the denominator cannot change it because both are immutable facts of that acquired snapshot. For `n = 8` at a byte boundary, the expression is exactly the byte selected by the derived offset and byte order. Tests cover permutations, 565/555/10-bit masks, padding and both byte orders with an independent decoder.

PNG reuse is admitted only after every fresh observable RGB byte equals the retained raster and its dimensions match. Full-result equality follows from the unchanged encoder input and the retained successful encoding. A compact response additionally requires the same rectangle and process frame. Equality is byte-exact, not hash-based; there is no collision assumption. These are conditional implementation arguments, not a machine-checked proof of the compiler or OS.

Without a trusted change notification, an adversary could change any unexamined pixel. Exact unchanged detection in this pixel-access model therefore needs a full comparison in the worst case. The implementation retains that O(P) work but removes redundant format analysis and encoding. Compact unchanged delivery is O(1) bytes with respect to image area. This is not a proof of global physical optimality: damage notifications, shared surfaces, semantic targeting and network placement can change the model.

## Executable qualification

`IDOL=/absolute/idol IDOL_RUNTIME=/absolute/runtime.c ./verify --output /new/evidence` now also compiles the actual capture source against controlled XImage layouts and tests the actual server against owned Xvfb scenes. `CAPTURE_COUNT=1` adds test-only call instrumentation to prove at most three mask analyses per snapshot. The foreign fixture controls platform inputs and counts actual image/encoder calls; it does not implement conversion or cache decisions.

`EVIDENCE=/new/faults IDOL=... IDOL_RUNTIME=... python3 tests/capture/mutation.py` requires seven successfully compiled corruptions to fail their named behavioral assertions. The original thirteen runtime mutations remain separate and required. No compiler/setup failure counts as a caught fault.

`BASELINE=/absolute/old-eyes CANDIDATE=/absolute/new-eyes EVIDENCE=/new/measure python3 tests/capture/measure.py` runs 24 workloads: flat/noisy scenes, four dimensions, default full images, incremental unchanged observations, and images changed before each paired round. It randomizes order within 21 retained pairs after ten warmups. Exact independently decoded RGB is checked for every response; incremental client materialization must equal the same current image. Raw latency and actual response bytes are retained. The timer spans client send through parsed MCP response, not PNG validation or AI inference. Bootstrap intervals are exploratory and not familywise-adjusted. Environment, compiler/runtime/binary identities and source hashes belong with each retained run.

## Open boundaries

This does not establish superiority over Peekaboo, CUA, ChatGPT computer use, or the strongest possible tuned implementation. It does not close current-compiler admission, graph-issued authority/outcome publication, authenticated Ocean/Lake/Sea leases, decision/idiom/idol-model integration, cross-platform accessibility, UI generation, or durable recovery. Existing competitor gates remain unmeasured.
