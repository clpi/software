#!/usr/bin/env python3
"""State steward for Idol Eyes campaigns (docs/steward.md).

Foreign campaign orchestration, not the native production
path: the steward decides nothing about references or
premises. Those decisions print from the compiled observe
program; the steward only sequences observations and actions
and files the campaign record the state-reset control asks
for:

  1. record the pre-state by observation;
  2. drive the fixture to a named baseline through the action
     path (the clear element, resolved from the fresh
     observation's own references);
  3. verify the baseline by re-observation;
  4. restore the pre-state when it is restorable (a plain
     digit string on the calculator shape, re-entered digit
     by digit, each press resolved from a fresh observation),
     or record it as the campaign's residue.

Every action is taken on a reference from the immediately
preceding observation, under that observation's premise. The
steward never reuses a reference across observations, so a
stale action cannot be submitted by construction; a transport
that refuses a stale premise (as the observe program does)
makes any violation loud in the tests.

The transport is injected: observe() returns an envelope dict
with app, premise, display and elements (each element a dict
with name and, when actionable, ref_id); act(ref, premise)
returns True when the action was delivered. BlockTransport
adapts the preview driver's block source and program runner
to that contract for seat use; the tests inject a fake.
"""
import json
import os
import time


def find_ref(envelope, label):
    for element in envelope.get("elements", []):
        if element.get("name") == label and element.get("ref_id"):
            return element["ref_id"]
    return None


def file_record(record, path):
    """Write the campaign record and read it back; a record
    that does not read back byte-identical is not filed."""
    data = json.dumps(record, indent=2, sort_keys=True).encode()
    for _ in range(30):
        try:
            fd = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o664)
            try:
                view = memoryview(data)
                while view:
                    written = os.write(fd, view)
                    view = view[written:]
            finally:
                os.close(fd)
            with open(path, "rb") as handle:
                if handle.read() == data:
                    return path
        except OSError:
            pass
        time.sleep(1)
    raise SystemExit("campaign record did not read back: " + str(path))


def campaign(transport, baseline="0", clear_labels=("C", "AC"),
             record_path=None):
    log = []

    def observe():
        envelope = transport.observe()
        log.append({"step": "observe", "display": envelope["display"]})
        return envelope

    def press(envelope, label):
        ref = find_ref(envelope, label)
        if ref is None:
            return False
        delivered = transport.act(ref, envelope["premise"])
        log.append({"step": "act", "label": label, "ref": ref,
                    "delivered": bool(delivered)})
        return bool(delivered)

    pre = observe()
    record = {"app": pre.get("app", ""), "pre": pre["display"],
              "baseline": baseline, "log": log}
    envelope = pre
    if envelope["display"] != baseline:
        cleared = False
        for label in clear_labels:
            if find_ref(envelope, label) is not None:
                cleared = press(envelope, label)
                break
        if not cleared:
            record["status"] = "no-clear-path"
            record["residue"] = envelope["display"]
            return finish(record, record_path)
        envelope = observe()
    record["after"] = envelope["display"]
    if envelope["display"] != baseline:
        record["status"] = "baseline-not-reached"
        record["residue"] = envelope["display"]
        return finish(record, record_path)

    target = record["pre"]
    if target == baseline:
        record["restored"] = envelope["display"]
        record["status"] = "baseline-verified"
    elif target.isdigit():
        restored = True
        for digit in target:
            envelope = observe()
            if not press(envelope, digit):
                restored = False
                break
        envelope = observe()
        record["restored"] = envelope["display"]
        record["status"] = ("baseline-verified-restored"
                            if restored and envelope["display"] == target
                            else "restore-failed")
    else:
        record["restored"] = None
        record["residue"] = target
        record["status"] = "baseline-verified-residue-recorded"
    return finish(record, record_path)


def finish(record, record_path):
    if record_path is not None:
        file_record(record, record_path)
        record["filed"] = str(record_path)
    return record


class BlockTransport:
    """Adapt a block source and a program runner (the preview
    driver's shape) to the steward's transport contract.

    block_source() returns a fresh observation block;
    run(command, block) returns the compiled observe program's
    answer line. act() reports the program's resolution: the
    transport action line it printed is kept on last_action
    for the seat driver to perform, exactly as tools/observe.py
    performs it today.
    """

    def __init__(self, block_source, run):
        self.block_source = block_source
        self.run = run
        self.block = ""
        self.last_action = None

    def observe(self):
        self.block = self.block_source()
        envelope = json.loads(self.run("snapshot", self.block))
        data = envelope["data"]
        display = ""
        for element in data["elements"]:
            if element.get("role") == "text":
                display = element.get("name", "")
                break
        return {"app": data["app"], "premise": data["premise"],
                "display": display, "elements": data["elements"]}

    def act(self, ref, premise):
        answer = self.run("act %s %s" % (ref, premise), self.block)
        if answer.startswith("act "):
            self.last_action = answer
            return True
        self.last_action = None
        return False
