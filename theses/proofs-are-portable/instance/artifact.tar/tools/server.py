#!/usr/bin/env python3
"""Build-only composition; production parsing/dispatch/effects execute in Idol."""
import hashlib,json,os,pathlib,subprocess,sys,tempfile
ROOT=pathlib.Path(__file__).resolve().parents[1]
def main():
    compiler=pathlib.Path(os.environ['IDOL']).resolve()
    out=ROOT/'.build'
    if out.is_symlink():raise RuntimeError('build directory must not be a symlink')
    out.mkdir(exist_ok=True)
    run=pathlib.Path(tempfile.mkdtemp(prefix='server-',dir=out))
    paths=['protocol/ingress.id','protocol/stream.id','protocol/capture.id','protocol/observation.id','protocol/input.id','protocol/program.id','protocol/server.id']
    source=run/'eyes.id'
    def execute(args,name):
        p=subprocess.run(args,stdout=subprocess.PIPE,stderr=subprocess.PIPE,timeout=90)
        (run/(name+'.out')).write_bytes(p.stdout);(run/(name+'.err')).write_bytes(p.stderr)
        if p.returncode:raise RuntimeError(p.stderr.decode(errors='replace')+p.stdout.decode(errors='replace'))
        return p.stdout
    execute(['cc','-std=c11','-O2','-Wall','-Wextra','-Werror',str(ROOT/'tests/server/layout.c'),'-o',str(run/'layout')],'layout-build')
    layout=execute([str(run/'layout')],'layout').decode()
    (run/'layout.id').write_text(layout)
    source.write_text(layout+'\n'+'\n'.join((ROOT/p).read_text() for p in paths))
    execute([str(compiler),'compile','--no-cache','--backend=c','--emit','c',str(source),'-o',str(run/'eyes.c')],'compile')
    graph=json.loads(execute([str(compiler),'graph',str(source)],'graph'))
    if graph.get('blocking_applications'):raise RuntimeError('blocking graph applications')
    runtime=pathlib.Path(os.environ['IDOL_RUNTIME']).resolve()
    execute(['cc','-std=c11','-Os','-flto','-ffunction-sections','-fdata-sections','-Wno-builtin-declaration-mismatch',str(run/'eyes.c'),str(runtime),'-Wl,--gc-sections','-lX11','-l:libXtst.so.6','-lm','-lz','-o',str(run/'eyes')],'link')
    digest=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
    receipt={'schema':'idol.eyes.server.build.v1','source':{p:digest(ROOT/p) for p in paths},'compilerSha256':digest(compiler),'runtimeSha256':digest(runtime),'generatedSha256':digest(run/'eyes.c'),'binarySha256':digest(run/'eyes'),'factCoverage':graph.get('fact_coverage'),'graphComplete':not graph.get('unresolved_applications'),'cFlags':['-Os','-flto','-ffunction-sections','-fdata-sections','-Wl,--gc-sections'],'scope':'compiled Idol stdio server and X11 realization; local launcher authority, not integrated graph world or mesh'}
    (run/'build.json').write_text(json.dumps(receipt,indent=2)+'\n')
    target=out/'eyes';temporary=run/'delivery';temporary.write_bytes((run/'eyes').read_bytes());temporary.chmod(0o755);temporary.replace(target)
    print(run)
if __name__=='__main__':main()
