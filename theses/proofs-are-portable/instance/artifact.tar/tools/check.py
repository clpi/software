"""Validate comparison contracts; never certify desktop capability or superiority."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys

REQUIRED_COMPARATORS = {'openclaw/Peekaboo', 'vercel-labs/agent-desktop'}
DESKTOP_COMMAND_DIGEST = 'ce82f4f49bbc7f86464c825ecdd828379b3c3c1efde40d3b723586db2dbd0d37'
DESKTOP_METRIC_DIGEST = '2db6ce2d95924558247d92cee490701cc8aa3ee299e278252f3f970862d9e057'
DESKTOP_PROFILES = ('macos-arm64', 'macos-x86_64', 'windows-arm64', 'windows-x86_64', 'linux-x11-arm64', 'linux-x11-x86_64', 'linux-wayland-arm64', 'linux-wayland-x86_64')
DESKTOP_ROUTES = ('cli-cold', 'mcp-persistent', 'ffi-in-process')
DESKTOP_SUBCOMMANDS = {'session': ['start', 'end', 'list', 'gc'], 'trace': ['show', 'export'], 'skills': ['list', 'get', 'path'], 'cursor-overlay': ['enable', 'disable']}
DESKTOP_OBLIGATIONS = ('semantic.identity', 'semantic.discovery', 'semantic.headless', 'semantic.effects', 'semantic.waits', 'semantic.images', 'authority.boundaries', 'authority.human', 'interface.mcp', 'interface.ffi', 'interface.cli', 'interface.agent', 'runtime.recovery', 'distribution.complete', 'integration.idol', 'integration.mesh', 'qualification.external', 'qualification.construction')


def decode(text):
    def pairs(entries):
        value = {}
        for key, item in entries:
            if key in value:
                raise ValueError('duplicate JSON member: ' + key)
            value[key] = item
        return value
    def nonfinite(value):
        raise ValueError('non-finite JSON number: ' + value)
    return json.loads(text, object_pairs_hook=pairs, parse_constant=nonfinite)


def exact(value):
    return isinstance(value, str) and re.fullmatch(r'[0-9a-f]{40}', value) is not None


def names(value):
    return (isinstance(value, list) and bool(value) and
            all(isinstance(x, str) and x.strip() for x in value) and
            len(set(value)) == len(value))


def desktop(comparison):
    errors = []
    registry = comparison.get('sourceRegistry')
    surface = comparison.get('commandSurface')
    baseline = comparison['baseline']
    if not isinstance(registry, dict) or not isinstance(surface, dict):
        return ['agent-desktop requires source registry and command surface']
    if (not exact(registry.get('blob')) or not exact(registry.get('commit')) or
            registry.get('commit') != baseline.get('commit') or
            registry.get('path') != 'src/cli/mod.rs'):
        errors.append('agent-desktop registry must bind the exact source and path')
    released = baseline.get('released')
    if not isinstance(released, dict) or not exact(released.get('commit')):
        errors.append('released comparator must have a separate exact source pin')
    commands = surface.get('names')
    if not names(commands):
        return errors + ['agent-desktop command names must be nonempty and unique']
    digest = hashlib.sha256(('\n'.join(sorted(commands)) + '\n').encode()).hexdigest()
    if (surface.get('count') != 60 or len(commands) != 60 or
            digest != DESKTOP_COMMAND_DIGEST or surface.get('sha256') != digest):
        errors.append('agent-desktop source command inventory changed or was reduced')
    if surface.get('subcommands') != DESKTOP_SUBCOMMANDS:
        errors.append('agent-desktop subcommand coverage changed or was reduced')
    refused = surface.get('refusalOnly')
    if not names(refused) or set(refused) != {'key-down','key-up','mouse-down','mouse-up'}:
        errors.append('held-input refusal contracts must remain explicit')
    for field, expected in [('profiles', DESKTOP_PROFILES), ('routes', DESKTOP_ROUTES)]:
        actual = comparison.get(field)
        if not names(actual) or set(actual) != set(expected):
            errors.append('agent-desktop ' + field + ' changed or were reduced')
    cases = comparison.get('cases')
    if isinstance(cases, list) and all(isinstance(x, dict) for x in cases):
        required = {'command.' + x for x in commands} | set(DESKTOP_OBLIGATIONS)
        required |= {'command.' + parent + '.' + child
                     for parent, children in DESKTOP_SUBCOMMANDS.items() for child in children}
        labels = {x.get('label') for x in cases if isinstance(x.get('label'), str)}
        if not required <= labels:
            errors.append('agent-desktop required command/semantic cases missing')
        for case in cases:
            if case.get('label') in {'command.key-down','command.key-up','command.mouse-down','command.mouse-up'}:
                if case.get('expectation') != 'safe-refusal':
                    errors.append('reserved held-input name is not an operational capability')
    metrics = comparison.get('metrics')
    if isinstance(metrics, list) and all(isinstance(x, dict) for x in metrics):
        triples = [(x.get('label'), x.get('direction'), x.get('unit')) for x in metrics]
        if all(all(isinstance(v, str) for v in row) for row in triples):
            digest = hashlib.sha256(json.dumps(sorted(triples), separators=(',', ':')).encode()).hexdigest()
            if digest != DESKTOP_METRIC_DIGEST or comparison.get('metricSha256') != digest:
                errors.append('agent-desktop metric coverage or meaning changed')
    return errors


def validate(project, comparison):
    if not isinstance(project, dict) or not isinstance(comparison, dict):
        return ['project and comparison must be objects']
    errors = []
    if project.get('name') != 'idol-eyes':
        errors.append('product must be idol-eyes')
    if project.get('runtime') != 'Idol':
        errors.append('production runtime must be Idol')
    for key in ('native', 'compiler'):
        value = project.get(key)
        if not isinstance(value, dict) or not exact(value.get('commit')):
            errors.append(key + '.commit must be an exact commit')
    baseline = comparison.get('baseline')
    if not isinstance(baseline, dict):
        return errors + ['baseline must be an object']
    if not exact(baseline.get('commit')):
        errors.append('baseline.commit must be an exact commit')
    repository = baseline.get('repository')
    if not isinstance(repository, str) or not re.fullmatch(r'[\w.-]+/[\w.-]+', repository):
        errors.append('baseline.repository must be owner/repository')
    if baseline.get('runtimeDependency') is not False:
        label = repository.rsplit('/', 1)[-1] if isinstance(repository, str) else 'comparator'
        errors.append(label + ' must remain an external comparator')
    if comparison.get('superiorityEstablished') is not False:
        errors.append('this bootstrap cannot certify superiority')
    if comparison.get('schema') != 'idol.eyes.comparison.v1':
        errors.append('unsupported comparison schema')
    cases = comparison.get('cases', [])
    if not isinstance(cases, list) or not cases:
        errors.append('comparison must contain cases')
    else:
        labels = [c.get('label') for c in cases if isinstance(c, dict)]
        if len(labels) != len(cases) or any(not isinstance(x, str) or not x for x in labels):
            errors.append('invalid comparison case')
        elif len(set(labels)) != len(labels):
            errors.append('comparison case labels must be unique')
        if any(not isinstance(c, dict) or c.get('state') != 'unmeasured' for c in cases):
            errors.append('bootstrap comparison cases must remain unmeasured')
        if any(not isinstance(c, dict) or not isinstance(c.get('requirement'), str) or
               not c['requirement'].strip() for c in cases):
            errors.append('comparison case must state its semantic requirement')
    metrics = comparison.get('metrics', [])
    if not isinstance(metrics, list) or not metrics:
        errors.append('comparison must contain metrics')
    elif any(not isinstance(m, dict) or m.get('direction') not in ('lower', 'higher') or
             not isinstance(m.get('label'), str) or not m.get('label') or
             not isinstance(m.get('unit'), str) or not m.get('unit') for m in metrics):
        errors.append('invalid comparison metric')
    elif len({m['label'] for m in metrics}) != len(metrics):
        errors.append('comparison metric labels must be unique')
    if repository == 'vercel-labs/agent-desktop' and not errors:
        errors.extend(desktop(comparison))
    return errors


def catalog(root, project):
    if not isinstance(project, dict):
        raise ValueError('project must be an object')
    paths = project.get('comparisons')
    if not names(paths) or len(paths) > 16 or project.get('comparison') not in paths:
        raise ValueError('comparisons must uniquely include the primary comparison')
    comparisons = []
    root = Path(root).resolve()
    for name in paths:
        if not re.fullmatch(r'bench/[A-Za-z0-9.-]+\.json', name) or '..' in Path(name).parts:
            raise ValueError('comparison path must be a direct bench JSON file')
        path = root / name
        if any(p.is_symlink() for p in (path, path.parent)) or not path.is_file():
            raise ValueError('comparison path is absent or symlinked: ' + name)
        comparison = decode(path.read_text())
        errors = validate(project, comparison)
        if errors:
            raise ValueError(name + ': ' + '; '.join(errors))
        comparisons.append(comparison)
    repositories = [x['baseline']['repository'] for x in comparisons]
    if len(set(repositories)) != len(repositories) or not REQUIRED_COMPARATORS <= set(repositories):
        raise ValueError('both owner-requested comparators are mandatory and unique')
    return comparisons


def inventory(data, comparison):
    registry = comparison['sourceRegistry']
    blob = hashlib.sha1(b'blob ' + str(len(data)).encode() + b'\0' + data).hexdigest()
    if blob != registry['blob']:
        raise ValueError('upstream registry bytes differ from the source pin')
    found = re.findall(r'CommandMetadata::new\("([a-z-]+)",\s*(?:true|false)\)', data.decode('utf-8'))
    if len(found) != len(set(found)) or set(found) != set(comparison['commandSurface']['names']):
        raise ValueError('upstream registry and coverage inventory differ')
    return sorted(found)

def git(root, *args):
    return subprocess.run(['git', '-C', str(root), *args], check=True,
                          capture_output=True, text=True, timeout=30).stdout.strip()


def native(root, project):
    pin = project['native']
    path = root / 'native'
    if not path.is_dir():
        raise ValueError('native checkout is absent; initialize the pinned submodule')
    if Path(git(path, 'rev-parse', '--show-toplevel')).resolve() != path.resolve():
        raise ValueError('native must be its own exact checkout, not the parent repository')
    if git(path, 'rev-parse', 'HEAD') != pin['commit']:
        raise ValueError('native checkout differs from the product pin')
    if git(path, 'status', '--porcelain=v1', '--untracked-files=all'):
        raise ValueError('native checkout is dirty')
    expected = '160000 ' + pin['commit'] + ' 0\tnative'
    if git(root, 'ls-files', '--stage', '--', 'native') != expected:
        raise ValueError('native gitlink differs from the product pin')
    if hashlib.sha256((path / pin['entry']).read_bytes()).hexdigest() != pin['sha256']:
        raise ValueError('native production bytes differ from their pinned digest')



def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--native', action='store_true')
    parser.add_argument('--coverage', action='store_true', help='print obligations, never measured results')
    parser.add_argument('--require-qualified', action='store_true', help='refuse until a real qualification producer exists')
    parser.add_argument('--upstream-registry', type=Path, help='verify exact agent-desktop src/cli/mod.rs bytes')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    try:
        project = decode((root / 'eyes.json').read_text())
        if not isinstance(project, dict):
            raise ValueError('project must be an object')
        comparisons = catalog(root, project)
        if args.native:
            native(root, project)
        if args.upstream_registry:
            if args.upstream_registry.is_symlink() or not args.upstream_registry.is_file():
                raise ValueError('upstream registry must be a regular nonsymlink file')
            comparison = next(x for x in comparisons if x['baseline']['repository'] == 'vercel-labs/agent-desktop')
            inventory(args.upstream_registry.read_bytes(), comparison)
    except (ValueError, OSError, KeyError, TypeError, subprocess.SubprocessError) as error:
        print('REFUSED: ' + str(error), file=sys.stderr)
        return 1
    if args.require_qualified:
        print('UNQUALIFIED: coverage metadata is not capability, benchmark or product evidence.', file=sys.stderr)
        return 2
    if args.coverage:
        report = {'qualification': 'unqualified', 'measuredCells': 0, 'comparators': {}}
        for comparison in comparisons:
            p = len(comparison.get('profiles', [])); r = len(comparison.get('routes', []))
            report['comparators'][comparison['baseline']['repository']] = {
                'source': comparison['baseline']['commit'], 'cases': len(comparison['cases']),
                'metrics': len(comparison['metrics']), 'profiles': p, 'routes': r,
                'commandNames': comparison.get('commandSurface', {}).get('count'),
                'requiredCells': len(comparison['cases']) * p * r if p and r else None,
                'state': 'unmeasured', 'applicability': 'requires source and runtime qualification'}
        print(json.dumps(report, indent=2))
    else:
        print('Composition valid. All requested comparator capabilities and superiority remain UNQUALIFIED.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
