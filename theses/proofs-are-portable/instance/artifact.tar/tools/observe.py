#!/usr/bin/env python3
"""Driver for the observe slice: transport in, Idol decides, transport out.

Foreign preview/qualification driver, not the native production path.
Peekaboo remains forbidden as a finished product dependency. This driver
does not establish graph authority or independently verified application
success. It

  1. reads a Peekaboo `see` JSON document (from --see FILE, or by running
     peekaboo itself under --live --app NAME on a Mac with the bridge up),
  2. projects it into the canonical observation block of docs/observe.md,
  3. pipes the block plus one command line to the compiled observe
     program (OBSERVE_BIN, default ./observe built from protocol/observe.id),
  4. for an `act` command, performs the single resolved transport action
     with `peekaboo click` against the same snapshot (only under --live),
     then takes a fresh observation and prints the post-action display
     text so the caller can verify the effect against a fresh snapshot.

Nothing here interprets a ref, a premise, or a refusal: those decisions
print from the Idol program verbatim.
"""
import argparse
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile


def field(value, name, token=False, reserved=()):
    if not isinstance(value, str) or any(ord(c) < 32 for c in value):
        raise SystemExit(name + " is not a safe transport field")
    if token and (not value or " " in value):
        raise SystemExit(name + " cannot be empty or contain command delimiters")
    if any(delimiter in value for delimiter in reserved):
        raise SystemExit(name + " contains a reserved ref delimiter")
    return value


def project(see):
    if not isinstance(see, dict) or not isinstance(see.get("data"), dict):
        raise SystemExit("observation must contain a data object")
    data = see["data"]
    if not isinstance(data.get("ui_elements"), list):
        raise SystemExit("observation must contain an element list")
    lines = ["S\t%s\t%s" % (field(data.get("snapshot_id"), "snapshot id", token=True, reserved=(":e",)),
                            field(data.get("application_name"), "application name"))]
    for element in data["ui_elements"]:
        if not isinstance(element, dict):
            raise SystemExit("observation element must be an object")
        label = element.get("label") or element.get("description") or ""
        if not isinstance(label, str):
            raise SystemExit("observation label must be text")
        if "\x00" in label:
            raise SystemExit("NUL observation labels are unsupported; refusing rather than truncating")
        label = label.replace("\t", " ").replace("\n", " ")
        actionable = element.get("is_actionable", False)
        if type(actionable) is not bool:
            raise SystemExit("observation actionability must be a boolean")
        lines.append("E\t%s\t%s\t%s\t%s" % (
            field(element.get("id"), "element id", token=True),
            field(element.get("role", ""), "element role"),
            "1" if actionable else "0", label))
    return "\n".join(lines) + "\n"


def run_program(block, command):
    if "\x00" in block or "\x00" in command:
        raise SystemExit("NUL transport input is unsupported; refusing rather than truncating")
    binary = os.environ.get("OBSERVE_BIN", "./observe")
    process = subprocess.run([binary], input=command + "\n" + block,
                             capture_output=True, text=True, timeout=30)
    if process.returncode != 0:
        raise SystemExit("observe program failed: " + process.stderr.strip())
    return process.stdout.strip()


def peekaboo_see(app, capture_directory):
    # This fixture must never replace a pre-existing file in the user's home.
    # Its caller retains this directory through action and reobservation.
    descriptor, path = tempfile.mkstemp(prefix="capture-", suffix=".png", dir=capture_directory)
    os.close(descriptor)
    out = subprocess.run(
        ["peekaboo", "see", "--app", app, "--json",
         "--capture-engine", "classic", "--path", path],
        capture_output=True, text=True, timeout=60)
    if out.returncode != 0:
        raise SystemExit("peekaboo see failed with exit " + str(out.returncode))
    try:
        see = json.loads(out.stdout)
    except json.JSONDecodeError:
        raise SystemExit("peekaboo see returned invalid JSON") from None
    if not isinstance(see, dict):
        raise SystemExit("peekaboo see returned a non-object response")
    if see.get("success") is not True:
        raise SystemExit("peekaboo see failed: " + json.dumps(see.get("error")))
    project(see)  # Validate framing/shape before any later consumer uses it.
    return see


def display_text(see):
    for element in see["data"]["ui_elements"]:
        if element.get("ax_role") == "AXStaticText" and element.get("value"):
            return element["value"]
    return ""


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("command", choices=["snapshot", "act"])
    parser.add_argument("ref", nargs="?", default="")
    parser.add_argument("premise", nargs="?", default="")
    parser.add_argument("--see", help="a peekaboo see JSON document")
    parser.add_argument("--live", action="store_true",
                        help="drive peekaboo on this Mac (snapshot/click)")
    parser.add_argument("--app", default="Calculator")
    args = parser.parse_args()

    with tempfile.TemporaryDirectory(prefix="eyes-observe-") as temporary:
        return preview(args, temporary)



def resolution(answer, see):
    """Validate preview transport framing, not semantic identity or authority."""
    refused = "invalid act response; no action submitted"
    if not isinstance(answer, str):
        raise SystemExit(refused)
    if not answer.startswith("act "):
        try:
            result = json.loads(answer)
        except json.JSONDecodeError:
            raise SystemExit(refused) from None
        if (not isinstance(result, dict) or result.get("ok") is not False
                or not isinstance(result.get("error"), dict)
                or not isinstance(result["error"].get("code"), str)
                or not result["error"]["code"]):
            raise SystemExit(refused)
        return None
    parts = answer.split(" ")
    if (len(parts) != 3 or not parts[1] or not parts[2]
            or any(ord(c) < 32 or ord(c) == 127 for c in answer)):
        raise SystemExit(refused)
    _, transport, snapshot = parts
    data = see["data"]
    if snapshot != data["snapshot_id"]:
        raise SystemExit(refused)
    # This checks the foreign envelope only; it is not live target continuity.
    candidates = [element for element in data["ui_elements"]
                  if element["id"] == transport]
    if len(candidates) != 1 or candidates[0].get("is_actionable") is not True:
        raise SystemExit(refused)
    return transport, snapshot


def preview(args, capture_directory):
    if args.live:
        see = peekaboo_see(args.app, capture_directory)
    elif args.see:
        see = json.loads(Path(args.see).read_text())
    else:
        raise SystemExit("give --see FILE or --live")
    block = project(see)

    command = args.command
    if command == "act":
        command = "act %s %s" % (args.ref, args.premise)
    answer = run_program(block, command)
    target = resolution(answer, see) if args.live and args.command == "act" else None
    print(answer)

    if target is not None:
        transport, snapshot = target
        try:
            click = subprocess.run(
                ["peekaboo", "click", "--on", transport,
                 "--snapshot", snapshot, "--app", args.app],
                capture_output=True, text=True, timeout=60)
        except (subprocess.TimeoutExpired, OSError):
            raise SystemExit("click transport did not complete; effect is unconfirmed, do not retry automatically") from None
        print("transport:", click.stdout.strip() or click.stderr.strip())
        if click.returncode != 0:
            raise SystemExit("click transport failed with exit " + str(click.returncode) + "; effect is unconfirmed, do not retry automatically")
        try:
            fresh = peekaboo_see(args.app, capture_directory)
        except (SystemExit, OSError, subprocess.TimeoutExpired):
            raise SystemExit("post-click observation failed; effect is unconfirmed, do not retry automatically") from None
        print("display after:", display_text(fresh))
        print("Application effect remains unverified; the displayed text is evidence only.", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
