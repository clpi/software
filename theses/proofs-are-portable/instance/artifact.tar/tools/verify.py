#!/usr/bin/env python3
"""Build Idol source, bind its output, then qualify only that exact executable."""
import argparse
import hashlib
import json
import os
import pathlib
import subprocess
import sys
import tempfile
import time
from process_scope import run_scope

ROOT = pathlib.Path(__file__).resolve().parents[1]
PYTHON = [sys.executable] + (['-S'] if sys.flags.no_site else [])
PHASES = ('check', 'desktop', 'safety', 'interaction', 'metadata', 'lease', 'backpressure', 'query', 'plans', 'reconcile', 'result')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', type=pathlib.Path)
    args = parser.parse_args()
    if args.output:
        out = args.output.resolve()
        out.mkdir(mode=0o700, exist_ok=False)
    else:
        parent = ROOT / '.evidence'
        parent.mkdir(exist_ok=True)
        out = pathlib.Path(tempfile.mkdtemp(prefix='source-', dir=parent))
    report = {'schema': 'idol.eyes.source.qualification.v1', 'outcome': 'failed',
              'scope': 'source-built Linux X11 MCP on owned fixtures; not graph authority or competitor qualification', 'runs': []}
    environment = {k: v for k, v in os.environ.items() if not k.startswith('IDOL_EYES_')}
    environment.pop('DISPLAY', None)
    try:
        for key in ('IDOL', 'IDOL_RUNTIME'):
            if not environment.get(key):
                raise RuntimeError('Set ' + key + ' to the existing compiler or its matching runtime')
        # Regular files cannot hang on inherited pipe writers after a child exits.
        with tempfile.TemporaryFile() as stdout, tempfile.TemporaryFile() as stderr:
            try:
                build = run_scope(PYTHON + [str(ROOT / 'tools/server.py')], cwd=ROOT,
                                  env=environment, stdout=stdout, stderr=stderr, timeout=180)
                report['buildRun'] = dict(build)
            except BaseException as error:
                # Cancellation propagates; no returned scope result means that
                # precise cleanup/exit evidence is unavailable to this caller.
                report['buildRun'] = {'ok': False, 'exit': None, 'cleanup': None,
                                      'error': {'type': type(error).__name__, 'message': str(error)}}
                raise
            finally:
                stdout.seek(0); stderr.seek(0)
                build_stdout, build_stderr = stdout.read(), stderr.read()
                (out / 'build.log').write_bytes(build_stdout + build_stderr)
                report['buildRun']['logSha256'] = digest(out / 'build.log')
        if not build['ok']:
            raise RuntimeError('Source build failed; see build.log')
        run = pathlib.Path(build_stdout.decode().strip().splitlines()[-1]).resolve()
        if not run.is_relative_to((ROOT / '.build').resolve()):
            raise RuntimeError('Build returned a path outside its owned output')
        receipt = json.loads((run / 'build.json').read_text())
        binary = run / 'eyes'
        if digest(binary) != receipt['binarySha256']:
            raise RuntimeError('Build executable differs from its receipt')
        for name, expected in receipt['source'].items():
            path = (ROOT / name).resolve()
            if not path.is_relative_to(ROOT) or digest(path) != expected:
                raise RuntimeError('Source differs from build receipt: ' + name)
        report['build'] = receipt
        report['binarySha256'] = digest(binary)
        environment['EYES'] = str(binary)
        commands = [('contract', PYTHON + ['-m', 'unittest', 'discover', '-s', 'tests', '-p', 'test_*.py', '-v'])]
        commands += [(name, PYTHON + ['tests/server/' + name + '.py']) for name in PHASES]
        commands += [(name, PYTHON + ['tests/capture/' + filename + '.py']) for name, filename in [('capture-layout', 'check'), ('capture-observation', 'observe'), ('capture-plans', 'plans')]]
        for name, command in commands:
            phase_environment = dict(environment)
            if name == 'capture-layout':
                phase_environment.update(EVIDENCE=str(out / 'capture-layout'), CAPTURE_COUNT='1')
            start = time.monotonic_ns()
            with (out / (name + '.log')).open('xb') as log:
                result = run_scope(command, cwd=ROOT, env=phase_environment, stdout=log,
                                   stderr=subprocess.STDOUT, timeout=45)
            report['runs'].append({'name': name, **result,
                                   'elapsedNs': time.monotonic_ns() - start,
                                   'logSha256': digest(out / (name + '.log'))})
            print(name, 'PASS' if result['ok'] else 'FAIL', flush=True)
            if not result['ok']:
                raise RuntimeError(name + ' failed')
        if digest(binary) != report['binarySha256']:
            raise RuntimeError('Executable changed during qualification')
        for name, expected in receipt['source'].items():
            if digest(ROOT / name) != expected:
                raise RuntimeError('Source changed during qualification: ' + name)
        report['outcome'] = 'pass'
        return 0
    except Exception as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        return 1
    finally:
        (out / 'report.json').write_text(json.dumps(report, indent=2) + '\n')
        print(out / 'report.json')

if __name__ == '__main__':
    sys.exit(main())
