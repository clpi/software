#!/usr/bin/env python3
"""Run physical ingress qualification with original outputs in a fresh private directory."""
import hashlib
import json
import os
from pathlib import Path
import platform
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()

def main():
    compiler = Path(os.environ.get('IDOL', '')).resolve()
    if not compiler.is_file() or not os.access(compiler, os.X_OK):
        raise SystemExit('IDOL must name an existing executable compiler')
    if platform.system() != 'Linux' or platform.machine() != 'x86_64':
        raise SystemExit('this physical qualification runner is currently Linux x86_64 only')
    parent = ROOT / '.evidence'
    parent.mkdir(exist_ok=True)
    out = Path(tempfile.mkdtemp(prefix='ingress-', dir=parent))
    source = ROOT / 'protocol/ingress.id'
    report = {'schema': 'idol.eyes.ingress.execution.v1', 'outcome': 'failed',
              'scope': 'physical MCP request parser only; not full protocol, graph authority, mesh, UI or performance admission',
              'sourceSha256': digest(source), 'compilerSha256': digest(compiler),
              'host': {'system': platform.system(), 'machine': platform.machine()}, 'runs': []}
    env = os.environ.copy()
    env['IDOL'] = str(compiler)

    def run(name, argv, evidence=None, limit=60):
        child = env.copy()
        if evidence is not None: child['EVIDENCE'] = str(evidence)
        with (out / (name + '.log')).open('xb') as log:
            try:
                process = subprocess.run(argv, cwd=ROOT, env=child, stdout=log,
                                         stderr=subprocess.STDOUT, timeout=limit, check=False)
            except subprocess.TimeoutExpired:
                report['runs'].append({'name': name, 'argv': argv, 'outcome': 'timeout'})
                raise
        report['runs'].append({'name': name, 'argv': argv, 'exit': process.returncode})
        if process.returncode:
            raise RuntimeError(f'{name} failed with {process.returncode}: {out / (name + ".log")}')

    try:
        run('cases', [sys.executable, 'tests/protocol/check.py', '-v'], out / 'cases')
        run('differential', [sys.executable, 'tests/protocol/differential.py'], out / 'differential')
        run('mutations', [sys.executable, 'tests/protocol/mutation.py'], out / 'mutations')
        flags=['-std=c11','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer']
        run('sanitize-build', ['cc',*flags,'-Wno-builtin-declaration-mismatch','-c',str(out/'differential/candidate.bridge.c'),'-o',str(out/'guarded.o')])
        run('sanitize-link', ['cc',*flags,'-Wall','-Wextra','-Werror','tests/protocol/guard.c',str(out/'guarded.o'),'-o',str(out/'guard')])
        env['ASAN_OPTIONS']='detect_leaks=1:halt_on_error=1'
        env['UBSAN_OPTIONS']='halt_on_error=1'
        run('guard', [str(out/'guard'),str(out/'differential/corpus.bin')])
        if digest(source)!=report['sourceSha256'] or digest(compiler)!=report['compilerSha256']:
            raise RuntimeError('source or compiler bytes changed during qualification')
        graph = json.loads((out/'cases/candidate.receipt.json').read_text())
        report['graphComplete']=graph['graphComplete']
        report['factCoverage']=graph['factCoverage']
        report['differential']=json.loads((out/'differential/differential.json').read_text())
        report['mutations']=json.loads((out/'mutations/mutations.json').read_text())
        report['outcome']='pass'
        return 0
    except Exception as error:
        report['error']={'type':type(error).__name__,'message':str(error)}
        return 1
    finally:
        (out/'report.json').write_text(json.dumps(report,indent=2)+'\n')
        print(json.dumps({'outcome':report['outcome'],'report':str(out/'report.json'),
                          'scope':report['scope'],'graphComplete':report.get('graphComplete')},indent=2))

if __name__ == '__main__':
    sys.exit(main())
