"""Linux test orchestration: bounded cleanup of an owned inherited process group.

Not a sandbox: descendants that deliberately change sessions/groups, and an
uncatchably killed controller, require external containment.
"""
import os
import signal
import subprocess
import sys
import time


def error_record(error):
    return {'type': type(error).__name__, 'message': str(error)}


def run_scope(command, *, cwd, env, stdout, stderr, timeout, grace=0.1):
    """Return execution and cleanup evidence; output must use files, not pipes.

    waitid leaves the group leader unreaped so its PID cannot be reused before
    the final group signal. Never call poll/communicate/wait before cleanup.
    """
    result = {'exit': None, 'timedOut': False, 'error': None,
              'cleanup': {'signalsSent': [], 'errors': [], 'leaderReaped': False}}
    child = None
    owned = True
    try:
        if (sys.platform != 'linux' or
                not all(hasattr(os, name) for name in ('waitid', 'P_PID', 'WEXITED', 'WNOHANG', 'WNOWAIT'))):
            raise RuntimeError('Owned process cleanup requires Linux waitid WNOWAIT')
        if timeout <= 0 or grace < 0:
            raise ValueError('timeout must be positive and cleanup grace nonnegative')
        if stdout == subprocess.PIPE or stderr == subprocess.PIPE:
            raise ValueError('Owned process output requires files, not inherited pipes')
        child = subprocess.Popen(command, cwd=cwd, env=env, stdout=stdout,
                                 stderr=stderr, start_new_session=True)
        deadline = time.monotonic() + timeout
        while True:
            try:
                status = os.waitid(os.P_PID, child.pid, os.WEXITED | os.WNOHANG | os.WNOWAIT)
            except ChildProcessError:
                # A foreign SIGCHLD handler/auto-reap invalidates PID ownership.
                # Do not risk signaling a recycled process group.
                owned = False
                raise
            if status is not None:
                break
            remaining = deadline - time.monotonic()
            if remaining <= 0:
                result['timedOut'] = True
                break
            time.sleep(min(0.02, remaining))
    except Exception as error:
        result['error'] = error_record(error)
    finally:
        if child is not None:
            if owned:
                def send(sig):
                    try:
                        os.killpg(child.pid, sig)
                        result['cleanup']['signalsSent'].append(sig.name)
                    except ProcessLookupError:
                        pass
                    except OSError as error:
                        result['cleanup']['errors'].append(error_record(error))
                try:
                    send(signal.SIGTERM)
                    try:
                        time.sleep(grace)
                    except Exception as error:
                        result['cleanup']['errors'].append(error_record(error))
                finally:
                    # Even cancellation during TERM/grace must escalate and reap.
                    # BaseException is propagated after these finally blocks.
                    try:
                        send(signal.SIGKILL)
                    finally:
                        try:
                            result['exit'] = child.wait(timeout=2)
                            result['cleanup']['leaderReaped'] = True
                        except Exception as error:
                            result['cleanup']['errors'].append(error_record(error))
            else:
                result['cleanup']['errors'].append({
                    'type': 'OwnershipLost', 'message': 'Leader was reaped outside the owned scope; group not signaled'})
    result['ok'] = (result['exit'] == 0 and not result['timedOut'] and
                    result['error'] is None and not result['cleanup']['errors'])
    return result
