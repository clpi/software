#!/usr/bin/env python3
"""Build orchestration only: the request parser is authored in protocol/ingress.id."""
import argparse
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[1]
MAGIC = b'\0asm\x01\0\0\0'

# Load the existing sibling runner even when this module is imported by path.
_scope_spec = importlib.util.spec_from_file_location('eyes_wasm_process_scope', ROOT / 'tools/process_scope.py')
process_scope = importlib.util.module_from_spec(_scope_spec)
_scope_spec.loader.exec_module(process_scope)


def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def build(compiler, capture, source=None, limit=60):
    compiler = Path(compiler).resolve(strict=True)
    if not compiler.is_file() or not os.access(compiler, os.X_OK):
        raise ValueError('compiler must be an executable file')
    source = Path(source or ROOT / 'protocol/ingress.id').resolve(strict=True)
    capture = Path(capture).absolute()
    capture.mkdir(mode=0o700)
    artifact = capture / 'ingress.wasm'
    report = {
        'schema': 'idol.eyes.wasm.build.v1', 'outcome': 'failed',
        'scope': 'Idol request parsing library only; no dispatch, desktop effects or graph-world admission',
        'sourceSha256': digest(source), 'compilerSha256': digest(compiler),
        'target': 'wasm32-wasi', 'backend': 'wasm',
        'compilerRevisionVerified': False,
        'qualification': 'not executed; binary validation and behavior require the separate Wasm tests',
    }
    command = [str(compiler), 'compile', '--no-cache', '--backend=wasm',
               '--target', 'wasm32-wasi', str(source), '-o', str(artifact)]
    report['command'] = command
    try:
        # There is deliberately no --lib: the compiler selects a library from
        # this source's absence of a process entry. No source is rewritten.
        with (capture / 'compile.log').open('xb') as log:
            if sys.platform == 'linux':
                report['processScope'] = 'linux-owned-inherited-group'
                try:
                    process = process_scope.run_scope(
                        command, cwd=None, env=None, stdout=log,
                        stderr=subprocess.STDOUT, timeout=limit)
                    report['process'] = process
                except BaseException as error:
                    # The runner cleans in finally, but cancellation supplies
                    # no returned exit/cleanup record. Preserve that distinction.
                    report['process'] = {
                        'ok': False, 'exit': None, 'cleanup': None,
                        'error': {'type': type(error).__name__, 'message': str(error)},
                    }
                    raise
                report['exit'] = process['exit']
                if process['timedOut']:
                    report['timeout'] = True
                    raise subprocess.TimeoutExpired(command, limit)
                if not process['ok']:
                    raise RuntimeError('Idol compilation or owned process cleanup failed; see compile.log')
            else:
                # Preserve the existing non-Linux build route without claiming
                # inherited-group containment that this runner cannot provide.
                report['processScope'] = 'direct-child-only'
                try:
                    child = subprocess.run(command, stdout=log, stderr=subprocess.STDOUT,
                                           timeout=limit, check=False)
                except subprocess.TimeoutExpired:
                    report['timeout'] = True
                    raise
                report['exit'] = child.returncode
                if child.returncode:
                    raise RuntimeError('Idol compilation failed; see compile.log')
        if artifact.read_bytes()[:8] != MAGIC:
            raise RuntimeError('compiler did not emit a WebAssembly version-1 artifact')
        if digest(source) != report['sourceSha256'] or digest(compiler) != report['compilerSha256']:
            raise RuntimeError('source or compiler changed during the build')
        report['artifactSha256'] = digest(artifact)
        report['artifactBytes'] = artifact.stat().st_size
        report['outcome'] = 'built-not-executed'
    except BaseException as error:
        report['error'] = {'type': type(error).__name__, 'message': str(error)}
        raise
    finally:
        report['logSha256'] = digest(capture / 'compile.log') if (capture / 'compile.log').exists() else None
        (capture / 'build.json').write_text(json.dumps(report, indent=2) + '\n')
    return report


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--compiler', default=os.environ.get('IDOL'))
    parser.add_argument('--capture', type=Path)
    args = parser.parse_args()
    if not args.compiler:
        parser.error('set IDOL or provide --compiler')
    capture = args.capture
    if capture is None:
        parent = ROOT / '.build'
        if parent.is_symlink():
            parser.error('.build must not be a symlink')
        parent.mkdir(exist_ok=True)
        # Reserve a unique name; build itself requires that it does not exist.
        capture = Path(tempfile.mkdtemp(prefix='wasm-', dir=parent))
        capture.rmdir()
    try:
        report = build(args.compiler, capture)
    except (Exception, KeyboardInterrupt) as error:
        print(json.dumps({'outcome': 'failed', 'capture': str(capture),
                          'error': type(error).__name__, 'message': str(error)}))
        return 1
    print(json.dumps({'outcome': report['outcome'], 'artifact': str(capture / 'ingress.wasm'),
                      'report': str(capture / 'build.json')}, indent=2))
    return 0


if __name__ == '__main__':
    sys.exit(main())
