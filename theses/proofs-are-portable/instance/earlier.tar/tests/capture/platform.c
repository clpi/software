/* Synthetic foreign ABI responses only. Pixel conversion executes in Idol. */
#include <X11/Xlib.h>
#include <X11/Xutil.h>
#include <stdint.h>
#include <string.h>
#include <dlfcn.h>
#include <zlib.h>
static XImage snapshot;
static Visual view;
static uint64_t calls, releases, images, encodings;
static int failencode;
void eyes_failencode(int value) { failencode=value; }
uint64_t eyes_images(void) { return images; }
uint64_t eyes_encodings(void) { return encodings; }
int compress2(Bytef *out, uLongf *length, const Bytef *data, uLong size, int level) {
    typedef int (*encoder)(Bytef *,uLongf *,const Bytef *,uLong,int);
    encoder original=(encoder)dlsym(RTLD_NEXT,"compress2");
    if(!original)return Z_STREAM_ERROR;
    ++encodings;
    if(failencode) { if(*length) out[0]=0; return Z_BUF_ERROR; }
    return original(out,length,data,size,level);
}
void eyes_tick(void) { ++calls; }
uint64_t eyes_calls(void) { return calls; }
uint64_t eyes_releases(void) { return releases; }
void eyes_image(void *pixels, int width, int height, int stride, int bits,
                int order, unsigned long r, unsigned long g, unsigned long b) {
    memset(&snapshot, 0, sizeof snapshot); memset(&view, 0, sizeof view);
    snapshot.width=width; snapshot.height=height; snapshot.bytes_per_line=stride;
    snapshot.bits_per_pixel=bits; snapshot.byte_order=order; snapshot.data=pixels;
    snapshot.red_mask=r; snapshot.green_mask=g; snapshot.blue_mask=b;
    view.class=TrueColor; calls=0; releases=0; images=0; encodings=0;
}
XImage *XGetImage(Display *d, Drawable w, int x, int y, unsigned int width,
                 unsigned int height, unsigned long mask, int format) {
    (void)d;(void)w;(void)x;(void)y;(void)width;(void)height;(void)mask;(void)format;
    ++images; return &snapshot;
}
#undef XDestroyImage
int XDestroyImage(XImage *image) { if(image==&snapshot) ++releases; return 0; }
Visual *XDefaultVisual(Display *d, int screen) { (void)d;(void)screen;return &view; }
int XDefaultScreen(Display *d) { (void)d;return 0; }
Window XRootWindow(Display *d, int screen) { (void)d;(void)screen;return 1; }
