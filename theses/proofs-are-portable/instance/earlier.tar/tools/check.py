"""Check product composition metadata; this does not certify UI or speed."""
import argparse
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys


def validate(project, comparison):
    errors = []
    if project.get('name') != 'idol-eyes':
        errors.append('product must be idol-eyes')
    if project.get('runtime') != 'Idol':
        errors.append('production runtime must be Idol')
    for key in ('native', 'compiler'):
        pin = project.get(key, {}).get('commit', '')
        if not isinstance(pin, str) or not re.fullmatch(r'[0-9a-f]{40}', pin):
            errors.append(key + '.commit must be an exact commit')
    baseline = comparison.get('baseline', {})
    pin = baseline.get('commit', '')
    if not isinstance(pin, str) or not re.fullmatch(r'[0-9a-f]{40}', pin):
        errors.append('baseline.commit must be an exact commit')
    if baseline.get('runtimeDependency') is not False:
        errors.append('Peekaboo must remain an external comparator')
    if comparison.get('superiorityEstablished') is not False:
        errors.append('this bootstrap cannot certify superiority')
    cases = comparison.get('cases', [])
    if not isinstance(cases, list) or not cases:
        errors.append('comparison must contain cases')
    else:
        labels = [c.get('label') for c in cases if isinstance(c, dict)]
        if len(labels) != len(cases) or any(not isinstance(x, str) or not x for x in labels):
            errors.append('invalid comparison case')
        elif len(set(labels)) != len(labels):
            errors.append('comparison case labels must be unique')
        if any(not isinstance(c, dict) or c.get('state') != 'unmeasured' for c in cases):
            errors.append('bootstrap comparison cases must remain unmeasured')
    metrics = comparison.get('metrics', [])
    if not isinstance(metrics, list) or not metrics:
        errors.append('comparison must contain metrics')
    elif any(not isinstance(m, dict) or m.get('direction') not in ('lower', 'higher') or
             not isinstance(m.get('label'), str) or not m.get('label') or
             not isinstance(m.get('unit'), str) or not m.get('unit') for m in metrics):
        errors.append('invalid comparison metric')
    return errors


def git(root, *args):
    return subprocess.run(['git', '-C', str(root), *args], check=True,
                          capture_output=True, text=True, timeout=30).stdout.strip()


def native(root, project):
    pin = project['native']
    path = root / 'native'
    if not path.is_dir():
        raise ValueError('native checkout is absent; initialize the pinned submodule')
    if Path(git(path, 'rev-parse', '--show-toplevel')).resolve() != path.resolve():
        raise ValueError('native must be its own exact checkout, not the parent repository')
    if git(path, 'rev-parse', 'HEAD') != pin['commit']:
        raise ValueError('native checkout differs from the product pin')
    if git(path, 'status', '--porcelain=v1', '--untracked-files=all'):
        raise ValueError('native checkout is dirty')
    expected = '160000 ' + pin['commit'] + ' 0\tnative'
    if git(root, 'ls-files', '--stage', '--', 'native') != expected:
        raise ValueError('native gitlink differs from the product pin')
    if hashlib.sha256((path / pin['entry']).read_bytes()).hexdigest() != pin['sha256']:
        raise ValueError('native production bytes differ from their pinned digest')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--native', action='store_true', help='also require the exact clean native checkout')
    args = parser.parse_args()
    root = Path(__file__).resolve().parents[1]
    try:
        project = json.loads((root / 'eyes.json').read_text())
        comparison = json.loads((root / 'bench/peekaboo.json').read_text())
        errors = validate(project, comparison)
        if errors:
            raise ValueError('; '.join(errors))
        if args.native:
            native(root, project)
    except (ValueError, OSError, KeyError, TypeError, subprocess.SubprocessError) as error:
        print('REFUSED: ' + str(error), file=sys.stderr)
        return 1
    print('Composition valid. Product and Peekaboo superiority remain UNQUALIFIED.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
